/*global Backbone,$,window,alert,_,moment,Cookies,google,document,ga,confirm*/
/*jslint unparam: true*/
"use strict";

var sw = {};
sw.events = {
    userLoggedIn: 'userLoggedIn',
    userLoggedOut: 'userLoggedOut',
    translate: 'translate',
};
_.extend(sw, Backbone.Events);

moment.duration.fn.format.defaults.trim = false;

sw.User = Backbone.Model.extend({
    url: "/api/me"
});

// Currently logged in user
sw.currentUser = new sw.User();

sw.Task = Backbone.Model.extend({
    urlRoot: "/api/tasks"
});

sw.Tasks = Backbone.Collection.extend({
    url: "/api/tasks"
});

sw.Workflow = Backbone.Model.extend({
    urlRoot: "/api/workflows"
});

sw.Workflows = Backbone.Collection.extend({
    url: "/api/workflows"
});

sw.Company = Backbone.Model.extend({
    urlRoot: "/api/companies"
});

sw.Companies = Backbone.Collection.extend({
    url: "/api/companies"
});

sw.Stage = Backbone.Model.extend({
    urlRoot: "/api/stages"
});

sw.Stages = Backbone.Collection.extend({
    url: "/api/stages"
});

sw.workflowStages = Backbone.Collection.extend({
    url: "/api/stages"
});

sw.Organization = Backbone.Model.extend({
    urlRoot: "/api/organizations"
});

sw.Organizations = Backbone.Collection.extend({
    url: "/api/organizations"
});

sw.Currencies = Backbone.Collection.extend({
    url: "/api/currencies"
});

sw.Person = Backbone.Model.extend({
    urlRoot: "/api/persons"
});

sw.People = Backbone.Collection.extend({
    url: "/api/persons"
});

sw.CompanyUsers = Backbone.Collection.extend({
    url: "/api/company_users"
});

sw.CompanyUser = Backbone.Model.extend({
    urlRoot: "/api/company_users"
});

sw.Timeline = Backbone.Collection.extend({
    url: "/api/timeline"
});

sw.Activity = Backbone.Model.extend({
    urlRoot: "/api/activities"
});

sw.Activities = Backbone.Collection.extend({
    url: "/api/activities"
});

sw.Notes = Backbone.Collection.extend({
    url: "/api/notes"
});

sw.Note = Backbone.Model.extend({
    urlRoot: "/api/notes"
});

sw.ActivityTypes = Backbone.Collection.extend({
    url: "/api/activity_types"
});

sw.Contact = Backbone.Model.extend({
    urlRoot: "/api/contacts"
});

sw.Contacts = Backbone.Collection.extend({
    url: "/api/contacts"
});

sw.DeletedObject = Backbone.Model.extend({
    urlRoot: "/api/deleted_objects"
});

sw.DeletedObjects = Backbone.Collection.extend({
    url: "/api/deleted_objects"
});

sw.TimeEntry = Backbone.Model.extend({
    urlRoot: "/api/time_entries",
});

sw.TimeEntries = Backbone.Collection.extend({
    url: "/api/time_entries"
});

sw.UserEvent = Backbone.Model.extend({
    urlRoot: "/api/user_events",
});

sw.UserEvents = Backbone.Collection.extend({
    url: "/api/user_events",
});

sw.duration = function (model) {
    var started_at = model.get('started_at'),
        finished_at = model.get('finished_at') || new Date(),
        diff = moment(finished_at).diff(moment(started_at));
    return moment.duration(diff);
};

sw.ThanksView = Backbone.View.extend({

    el: '.thanks-for-signup',

    initialize: function () {
        sw.on(sw.events.userLoggedIn, this.render, this);
        sw.on(sw.events.userLoggedOut, this.hide, this);
    },

    hide: function () {
        this.$el.addClass('hidden');
    },

    render: function () {
        this.$el.removeClass('hidden');
    },

});

sw.FilteredView = Backbone.View.extend({

    filterOnlyActiveTasks: function () {
        var onlyActiveTasks = this.$el.find('.only-active-tasks').is(':checked');

        Cookies.set('only_active_tasks', onlyActiveTasks);

        this.fetchTasks();
    },

    fetchTasks: function () {
        var onlyActiveTasks = Cookies.get('only_active_tasks') === 'true';

        sw.tasks.fetch(
            {
                data: {
                    only_active_tasks: onlyActiveTasks,
                },
                reset: true,
            }
        );
    },

    renderFilters: function () {
        var onlyActiveTasks = Cookies.get('only_active_tasks') === 'true';

        this.$el.find('.only-active-tasks').prop('checked', onlyActiveTasks);
    },
});

sw.NavView = sw.FilteredView.extend({

    el: '.navbar-fixed-top',

    companyTemplate: _.template($("#company-menu-item-template").html()),
    companyDropdown: $('.current-user-menu-dropdown'),

    initialize: function () {
        sw.on(sw.events.userLoggedIn, this.render, this);
        sw.on(sw.events.userLoggedOut, this.hide, this);

        sw.companies.on("add", this.renderCompany, this);
        sw.companies.on("remove", this.removeCompany, this);
    },

    events: {
        'click .company-selection-item': 'selectCompany',
        'click .select-language': 'selectLanguage',
    },

    selectCompany: function (event) {
        event.preventDefault();

        var companyID = $(event.target).closest('li').attr('data-company-id'),
            view = this;

        sw.currentUser.save(
            {'active_company_id': companyID},
            {
                wait: true,
                success: function () {
                    $('.company-selection-item').find('.fa-check').addClass('hidden');
                    $('[data-company-id="' + companyID + '"]').find('.fa-check').removeClass('hidden');

                    var el = $('.current-workflow-name');

                    if (!sw.currentUser.get('active_workflow_id')) {
                        el.text('Workflow');
                        el.removeAttr('data-workflow-id');
                    } else {
                        el.text(sw.currentUser.get('active_workflow_name'));
                        el.attr('data-workflow-id', sw.currentUser.get('active_workflow_name'));
                    }

                    sw.workflows.reset();
                    sw.workflows.fetch();

                    sw.stages.reset();
                    sw.stages.fetch({
                        success: function () {
                            view.fetchTasks();
                        },
                    });

                    sw.organizations.reset();
                    sw.organizations.fetch();

                    sw.people.reset();
                    sw.people.fetch();

                    sw.activities.reset();
                    sw.activities.fetch();

                    sw.timeline.reset();
                    sw.timeline.fetch();

                    sw.companyUsers.reset();
                    sw.companyUsers.fetch();

                    if (Backbone.history.getFragment().indexOf("workflows") !== -1) {
                        sw.router.navigate('/settings/workflows', {trigger: true});
                    }
                },
            }
        );
    },

    hide: function () {
        $('.current-user-menu').addClass('hidden');

        $('.logged-in-menu').addClass('hidden');

        $('.nav .login').removeClass('hidden');
    },

    render: function () {
        $('.current-user-menu').removeClass('hidden');

        $('.logged-in-menu').removeClass('hidden');

        $('.current-user-name').text(sw.currentUser.get('email'));

        $('.nav .login').addClass('hidden');

        sw.lazyFetch(sw.companies);
    },

    selectLanguage: function (event) {
        event.preventDefault();

        sw.setLang($(event.target).attr('data-lang'));
    },

    renderCompany: function (model) {
        this.companyDropdown.prepend(this.companyTemplate(model.attributes));
        if (sw.currentUser.get('active_company_id') === model.get('id')) {
            $('[data-company-id="' + model.get('id') + '"]').find('.fa-check').removeClass('hidden');
        }
    },

    removeCompany: function (model) {
        this.companyDropdown.find('[data-company-id="' + model.get('id') + '"]').remove();
    },
});

sw.getLang = function () {
    return Cookies.get('lang') || 'eng';
};

sw.setLang = function (lang) {
    Cookies.set('lang', lang);

    sw.trigger(sw.events.translate);
};

sw.translate = function (text) {
    var dict = sw.appView.dict[sw.getLang()];
    if (!dict) {
        // nothing to translate with
        return text;
    }
    return dict[$.trim(text)] || text;
};

sw.popover = null;

sw.createPopover = function (el, placement, content) {
    sw.popover = el.popover({
        content: sw.translate(content),
        trigger: 'manual',
        placement: placement,
        title: sw.translate('Tutorial'),
        html: true,
    });
};

sw.hasEvent = function (name) {
    return sw.userEvents.findWhere({name: name});
};

sw.createEvent = function (name) {
    if (sw.hasEvent(name)) {
        return;
    }
    sw.userEvents.create({name: name});
};

sw.showTutorial = function (view, section, id) {
    if (!sw.hasEvent('tutorialStarted')) {
        return;
    }

    if (view === sw.settingsView) {
        if (section === 'companies' && !sw.hasEvent('editCompany')) {
            sw.createPopover(view.$el.find('.edit-company'), 'right', 'Click here to change the name of your company.');
        }
        if (section === 'users' && !sw.hasEvent('addUser')) {
            sw.createPopover(view.$el.find('.add-user-button'), 'right', 'Click here add users to your company.');
        }
        if (section === 'workflows') {
            if (!sw.hasEvent('viewWorkflow')) {
                if (!id) {
                    sw.createPopover(view.$el.find('.workflow-list-item'), 'right', 'Each task will pass through stages defined by workflow. Click here to see the details of your workflow.');
                } else {
                    sw.tutorialDone('viewWorkflow');
                }
            } else if (!sw.hasEvent('editWorkflow')) {
                if (id) {
                    sw.createPopover(view.$el.find('.edit-workflow-button'), 'right', 'Click here to change the name of your workflow.');
                }
            } else if (!sw.hasEvent('editStages')) {
                if (id) {
                    sw.createPopover(view.$el.find('#sortable-stage-list'), 'right', 'Click on stage name to edit it. Drag a stage to reorder. <a id="editStagesDone">Continue tutorial.</a>');
                }
            }
        }
    }

    if (view === sw.boardView) {
        if (!sw.hasEvent('addTask')) {
            sw.createPopover(view.$el.find('.add-task-button'), 'right', "In board view, you'll see tasks by stage. Click here to add your first task.");
        } else if (!sw.hasEvent('dragTask')) {
            sw.createPopover(view.$el.find('.table'), 'bottom', "Try to drag the task you just added into another stage.");
        }
    }

    if (view === sw.tasksView) {
        if (!sw.hasEvent('tasksView')) {
            sw.createPopover($('.tasks-menu'), 'bottom', "In tasks view, you'll see all active tasks, regardless of their stage. <a id='tasksViewDone'>Continue tutorial</a>");
        }
    }

    if (view === sw.teamView) {
        if (!sw.hasEvent('teamView')) {
            sw.createPopover(view.$el.find('.team-table'), 'bottom', "In team view, you'll see tasks by user. Try to drag the task onto another user. <a id='teamViewDone'>Continue tutorial</a>");
        }
    }

    if (view === sw.organizationsView) {
        if (!sw.hasEvent('addOrganization')) {
            sw.createPopover(view.$el.find('.add-organization-button'), 'right', "Click here to add an organization your company is dealing with.");
        }
    }

    if (view === sw.peopleView) {
        if (!sw.hasEvent('addPerson')) {
            sw.createPopover(view.$el.find('.add-person-button'), 'right', "Click here to add a contact person your company is dealing with.");
        }
    }

    if (view === sw.activitiesView) {
        if (!sw.hasEvent('addActivity')) {
            sw.createPopover(view.$el.find('.add-activity-button'), 'right', "Activities, such as a phone call, may be related to organization, contact person or task. Click here to add an activity.");
        }
    }

    if (view === sw.workView) {
        if (!sw.hasEvent('startWork')) {
            sw.createPopover(view.$el.find('.start-work-button'), 'right', "Enter a description and click Start to measure the actual work you're doing.");
        } else if (!sw.hasEvent('stopWork')) {
            sw.createPopover(view.$el.find('.stop-work-button'), 'right', "When you're finished working, click Stop.");
        }
    }

    if (sw.popover) {
        sw.popover.popover('show');
        $('#editStagesDone').click(function () {
            sw.tutorialDone('editStages');
        });
        $('#tasksViewDone').click(function () {
            sw.tutorialDone('tasksView');
        });
        $('#teamViewDone').click(function () {
            sw.tutorialDone('teamView');
        });
    }
};

sw.tutorialDone = function (name) {
    if (sw.popover) {
        sw.popover.popover('destroy');
    }

    if (!sw.hasEvent('tutorialStarted')) {
        return;
    }

    if (sw.hasEvent('tutorialDone')) {
        return;
    }

    sw.createEvent(name);

    if (name === 'editCompany') {
        sw.router.navigate('#settings/users', {trigger: true});
    }
    if (name === 'addUser') {
        sw.router.navigate('#settings/workflows', {trigger: true});
    }
    if (name === 'editWorkflow') {
        sw.showTutorial(sw.settingsView, 'workflows', 'id');
    }
    if (name === 'viewWorkflow') {
        sw.showTutorial(sw.settingsView, 'workflows', null);
    }
    if (name === 'editStages') {
        sw.router.navigate('#board', {trigger: true});
    }
    if (name === 'addTask') {
        sw.showTutorial(sw.boardView, null, null);
    }
    if (name === 'dragTask') {
        sw.router.navigate('#tasks', {trigger: true});
    }
    if (name === 'tasksView') {
        sw.router.navigate('#team', {trigger: true});
    }
    if (name === 'teamView') {
        sw.router.navigate('#organizations', {trigger: true});
    }
    if (name === 'addOrganization') {
        sw.router.navigate('#people', {trigger: true});
    }
    if (name === 'addPerson') {
        sw.router.navigate('#activities', {trigger: true});
    }
    if (name === 'addActivity') {
        sw.router.navigate('#work', {trigger: true});
    }
    if (name === 'startWork') {
        sw.showTutorial(sw.workView, null, null);
    }
    if (name === 'stopWork') {
        sw.tutorialDoneModal.render();
    }
};

sw.AppView = Backbone.View.extend({

    el: 'body',

    dict: {
        'est': {
            'Stop': 'Stopp',
            'Continue': 'Jätka',
            'Manual': 'Kasutusjuhend',
            'Export CSV': 'Ekspordi CSV',
            'Please enter a name': 'Palun sisestage nimi',
            'Tutorial': 'Sissejuhatus',
            'Please assign a workflow stage': 'Palun määrake töökorralduse etapp',
            'Please enter a title': 'Palun sisestage kirjeldus',
            'Rename organization': 'Nimeta organisatsioon ümber',
            'Rename task': 'Nimeta ülesanne ümber',
            'Set task value': 'Määra ülesande väärtus',
            'Rename person': 'Nimeta kontakisik ümber',
            'Rename activity': 'Nimeta tegevus ümber',
            'Please enter a subject': 'Palun sisesta teema',
            'Tutorial complete!': 'Sissejuhatus läbitud!',
            "When you're finished working, click Stop.": "Kui said töö tehtud, vajuta Stop.",
            "You have completed the tutorial. If you have further questions, please contact us!": "Said sissejuhatuse edukalt läbitud. Kui sul on küsimusi, siis palun võta meiega ühendust!",
            "Enter a description and click Start to measure the actual work you're doing.": "Sisesta kirjeldus ja vajuta Start, et mõõta tegelikku tööaega.",
            "Activities, such as a phone call, may be related to organization, contact person or task. Click here to add an activity.": "Tegevused, näiteks telefonikõne, võivad olla seotud organisatsiooni, kontaktisiku või ülesandega. Kliki siia, et lisada tegevus.",
            "Click here to add a contact person your company is dealing with.": "Kliki siia, et lisada kontakisik, kellega sinu ettevõte teeb koostööd.",
            "Click here to add an organization your company is dealing with.": "Kliki siia, et lisada organisatsioon, kellega sinu ettevõte teeb koostööd.",
            'Try to drag the task you just added into another stage.': 'Proovi just lisatud ülesanne mõnda teise etappi lohistada',
            "In tasks view, you'll see all active tasks, regardless of their stage. <a id='tasksViewDone'>Continue tutorial</a>": "Ülesannete vaates näed aktiivseid ülesandeid sõltumata nende töökorralduse etapist. <a id='tasksViewDone'>Jätka sissejuhatust</a>",
            "In board view, you'll see tasks by stage. Click here to add your first task.": 'Tahvlivaates näed tööülesandeid etapi lõikes. Kliki siia, et lisada oma esimene tööülesanne.',
            "In team view, you'll see tasks by user. Try to drag the task onto another user. <a id='teamViewDone'>Continue tutorial</a>": "Meeskonna vaates näed ülesandeid kasutajate lõikes. Proovi ülesanne teisele kasutajale lohistada. <a id='teamViewDone'>Jätka sissejuhatust</a>",
            'Each task will pass through stages defined by workflow. Click here to see the details of your workflow.': 'Iga tööülesanne läbib töökorralduses defineeritud etapid. Kliki siia, et näha töökorralduse detailset infot.',
            'Click on stage name to edit it. Drag a stage to reorder. <a id="editStagesDone">Continue tutorial.</a>': 'Kliki etapi nimel, et seda muuta. Lohista etappi, et järjestust muuta. <a id="editStagesDone">Jätka sissejuhatust.</a>',
            'Click here to change the name of your workflow.': 'Kliki siia, et muuta oma töökorralduse nime.',
            'Invite user': 'Saada kutse',
            'Email cannot be empty': 'E-mail peab olema täidetud',
            'Name cannot be empty': 'Nimi peab olema täidetud',
            'Click here add users to your company.': 'Kliki siia, et lisada oma ettevõttele töötajaid.',
            'Click here to change the name of your company.': 'Kliki siia, et oma ettevõtte nime muuta.',
            'Start interactive tutorial!': 'Alusta interaktiivse sissejuhatusega!',
            'Sign up with Facebook': 'Registreeru Facebookiga',
            'Sign up with Google': "Registreeru Google'iga",
            'Invalid e-mail or password': 'Vale e-mail või salasõna',
            'Only active tasks': 'Ainult aktiivsed ülesanded',
            'Time entry': 'Töökirje',
            'Stage': 'Töökorralduse samm',
            'Note': 'Märkus',
            'Remove user': 'Eemalda kasutaja',
            'Call': 'Telefonikõne',
            'Meeting': 'Kohtumine',
            'Deadline': 'Tähtaeg',
            'Lunch': 'Lõuna',
            'Board': 'Tahvel',
            'Tasks': 'Ülesanded',
            'Team': 'Meeskond',
            'Activities': 'Tegevused',
            'People': 'Kontaktisikud',
            'Organizations': 'Ettevõtted',
            'Work': 'Töö',
            'Deleted data': 'Kustutatud andmed',
            'Settings': 'Seaded',
            'Estonian': 'Eesti keel',
            'English': 'Inglise keel',
            'Help and feedback': 'Abi ja tagasiside',
            'Logout': 'Logi välja',
            'Add task': 'Lisa ülesanne',
            'Add activity': 'Lisa tegevus',
            'Add person': 'Lisa kontaktisik',
            'Add organization': 'Lisa ettevõte',
            'Save': 'Salvesta',
            'Success': 'Õnnestus',
            'Failed': 'Ebaõnnestus',
            'Add': 'Lisa',
            'Select': 'Vali',
            'Clear': 'Tühjenda',
            'Delete task': 'Kustuta ülesanne',
            'Delete activity': 'Kustuta tegevus',
            'Add contact': 'Lisa kontaktisik',
            'Delete': 'Kustuta',
            'Delete person': 'Kustuta kontaktisik',
            'Delete organization': 'Kustuta ettevõte',
            'Delete time entry': 'Kustuta töökirje',
            'Undelete': 'Taasta',
            'Add company': 'Lisa ettevõte',
            'Remove company': 'Eemalda ettevõte',
            'Add user': 'Lisa kasutaja',
            'Add workflow': 'Lisa töökorraldus',
            'Edit workflow': 'Muuda töökorraldust',
            'Add stage': 'Lisa samm',
            'Delete workflow': 'Kustuta töökorraldus',
            'Companies': 'Ettevõtted',
            'Workflow': 'Töökorraldus',
            'Details': 'Detailid',
            'Assigned to': 'Kellele määratud',
            'Workflow stage': 'Töökorralduse etapp',
            'Subject': 'Teema',
            'Expected close date': 'Eeldatav lõppkuupäev',
            'Organization': 'Ettevõte',
            'Person': 'Kontaktisik',
            'Notes': 'Märkmed',
            'Files': 'Failid',
            'User': 'Kasutaja',
            'Activity type': 'Tegevuse tüüp',
            'Date': 'Kuupäev',
            'Time': 'Kellaaeg',
            'Duration': 'Kestus',
            'Task': 'Ülesanne',
            'Owner': 'Omanik',
            'Contacts': 'Kontaktisikud',
            'Address': 'Aadress',
            '(no description)': '(kirjeldus puudub)',
            'Deleted at': 'Kustutamise aeg',
            'Type': 'Tüüp',
            'Description': 'Kirjeldus',
            'Title': 'Pealkiri',
            'Value': 'Väärtus',
            'Contact person': 'Kontaktisik',
            'Next activity date': 'Järgmise tegevuse aeg',
            'Done': 'Tehtud',
            'Due date': 'Tähtaeg',
            'Name': 'Nimi',
            'Email': 'E-mail',
            'Phone': 'Telefon',
            'Closed tasks': 'Lõpetatud ülesanded',
            'Open tasks': 'Pooleli ülesanded',
            'Started at': 'Alustamise aeg',
            'Finished at': 'Lõpetamise aeg',
            'Assignment': 'Seotud andmed',
            'Select person': 'Vali kontaktisik',
            'Select organization': 'Vali ettevõte',
            'Are you sure?': 'Kas olete kindel?',
            'Task title': 'Ülesande kirjeldus',
            'Contact person name': 'Kontaktisiku nimi',
            'Organization name': 'Ettevõtte nimi',
            'Task value': 'Ülesande väärtus',
            'Currency': 'Vääring',
            'Reopen': 'Ava uuesti',
            'Failed at': 'Ebaõnnestumise aeg',
            'Mark as done': 'Märgi tehtuks',
            'Select task': 'Vali ülesanne',
            'Task name': 'Ülesande pealkiri',
            'Users': 'Kasutajad',
            'Workflows': 'Töökorraldused',
            'Edit company': 'Muuda ettevõtet',
            'New stage': 'Uus samm',
            'Edit stage': 'Muuda sammu',
            'Thanks for signing up!': 'Aitäh, et registreerusid!',
            'As a new user you are provided with 3 months of free usage.': 'Uue kasutajana pakume sulle 3 kuud tasuta teenust.',
            "superwork.io will launch in March 2017. We'll notify you!": "superwork.io alustab ametlikult 2017 märtsis. Anname sulle sellest märku!",
            'superwork.io is a Web-based Customer Relationships and Task Management software with integrated time and location tracking.': 'superwork.io on veebipõhine kliendihalduse ja ülesannete halduse tarkvara integreeritud tööaja ning asukoha jälgimisega',
            'Work more collaboratively and get more done.': 'Tee koostööd ja saa rohkem tehtud.',
            'See your tasks clearly, take the actions that matter.': 'Oma ülesannetest ülevaadet ning toimeta nõnda, et sellest on kasu.',
            'Sign up for free': 'Registreeru tasuta',
            'Feature comparision': 'Võimaluste võrdlus',
            'Customer Relationship Management': 'Kliendiandmete haldus',
            'Priority 24/7 Skype chat support': "24/7 kasutajatugi üle Skype'i",
            'Priority 24/7 E-mail support': "24/7 kasutajatugi läbi e-maili",
            'Price per user per month': 'Kuutasu kasutaja kohta',
            'Integrated time tracking': 'Tööaja mõõtmine',
            'Push notifications': 'Push notifications',
            'One-click data export': 'Andmete eksport 1 klikiga',
            'Workflow view': 'Töökorralduse vaade',
            'Realtime team view': 'Reaalajas meeskonna vaade',
            'Reporting': 'Raportid',
            'Statistics': 'Statistika',
            'File storage per user': 'Kettaruumi kasutaja kohta',
            'Location tracking': 'Asukoha jälgimine',
            'Integrations': 'Integratsioonid',
            'On-site installations': 'Install kasutaja serverisse',
            'No separate native or mobile app needed': 'Ei vaja eraldi rakendust arvutis või telefonis',
            'Login': 'Logi sisse',
            'Blog': 'Blogi',
            'Email address': 'E-maili aadress',
            'Password': 'Salasõna',
            'Log in with Facebook': 'Logi sisse Facebookiga',
            'Log in with Google': "Logi sisse Google'iga",
        }
    },

    events: {
        'click .start-using': 'startTutorial',
        'click .logged-in-menu a': 'clickMenu',
        'click .current-user-menu-dropdown': 'clickMenu',
    },

    initialize: function () {
        sw.on(sw.events.translate, this.translate, this);

        sw.on(sw.events.userLoggedIn, this.fetchUserEvents, this);
        sw.on(sw.events.userLoggedOut, this.resetUserEvents, this);

        sw.userEvents.on("reset", this.renderStartTutorialButton, this);

        this.translate();
    },

    clickMenu: function () {
        $('#navbar').removeClass('in');
    },

    renderStartTutorialButton: function () {
        if (sw.hasEvent('tutorialDone')) {
            $('.start-using').addClass('hidden');
        } else {
            $('.start-using').removeClass('hidden');
        }
    },

    fetchUserEvents: function () {
        sw.userEvents.fetch({reset: true});
    },

    resetUserEvents: function () {
        sw.userEvents.reset();
    },

    startTutorial: function () {
        sw.createEvent('tutorialStarted');
        sw.router.navigate('#settings/companies', {trigger: true});
    },

    translate: function () {
        var lang = sw.getLang(),
            langDict = this.dict[lang],
            el = null,
            translation = null;
        if (lang === this.$el.attr('data-lang')) {
            // nothing to translate
            return;
        }
        if (!langDict) {
            langDict = {};
        }
        $('a, button, label, th, span, h1, h2, h3, h4, .translate').each(function (_, a) {
            el = $(a);
            if (el.find('a').length) {
                return;
            }
            if (el.find('input').length) {
                return;
            }
            if (el.find('span').length) {
                return;
            }
            if (el.hasClass('dont-translate')) {
                return;
            }
            if (lang !== 'eng') {
                el.attr('orig-lang', $.trim(el.text()));
                translation = langDict[$.trim(el.text())] || el.text();
            } else {
                translation = el.attr('orig-lang');
            }
            el.text(translation);
        });
        $('input').each(function (_, a) {
            el = $(a);
            if (lang !== 'eng') {
                el.attr('orig-lang', el.text());
                translation = langDict[el.attr('placeholder')] || el.attr('placeholder');
            } else {
                translation = el.attr('orig-lang');
            }
            el.attr('placeholder', translation);
        });
        this.$el.attr('data-lang', lang);
    }
});

sw.TutorialDoneModal = Backbone.View.extend({

    el: '#tutorialDoneModal',

    events: {
        'click button': 'done',
    },

    done: function () {
        sw.createEvent('tutorialDone');

        this.$el.modal('hide');
    },

    render: function () {
        this.$el.modal('show');
    },
});

sw.PasswordModal = Backbone.View.extend({

    el: '#activationModal',

    initialize: function () {
        sw.on(sw.events.userLoggedIn, this.checkPassword, this);
    },

    events: {
        'click .set-password-button': 'setPassword',
    },

    setPassword: function () {
        var dialog = this.$el;
        sw.currentUser.save({password: this.$el.find('#newPassword').val()}, {
            wait: true,
            success: function () {
                dialog.modal('hide');
            },
            error: function (ignore, response) {
                dialog.find('.activation-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    checkPassword: function () {
        if (!sw.currentUser.get('has_password')) {
            this.render();
        }
    },

    render: function () {
        var dialog = this;

        dialog.$el.find('.activation-error').addClass('hidden');

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newPassword').focus();
        });

        this.$el.modal('show');
    }
});

sw.TaskModal = Backbone.View.extend({

    el: '#taskModal',

    stageTemplate: _.template($("#task-workflow-stage-template").html()),
    stageDropdown: $('.task-workflow-stage-dropdown'),

    userDropdown: $('.task-user-item-dropdown'),
    userTemplate: _.template($('#task-user-item-template').html()),

    initialize: function () {
        sw.stages.on("add", this.renderStage, this);

        sw.companyUsers.on("add", this.renderUser, this);
    },

    events: {
        'click .save-task-button': 'saveTask',
        'click .task-workflow-stage': 'selectWorkflowStage',
        'click .task-user': 'selectUser',
    },

    renderUser: function (model) {
        this.userDropdown.append(this.userTemplate(model.attributes));
    },

    selectUser: function (event) {
        event.preventDefault();

        var id = $(event.target).closest('li').attr('data-company-user-id'),
            model = sw.companyUsers.get(id);

        this.$el.find('.task-user-name').text(model.get('name'));
        this.$el.find('.task-user-name').attr('data-user-id', model.get('user_id'));
    },

    saveTask: function () {
        var dialog = this,
            task = new sw.Task();
        task.set('name', this.$el.find('#taskTitle').val());
        task.set('stage_id', this.$el.find('#taskWorkflowStage').attr('data-selected-stage-id'));
        task.set('expected_close_date', this.$el.find('#taskExpectedCloseDate').datepicker('getDate'));
        task.set('value', parseInt(this.$el.find('#taskValue').val(), 10));
        task.set('org_name', this.$el.find('#taskOrganizationName').val());
        task.set('org_id', this.$el.find('#taskOrganizationName').attr('data-organization-id'));
        task.set('person_name', this.$el.find('#taskContactPersonName').val());
        task.set('person_id', this.$el.find('#taskContactPersonName').attr('data-person-id'));
        task.set('currency', this.$el.find('#taskCurrency').val());
        task.set('user_id', this.$el.find('.task-user-name').attr('data-user-id'));
        task.save({}, {
            wait: true,
            success: function () {
                sw.tasks.add(task);
                if (dialog.collection) {
                    dialog.collection.add(task);
                }
                dialog.$el.modal('hide');
                sw.tutorialDone('addTask');
            },
            error: function (ignore, response) {
                dialog.$el.find('.task-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    selectWorkflowStage: function (event) {
        event.preventDefault();
        var li = $(event.target).closest('li'),
            name = li.text(),
            id = li.attr('data-workflow-stage-id');
        this.$el.find('.task-workflow-stage-name').text(name);
        this.$el.find('#taskWorkflowStage').attr('data-selected-stage-id', id);
    },

    render: function (data) {
        this.$el.find('#taskWorkflowStage').removeAttr('data-selected-stage-id');
        this.$el.find('.task-workflow-stage-name').text(sw.translate('Workflow stage'));
        this.$el.find('#taskExpectedCloseDate').val('');
        this.$el.find('#taskTitle').val('');
        this.$el.find('#taskValue').val('');
        this.$el.find('#taskOrganizationName').val('');
        this.$el.find('#taskContactPersonName').val('');
        this.$el.find('.task-error').addClass('hidden');

        if (data) {
            if (data.stage_id) {
                this.$el.find('#taskWorkflowStage').attr('data-selected-stage-id', data.stage_id);
            }
            if (data.stage_name) {
                this.$el.find('.task-workflow-stage-name').text(data.stage_name);
            }
            if (data.person_id) {
                this.$el.find('#taskContactPersonName').attr('data-person-id', data.person_id);
            }
            if (data.person_name) {
                this.$el.find('#taskContactPersonName').val(data.person_name);
            }
            if (data.org_id) {
                this.$el.find('#taskOrganizationName').attr('data-organization-id', data.org_id);
            }
            if (data.org_name) {
                this.$el.find('#taskOrganizationName').val(data.org_name);
            }
            if (data.collection) {
                this.collection = data.collection;
            }
        }

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#taskTitle').focus();
        });
        this.$el.modal('show');

        this.$el.find('#taskExpectedCloseDate').datepicker({
            autoclose: true,
        });

        sw.lazyFetch(sw.companyUsers);

        sw.lazyFetch(sw.stages, function () {
            // select first stage automatically, if theres no stage selected yet
            if (!data || !data.stage_id) {
                if (sw.stages.length) {
                    var stage = sw.stages.models[0];
                    dialog.$el.find('#taskWorkflowStage').attr('data-selected-stage-id', stage.get('id'));
                    dialog.$el.find('.task-workflow-stage-name').text(stage.get('name'));
                }
            }
        });

        sw.lazyFetch(sw.organizations, function () {
            var items = sw.organizations.pluck('name');
            dialog.$el.find('#taskOrganizationName').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#taskOrganizationName').removeAttr('data-organization-id');
                        return;
                    }
                    var model = sw.organizations.findWhere({name: ui.item.label});
                    dialog.$el.find('#taskOrganizationName').attr('data-organization-id', model.get('id'));
                },
            });
        });

        sw.lazyFetch(sw.people, function () {
            var items = sw.people.pluck('name');
            dialog.$el.find('#taskContactPersonName').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#taskContactPersonName').removeAttr('data-person-id');
                        return;
                    }
                    var model = sw.people.findWhere({name: ui.item.label});
                    dialog.$el.find('#taskContactPersonName').attr('data-person-id', model.get('id'));
                },
            });
        });

        sw.lazyFetch(sw.currencies, function () {
            var currencies = [];
            sw.currencies.each(function (model) {
                currencies.push({
                    label: model.get('name'),
                    value: model.get('symbol'),
                });
            });
            dialog.$el.find('#taskCurrency').autocomplete({
                source: currencies
            });
        });

    },

    renderStage: function (model) {
        this.stageDropdown.append(this.stageTemplate(model.attributes));
    },
});

sw.shortDateFormat = function () {
    return "L";
};

sw.longDateFormat = function () {
    return "llll";
};

sw.TasksView = sw.FilteredView.extend({

    el: '.tasks-view',

    workflowTemplate: _.template($("#tasks-workflow-menu-item-template").html()),
    workflowDropdown: $('.tasks-workflow-dropdown'),

    taskTemplate: _.template($("#task-row-template").html()),
    taskTable: $('.tasks-table-body'),

    initialize: function () {
        sw.tasks.on("add", this.renderTask, this);
        sw.tasks.on("reset", this.resetTasks, this);
        sw.tasks.on("change", this.updateTask, this);
        sw.tasks.on("remove", this.removeTask, this);

        sw.workflows.on("add", this.renderWorkflow, this);
        sw.workflows.on("reset", this.resetWorkflows, this);
        sw.workflows.on("change", this.updateWorkflow, this);

        sw.on(sw.events.userLoggedIn, this.renderActiveWorkflow, this);
    },

    events: {
        'click .add-task-button': 'addTask',
        'click .workflow-selection-item': 'selectWorkflow',
        'click .only-active-tasks': 'filterOnlyActiveTasks',
    },

    removeTask: function (model) {
        this.taskTable.find('tr[data-task-id="' + model.get('id') + '"]').remove();
    },

    resetTasks: function (models) {
        this.taskTable.empty();
        if (!models) {
            return;
        }
        var view = this;
        models.each(function (model) {
            view.renderTask(model);
        });
    },

    renderTemplate: function (model) {
        var data = _.clone(model.attributes);
        if (data.expected_close_date) {
            data.expected_close_date = moment(data.expected_close_date).format(sw.shortDateFormat());
        }
        if (data.next_activity_date) {
            data.next_activity_time = moment(data.next_activity_date).format(sw.longDateFormat());
        } else {
            data.next_activity_time = '';
        }
        return this.taskTemplate(data);
    },

    renderTask: function (model) {
        this.taskTable.append(this.renderTemplate(model));
    },

    updateTask: function (model) {
        var row = this.taskTable.find('tr[data-task-id="' + model.get('id') + '"]');
        if (this.$el.find('.only-active-tasks').is(':checked') && (model.get('won_time') || model.get('lost_time'))) {
            row.remove();
        } else {
            row.replaceWith(this.renderTemplate(model));
        }
    },

    renderActiveWorkflow: function () {
        if (sw.currentUser.get('active_workflow_name')) {
            var el = this.$el.find('.current-workflow-name');
            el.text(sw.currentUser.get('active_workflow_name'));
            el.attr('data-workflow-id', sw.currentUser.get('active_workflow_id'));
        }
    },

    resetWorkflows: function () {
        this.workflowDropdown.empty();
    },

    renderWorkflow: function (model) {
        this.workflowDropdown.append(this.workflowTemplate(model.attributes));
    },

    updateWorkflow: function (model) {
        var el = this.$el.find('.current-workflow-name');
        if (el.attr('data-workflow-id') === model.get('id')) {
            el.text(model.get('name'));
        }

        this.workflowDropdown.find('[data-workflow-id="' + model.get('id') + '"]').replaceWith(this.workflowTemplate(model.attributes));
    },

    render: function () {
        this.$el.removeClass('hidden');

        this.renderFilters();

        sw.lazyFetch(sw.workflows);

        var view = this;

        sw.lazyFetch(sw.stages, function () {
            view.fetchTasks();
        });

        sw.showTutorial(this);
    },

    selectWorkflow: function (event) {
        event.preventDefault();

        var li = $(event.target).closest('li'),
            workflowID = li.attr('data-workflow-id'),
            view = this;

        sw.currentUser.save(
            {'active_workflow_id': workflowID},
            {
                wait: true,
                success: function () {
                    var el = $('.current-workflow-name');
                    el.text(li.find('a').text());
                    el.attr('data-workflow-id', workflowID);

                    sw.stages.reset();
                    sw.stages.fetch({
                        success: function () {
                            view.fetchTasks();
                        }
                    });
                },
            }
        );
    },

    addTask: function () {
        sw.taskModal.render();
    },

});

sw.TaskNameModal = Backbone.View.extend({

    el: '#taskNameModal',

    model: null,

    events: {
        'click .save-task-button': 'save',
    },

    save: function () {
        var modal = this;

        this.model.save({
            name: this.$el.find('#renameTaskTitle').val(),
        }, {
            wait: true,
            success: function () {
                modal.$el.modal('hide');
            },
            error: function (ignore, response) {
                modal.$el.find('.task-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        this.model = model;

        this.$el.find('.task-error').addClass('hidden');

        this.$el.find('#renameTaskTitle').val(this.model.get('name'));

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#renameTaskTitle').focus();
        });

        this.$el.modal('show');
    },
});

sw.ContactModal = Backbone.View.extend({

    el: '#contactModal',

    model: null,

    events: {
        'click .save-contact-button': 'save',
        'click .delete-contact-button': 'deleteContact',
    },

    save: function () {
        var modal = this,
            model = this.model;

        this.model.save({
            name: this.$el.find('#personContact').val(),
        }, {
            wait: true,
            success: function () {
                modal.$el.modal('hide');
                if (!sw.personContacts.get(model.get('id'))) {
                    sw.personContacts.add(model);
                }
            },
            error: function (ignore, response) {
                modal.$el.find('.contact-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    deleteContact: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }

        var modal = this,
            model = this.model;

        this.model.destroy({
            wait: true,
            success: function () {
                modal.$el.modal('hide');
                sw.personContacts.remove(model);
            },
            error: function (ignore, response) {
                modal.$el.find('.contact-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        this.model = model;

        this.$el.find('.contact-error').addClass('hidden');

        this.$el.find('#personContact').val(this.model.get('name'));

        if (this.model.get('id')) {
            this.$el.find('.delete-contact-button').removeClass('hidden');
        } else {
            this.$el.find('.delete-contact-button').addClass('hidden');
        }

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#personContact').focus();
        });

        this.$el.modal('show');
    },
});

sw.PersonNameModal = Backbone.View.extend({

    el: '#personNameModal',

    model: null,

    events: {
        'click .save-person-button': 'save',
    },

    save: function () {
        var modal = this;

        this.model.save({
            name: this.$el.find('#editPersonName').val(),
        }, {
            wait: true,
            success: function () {
                modal.$el.modal('hide');
            },
            error: function (ignore, response) {
                modal.$el.find('.person-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        this.model = model;

        this.$el.find('.person-error').addClass('hidden');

        this.$el.find('#editPersonName').val(this.model.get('name'));

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#editPersonName').focus();
        });

        this.$el.modal('show');
    },
});

sw.OrganizationNameModal = Backbone.View.extend({

    el: '#organizationNameModal',

    model: null,

    events: {
        'click .save-organization-button': 'save',
    },

    save: function () {
        var modal = this;

        this.model.save({
            name: this.$el.find('#organizationName').val(),
        }, {
            wait: true,
            success: function () {
                modal.$el.modal('hide');
            },
            error: function (ignore, response) {
                modal.$el.find('.organization-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        this.model = model;

        this.$el.find('.organization-error').addClass('hidden');

        this.$el.find('#organizationName').val(this.model.get('name'));

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#organizationName').focus();
        });

        this.$el.modal('show');
    },
});

sw.TaskValueModal = Backbone.View.extend({

    el: '#taskValueModal',

    model: null,

    events: {
        'click .save-task-button': 'save',
    },

    save: function () {
        var modal = this;

        this.model.save({
            value: parseInt(modal.$el.find('#editTaskValue').val(), 10),
            currency: modal.$el.find('#editTaskCurrency').val(),
        }, {
            wait: true,
            success: function () {
                modal.$el.modal('hide');
            },
            error: function (ignore, response) {
                modal.$el.find('.task-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        this.model = model;

        this.$el.find('.task-error').addClass('hidden');

        this.$el.find('#editTaskValue').val(this.model.get('value'));
        this.$el.find('#editTaskCurrency').val(this.model.get('currency'));

        var dialog = this,
            currencies = [];

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#editTaskValue').focus();
        });

        sw.lazyFetch(sw.currencies, function () {
            sw.currencies.each(function (model) {
                currencies.push({
                    label: model.get('name'),
                    value: model.get('symbol'),
                });
            });
            dialog.$el.find('#editTaskCurrency').autocomplete({
                source: currencies
            });
        });

        this.$el.modal('show');
    },
});

sw.EditTaskPersonModal = Backbone.View.extend({

    el: '#editTaskPersonModal',

    model: null,

    events: {
        'click .save-task-button': 'save',
    },

    save: function () {
        var dialog = this;

        this.model.save({
            person_name: this.$el.find('#editTaskPersonName').val(),
            person_id: this.$el.find('#editTaskPersonName').attr('data-person-id'),
        }, {
            wait: true,
            success: function () {
                dialog.$el.modal('hide');
            },
            error: function (ignore, response) {
                dialog.$el.find('.task-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        var dialog = this;

        this.model = model;

        dialog.$el.find('#editTaskPersonName').val('');

        dialog.$el.find('.task-error').addClass('hidden');

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#editTaskPersonName').focus();
        });

        sw.lazyFetch(sw.people, function () {
            var items = sw.people.pluck('name');
            dialog.$el.find('#editTaskPersonName').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#editTaskPersonName').removeAttr('data-person-id');
                        return;
                    }
                    var person = sw.people.findWhere({name: ui.item.label});
                    dialog.$el.find('#editTaskPersonName').attr('data-person-id', person.get('id'));
                },
            });
        });

        this.$el.modal('show');
    },
});

sw.EditOrganizationModal = Backbone.View.extend({

    el: '#editOrganizationModal',

    model: null,

    events: {
        'click .save-button': 'save',
    },

    save: function () {
        var dialog = this;

        this.model.save({
            org_name: this.$el.find('#editOrganizationName').val(),
            org_id: this.$el.find('#editOrganizationName').attr('data-org-id'),
        }, {
            wait: true,
            success: function () {
                dialog.$el.modal('hide');
            },
            error: function (ignore, response) {
                dialog.$el.find('.model-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        var dialog = this;

        this.model = model;

        dialog.$el.find('#editOrganizationName').val('');

        dialog.$el.find('.model-error').addClass('hidden');

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#editOrganizationName').focus();
        });

        sw.lazyFetch(sw.organizations, function () {
            var items = sw.organizations.pluck('name');
            dialog.$el.find('#editOrganizationName').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#editOrganizationName').removeAttr('data-org-id');
                        return;
                    }
                    var org = sw.organizations.findWhere({name: ui.item.label});
                    dialog.$el.find('#editOrganizationName').attr('data-org-id', org.get('id'));
                },
            });
        });

        this.$el.modal('show');
    },
});

sw.EditTaskModal = Backbone.View.extend({

    el: '#editTaskModal',

    model: null,

    events: {
        'click .save-button': 'save',
    },

    save: function () {
        var dialog = this;

        this.model.save({
            task_title: this.$el.find('#editTaskName').val(),
            task_id: this.$el.find('#editTaskName').attr('data-task-id'),
        }, {
            wait: true,
            success: function () {
                dialog.$el.modal('hide');
            },
            error: function (ignore, response) {
                dialog.$el.find('.model-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        var dialog = this;

        this.model = model;

        dialog.$el.find('#editTaskName').val('');

        dialog.$el.find('.model-error').addClass('hidden');

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#editTaskName').focus();
        });

        sw.lazyFetch(sw.tasks, function () {
            var items = sw.tasks.pluck('name');
            dialog.$el.find('#editTaskName').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#editTaskName').removeAttr('data-task-id');
                        return;
                    }
                    var task = sw.tasks.findWhere({name: ui.item.label});
                    dialog.$el.find('#editTaskName').attr('data-task-id', task.get('id'));
                },
            });
        });

        this.$el.modal('show');
    },
});

sw.ActivityNameModal = Backbone.View.extend({

    el: '#activityNameModal',

    model: null,

    events: {
        'click .save-activity-button': 'save',
    },

    save: function () {
        var modal = this;

        this.model.save({
            name: this.$el.find('#activityName').val(),
        }, {
            wait: true,
            success: function () {
                modal.$el.modal('hide');
            },
            error: function (ignore, response) {
                modal.$el.find('.activity-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model) {
        this.model = model;

        this.$el.find('.activity-error').addClass('hidden');

        this.$el.find('#activityName').val(this.model.get('name'));

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#activityName').focus();
        });

        this.$el.modal('show');
    },
});

sw.ActivityView = Backbone.View.extend({

    el: '.activity-view',

    model: null,

    userDropdown: $('.activity-user-dropdown'),
    userTemplate: _.template($('#activity-user-template').html()),

    typeDropdown: $('.activity-type-dropdown'),
    typeTemplate: _.template($('#activity-type-template').html()),

    initialize: function () {
        sw.activities.on("change", this.updateActivity, this);

        sw.companyUsers.on("add", this.renderUser, this);

        sw.activityTypes.on("add", this.renderActivityType, this);

        this.$el.find('#activityDate').datepicker({
            autoclose: true,
        });

        var view = this;

        this.$el.find('#activityDate').datepicker().on('changeDate', function () {
            view.setDueDate();
        });

        this.$el.find('#activityTime').change(function () {
            view.setDueDate();
        });

        this.$el.find('#activityDuration').change(function () {
            view.model.save({duration: view.$el.find('#activityDuration').val()});
        });
    },

    events: {
        'click .activity-name': 'editActivityName',
        'click .activity-user': 'selectUser',
        'click .select-org-button': 'selectOrg',
        'click .select-person-button': 'selectPerson',
        'click .select-task-button': 'selectTask',
        'click .clear-org-button': 'clearOrg',
        'click .clear-person-button': 'clearPerson',
        'click .clear-task-button': 'clearTask',
        'click .delete-activity-button': 'deleteActivity',
        'click .activity-type': 'selectType',
        'click #activityDone': 'activityDone',
    },

    activityDone: function () {
        var newValue = new Date();
        if (this.model.get('marked_as_done_time')) {
            newValue = null;
        }
        this.model.save({
            marked_as_done_time: newValue,
        });
    },

    setDueDate: function (view) {
        if (this.settingDate) {
            return;
        }

        var dateInput = this.$el.find('#activityDate').datepicker('getDate'),
            timeInput = this.$el.find('#activityTime').val(),
            time = moment(timeInput, ['h:m a', 'H:m']),
            date = moment(dateInput),
            datetime = moment();

        if (!dateInput) {
            this.model.save({due_date: null});
            return;
        }

        if (date.isValid()) {
            datetime.set({
                'year': date.year(),
                'month': date.month(),
                'date': date.date()
            });
        }

        if (time.isValid()) {
            datetime.set({
                'hour': time.hour(),
                'minute': time.minute(),
                'second': 0,
                'millisecond': 0,
            });
        }

        this.model.save({due_date: datetime});
    },

    deleteActivity: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }

        var model = this.model;

        this.model.destroy({
            wait: true,
            success: function () {
                sw.activities.remove(model);
                sw.router.navigate('/activities', {trigger: true});
            },
        });
    },

    clearOrg: function () {
        this.model.save({
            org_id: null,
            org_name: null,
        });
    },

    clearPerson: function () {
        this.model.save({
            person_id: null,
            person_name: null,
        });
    },

    clearTask: function () {
        this.model.save({
            task_id: null,
            task_title: null,
        });
    },

    selectOrg: function () {
        sw.editOrganizationModal.render(this.model);
    },

    selectPerson: function () {
        sw.editTaskPersonModal.render(this.model);
    },

    selectTask: function () {
        sw.editTaskModal.render(this.model);
    },

    selectType: function (event) {
        event.preventDefault();

        this.model.save({
            type_id: $(event.target).closest('.activity-type').attr('data-activity-type-id'),
        });
    },

    selectUser: function (event) {
        event.preventDefault();

        var userID = $(event.target).closest('.activity-user').attr('data-user-id');

        this.model.save({
            assigned_to_user_id: userID,
        });
    },

    renderUser: function (model) {
        this.userDropdown.append(this.userTemplate(model.attributes));
    },

    renderActivityType: function (model) {
        var data = _.clone(model.attributes);
        data.label = sw.translate(data.name);
        this.typeDropdown.append(this.typeTemplate(data));
    },

    editActivityName: function (event) {
        event.preventDefault();

        sw.activityNameModal.render(this.model);
    },

    render: function (id) {
        var view = this;

        sw.lazyFetch(sw.companyUsers);

        sw.lazyFetch(sw.activities, function () {
            view.model = sw.activities.get(id);
            view.renderActivity();
        });

        sw.lazyFetch(sw.activityTypes);
    },

    updateActivity: function (model) {
        if (!this.model) {
            return;
        }
        if (this.model.get('id') !== model.get('id')) {
            return;
        }

        this.renderActivity();
    },

    renderActivity: function () {
        this.$el.find('.activity-name').text(this.model.get('name'));

        this.$el.find('.activity-user-name').text(this.model.get('assigned_to_user_name'));

        this.$el.find('.organization-name').text(this.model.get('org_name'));
        this.$el.find('.organization-name').attr('href', '#organization/' + this.model.get('org_id'));

        this.$el.find('.person-name').text(this.model.get('person_name'));
        this.$el.find('.person-name').attr('href', '#person/' + this.model.get('person_id'));

        this.$el.find('.task-name').text(this.model.get('task_title'));
        this.$el.find('.task-name').attr('href', '#task/' + this.model.get('task_id'));

        this.$el.find('.activity-type-name').text(sw.translate(this.model.get('type')));

        this.$el.find('#activityDone').prop('checked', !!this.model.get('marked_as_done_time'));

        this.settingDate = true;

        var m = moment(this.model.get('due_date'));

        if (this.model.get('due_date')) {
            this.$el.find('#activityDate').datepicker('setDate', m.toDate());
            this.$el.find('#activityTime').val(m.format('HH:mm'));
        } else {
            this.$el.find('#activityDate').datepicker('setDate', null);
            this.$el.find('#activityTime').val('');
        }

        this.$el.find('#activityDuration').val(this.model.get('duration'));

        this.settingDate = false;

        this.$el.removeClass('hidden');
    }
});

sw.TimeEntryView = Backbone.View.extend({

    el: '.time-entry-view',

    model: null,

    events: {
        'click .delete-time-entry-button': 'deleteTimeEntry',
        'click .continue-time-entry': 'continueTimeEntry',
    },

    render: function (id) {
        var view = this;

        this.model = new sw.TimeEntry({id: id});
        this.model.fetch({
            wait: true,
            success: function () {
                view.renderTimeEntry();
            },
        });
    },

    renderTimeEntry: function () {
        this.$el.find('.time-entry-name').text(this.model.get('name') || sw.translate('(no description)'));

        this.$el.removeClass('hidden');
    },

    continueTimeEntry: function () {
        var model = new sw.TimeEntry();

        model.save({
            name: this.model.get('name'),
            started_at: new Date(),
        }, {
            wait: true,
            success: function () {
                sw.timeEntries.add(model);
                sw.router.navigate('/work', {trigger: true});
            },
        });
    },

    deleteTimeEntry: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }

        var model = this.model;

        this.model.destroy({
            wait: true,
            success: function () {
                sw.timeEntries.remove(model);
                sw.router.navigate('/work', {trigger: true});
            },
        });
    },
});

sw.PersonView = Backbone.View.extend({

    el: '.person-view',

    model: null,

    userDropdown: $('.person-user-dropdown'),
    userTemplate: _.template($('#person-user-template').html()),

    notesList: $('.notes-list'),
    noteTemplate: _.template($('#person-note-template').html()),

    activityList: $('.activity-list'),
    activityTemplate: _.template($('#person-activity-template').html()),

    taskList: $('.tasks-list'),
    taskTemplate: _.template($("#person-task-template").html()),

    contactList: $('.contact-list'),
    contactTemplate: _.template($("#person-contact-template").html()),

    initialize: function () {
        sw.people.on("change", this.updatePerson, this);

        sw.companyUsers.on("add", this.renderUser, this);

        sw.personNotes.on("reset", this.resetNotes, this);
        sw.personNotes.on("add", this.renderNote, this);
        sw.personNotes.on("remove", this.removeNote, this);

        sw.personTasks.on("reset", this.resetTasks, this);
        sw.personTasks.on("add", this.renderTask, this);
        sw.personTasks.on("remove", this.removeTask, this);

        sw.personActivities.on("reset", this.resetActivities, this);
        sw.personActivities.on("add", this.renderActivity, this);
        sw.personActivities.on("remove", this.removeActivity, this);

        sw.personContacts.on("reset", this.resetContacts, this);
        sw.personContacts.on("add", this.renderContact, this);
        sw.personContacts.on("remove", this.removeContact, this);
        sw.personContacts.on("change", this.updateContact, this);
    },

    events: {
        'click .delete-person-button': 'deletePerson',
        'click .person-name': 'editPersonName',
        'click .person-user': 'selectUser',
        'click .clear-org-button': 'clearOrg',
        'click .select-org-button': 'selectOrg',
        'click .add-note-button': 'addNote',
        'click .add-person-activity-button': 'addActivity',
        'click .add-person-task-button': 'addTask',
        'click .delete-note-button': 'deleteNote',
        'click .add-contact-button': 'addContact',
        'click .edit-contact': 'editContact',
    },

    editContact: function (event) {
        event.preventDefault();

        var tr = $(event.target).closest('tr'),
            id = tr.attr('data-contact-id'),
            model = sw.personContacts.get(id);

        sw.contactModal.render(model);
    },

    resetContacts: function () {
        this.contactList.empty();
    },

    updateContact: function (model) {
        if (this.model.get('id') !== model.get('person_id')) {
            return;
        }
        this.contactList.find('[data-contact-id="' + model.get('id') + '"]').replaceWith(this.contactTemplate(model.attributes));
    },

    renderContact: function (model) {
        this.contactList.append(this.contactTemplate(model.attributes));
    },

    removeContact: function (model) {
        this.contactList.find('[data-contact-id="' + model.get('id') + '"]').remove();
    },

    addContact: function () {
        var model = new sw.Contact({person_id: this.model.get('id')});
        sw.contactModal.render(model);
    },

    deleteNote: function (event) {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var noteID = $(event.target).closest('.panel').attr('data-note-id'),
            model = sw.personNotes.get(noteID);

        model.destroy({
            wait: true,
            success: function () {
                sw.personNotes.remove(model);
            },
        });
    },

    addTask: function () {
        sw.taskModal.render({
            person_id: this.model.get('id'),
            person_name: this.model.get('name'),
            collection: sw.personTasks,
        });
    },

    resetActivities: function () {
        this.activityList.empty();
    },

    renderActivity: function (model) {
        var data = _.clone(model.attributes);
        if (data.due_date) {
            data.due_time = moment(data.due_date).format(sw.longDateFormat());
        } else {
            data.due_time = '';
        }
        if (data.marked_as_done_time) {
            data.done_class = "";
        } else {
            data.done_class = "hidden";
        }
        data.emails = sw.emails(data.person_email);
        data.phones = sw.phones(data.person_phone);
        this.activityList.append(this.activityTemplate(data));
    },

    resetTasks: function () {
        this.taskList.empty();
    },

    renderTask: function (model) {
        var data = _.clone(model.attributes);
        if (data.expected_close_date) {
            data.expected_close_time = moment(data.expected_close_date).format(sw.shortDateFormat());
        } else {
            data.expected_close_time = null;
        }
        if (data.next_activity_date) {
            data.next_activity_time = moment(data.next_activity_date).format(sw.longDateFormat());
        } else {
            data.next_activity_time = '';
        }
        this.taskList.append(this.taskTemplate(data));
    },

    addActivity: function () {
        sw.newActivityModal.render(sw.personActivities, {
            person_id: this.model.get('id'),
            person_name: this.model.get('name'),
        });
    },

    addNote: function () {
        var model = new sw.Note(),
            view = this;

        model.save({
            name: this.$el.find('.notes-editor').val(),
            person_id: this.model.get('id'),
        }, {
            wait: true,
            success: function () {
                view.$el.find('.notes-editor').val('');

                sw.personNotes.add(model);
            }
        });
    },

    resetNotes: function () {
        this.notesList.empty();
    },

    removeNote: function (model) {
        this.$el.find('.panel[data-note-id="' + model.get('id') + '"]').remove();
    },

    renderNote: function (model) {
        var data = _.clone(model.attributes);
        data.created_time = moment(data.created_at).format(sw.longDateFormat());
        data.delete_label = sw.translate('Delete');
        this.notesList.append(this.noteTemplate(data));
    },

    clearOrg: function () {
        this.model.save({
            org_id: null,
            org_name: null,
        });
    },

    selectOrg: function () {
        sw.editOrganizationModal.render(this.model);
    },

    selectUser: function (event) {
        event.preventDefault();

        var userID = $(event.target).closest('.person-user').attr('data-user-id');

        this.model.save({
            owner_id: userID,
        });
    },

    renderUser: function (model) {
        this.userDropdown.append(this.userTemplate(model.attributes));
    },

    updatePerson: function (model) {
        if (this.model && this.model.get('id') === model.get('id')) {
            this.renderPerson();
        }
    },

    editPersonName: function (event) {
        event.preventDefault();

        sw.personNameModal.render(this.model);
    },

    deletePerson: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }

        var model = this.model;

        this.model.destroy({
            wait: true,
            success: function () {
                sw.people.remove(model);
                sw.router.navigate('/people', {trigger: true});
            },
        });
    },

    render: function (id) {
        var view = this;

        sw.lazyFetch(sw.people, function () {
            view.model = sw.people.get(id);
            view.renderPerson();
        });

        sw.lazyFetch(sw.companyUsers);

        sw.personNotes.reset();
        sw.personNotes.fetch(
            {
                data: {
                    person_id: id,
                }
            }
        );

        sw.personTasks.reset();
        sw.personTasks.fetch(
            {
                data: {
                    person_id: id,
                }

            }
        );

        sw.personActivities.reset();
        sw.personActivities.fetch(
            {
                data: {
                    person_id: id,
                }

            }
        );

        sw.personContacts.reset();
        sw.personContacts.fetch(
            {
                data: {
                    person_id: id,
                }
            }
        );
    },

    renderPerson: function () {
        this.$el.find('.person-name').text(this.model.get('name'));
        this.$el.find('.person-user-name').text(this.model.get('owner_name'));

        this.$el.find('.organization-name').text(this.model.get('org_name'));
        this.$el.find('.organization-name').attr('href', '#organization/' + this.model.get('org_id'));

        this.$el.removeClass('hidden');
    }
});

sw.OrganizationView = Backbone.View.extend({

    el: '.organization-view',

    model: null,

    userDropdown: $('.organization-user-dropdown'),
    userTemplate: _.template($('#organization-user-template').html()),

    notesList: $('.notes-list'),
    noteTemplate: _.template($('#organization-note-template').html()),

    activityList: $('.activity-list'),
    activityTemplate: _.template($('#organization-activity-template').html()),

    taskList: $('.tasks-list'),
    taskTemplate: _.template($("#organization-task-template").html()),

    personList: $('.people-list'),
    personTemplate: _.template($("#organization-person-template").html()),

    initialize: function () {
        sw.organizations.on("change", this.updateOrganization, this);

        sw.companyUsers.on("add", this.renderUser, this);

        sw.organizationNotes.on("reset", this.resetNotes, this);
        sw.organizationNotes.on("add", this.renderNote, this);
        sw.organizationNotes.on("remove", this.removeNote, this);

        sw.organizationTasks.on("reset", this.resetTasks, this);
        sw.organizationTasks.on("add", this.renderTask, this);
        sw.organizationTasks.on("remove", this.removeTask, this);

        sw.organizationActivities.on("reset", this.resetActivities, this);
        sw.organizationActivities.on("add", this.renderActivity, this);
        sw.organizationActivities.on("remove", this.removeActivity, this);

        sw.organizationPeople.on("reset", this.resetPeople, this);
        sw.organizationPeople.on("add", this.renderPerson, this);
        sw.organizationPeople.on("remove", this.removePerson, this);

        var view = this;
        this.$el.find('#organizationAddress').change(function () {
            view.setAddress();
        });
    },

    events: {
        'click .delete-organization-button': 'deleteOrganization',
        'click .organization-name': 'editOrganizationName',
        'click .organization-user': 'selectUser',
        'click .add-note-button': 'addNote',
        'click .add-organization-activity-button': 'addActivity',
        'click .add-organization-task-button': 'addTask',
        'click .add-person-button': 'addPerson',
        'click .delete-note-button': 'deleteNote',
    },

    setAddress: function () {
        this.model.save({
            address: this.$el.find('#organizationAddress').val(),
        });
    },

    deleteNote: function (event) {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var noteID = $(event.target).closest('.panel').attr('data-note-id'),
            model = sw.organizationNotes.get(noteID);

        model.destroy({
            wait: true,
            success: function () {
                sw.organizationNotes.remove(model);
            },
        });
    },

    addPerson: function () {
        var model = new sw.Person({
            org_id: this.model.get('id'),
            org_name: this.model.get('name'),
        });
        sw.newPersonModal.render(model, sw.organizationPeople);
    },

    addTask: function () {
        sw.taskModal.render({
            org_id: this.model.get('id'),
            org_name: this.model.get('name'),
            collection: sw.organizationTasks,
        });
    },

    resetActivities: function () {
        this.activityList.empty();
    },

    renderActivity: function (model) {
        var data = _.clone(model.attributes);
        if (data.due_date) {
            data.due_time = moment(data.due_date).format(sw.longDateFormat());
        } else {
            data.due_time = '';
        }
        if (data.marked_as_done_time) {
            data.done_class = "";
        } else {
            data.done_class = "hidden";
        }
        data.emails = sw.emails(data.person_email);
        data.phones = sw.phones(data.person_phone);
        this.activityList.append(this.activityTemplate(data));
    },

    resetTasks: function () {
        this.taskList.empty();
    },

    renderTask: function (model) {
        var data = _.clone(model.attributes);
        if (data.expected_close_date) {
            data.expected_close_time = moment(data.expected_close_date).format(sw.shortDateFormat());
        } else {
            data.expected_close_time = null;
        }
        if (data.next_activity_date) {
            data.next_activity_time = moment(data.next_activity_date).format(sw.longDateFormat());
        } else {
            data.next_activity_time = '';
        }
        this.taskList.append(this.taskTemplate(data));
    },

    addActivity: function () {
        sw.newActivityModal.render(sw.organizationActivities, {
            org_id: this.model.get('id'),
            org_name: this.model.get('name'),
        });
    },

    addNote: function () {
        var model = new sw.Note(),
            view = this;

        model.save({
            name: this.$el.find('.notes-editor').val(),
            org_id: this.model.get('id'),
        }, {
            wait: true,
            success: function () {
                view.$el.find('.notes-editor').val('');

                sw.organizationNotes.add(model);
            }
        });
    },

    resetNotes: function () {
        this.notesList.empty();
    },

    removeNote: function (model) {
        this.$el.find('.panel[data-note-id="' + model.get('id') + '"]').remove();
    },

    renderNote: function (model) {
        var data = _.clone(model.attributes);
        data.created_time = moment(data.created_at).format(sw.longDateFormat());
        data.delete_label = sw.translate('Delete');
        this.notesList.append(this.noteTemplate(data));
    },

    resetPeople: function () {
        this.personList.empty();
    },

    renderPerson: function (model) {
        var data = _.clone(model.attributes);
        if (data.next_activity_date) {
            data.next_activity_time = moment(data.next_activity_date).format(sw.longDateFormat());
        } else {
            data.next_activity_time = '';
        }
        data.emails = sw.emails(data.email);
        data.phones = sw.phones(data.phone);
        this.personList.append(this.personTemplate(data));
    },

    selectUser: function (event) {
        event.preventDefault();

        var userID = $(event.target).closest('.organization-user').attr('data-user-id');

        this.model.save({
            owner_id: userID,
        });
    },

    renderUser: function (model) {
        this.userDropdown.append(this.userTemplate(model.attributes));
    },

    updateOrganization: function (model) {
        if (this.model && this.model.get('id') === model.get('id')) {
            this.renderOrganization();
        }
    },

    editOrganizationName: function (event) {
        event.preventDefault();

        sw.organizationNameModal.render(this.model);
    },

    deleteOrganization: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }

        var model = this.model;

        this.model.destroy({
            wait: true,
            success: function () {
                sw.people.remove(model);
                sw.router.navigate('/organizations', {trigger: true});
            },
        });
    },

    render: function (id) {
        var view = this;

        sw.lazyFetch(sw.organizations, function () {
            view.model = sw.organizations.get(id);
            view.renderOrganization();
        });

        sw.lazyFetch(sw.companyUsers);

        sw.organizationNotes.reset();
        sw.organizationNotes.fetch(
            {
                data: {
                    org_id: id,
                }
            }
        );

        sw.organizationTasks.reset();
        sw.organizationTasks.fetch(
            {
                data: {
                    org_id: id,
                }

            }
        );

        sw.organizationActivities.reset();
        sw.organizationActivities.fetch(
            {
                data: {
                    org_id: id,
                }

            }
        );

        sw.organizationPeople.reset();
        sw.organizationPeople.fetch(
            {
                data: {
                    org_id: id,
                }
            }
        );
    },

    renderOrganization: function () {
        this.$el.find('.organization-name').text(this.model.get('name'));

        this.$el.find('.organization-user-name').text(this.model.get('owner_name'));

        this.$el.find('#organizationAddress').val(this.model.get('address'));

        this.$el.removeClass('hidden');
    }
});

sw.TaskView = Backbone.View.extend({

    el: '.task-view',

    workflowStageDropdown: $('.workflow-stage-dropdown'),
    workflowStageTemplate: _.template($('#workflow-stage-template').html()),

    notesList: $('.notes-list'),
    noteTemplate: _.template($('#note-template').html()),

    activityList: $('.activity-list'),
    activityTemplate: _.template($('#activity-template').html()),

    userDropdown: $('.task-user-dropdown'),
    userTemplate: _.template($('#task-user-template').html()),

    model: null,

    settingDate: false,

    initialize: function () {
        sw.tasks.on("change", this.updateTask, this);

        sw.stages.on("add", this.renderStage, this);

        sw.taskNotes.on("reset", this.resetNotes, this);
        sw.taskNotes.on("add", this.renderNote, this);
        sw.taskNotes.on("remove", this.removeNote, this);

        sw.taskActivities.on("reset", this.resetActivities, this);
        sw.taskActivities.on("add", this.renderActivity, this);

        sw.companyUsers.on("add", this.renderUser, this);

        this.$el.find('#expectedCloseDate').datepicker({
            autoclose: true,
        });

        var view = this;

        this.$el.find('#expectedCloseDate').datepicker().on('changeDate', function (e) {
            if (view.settingDate) {
                return;
            }
            view.model.save({expected_close_date: e.date});
        });
    },

    events: {
        'click .task-name': 'editTaskName',
        'click .task-value': 'editTaskValue',
        'click .task-workflow-stage': 'selectStage',
        'click .success-button': 'success',
        'click .failed-button': 'failed',
        'click .reopen-button': 'reopen',
        'click .select-org-button': 'selectOrg',
        'click .clear-org-button': 'clearOrg',
        'click .select-person-button': 'selectPerson',
        'click .clear-person-button': 'clearPerson',
        'click .add-note-button': 'addNote',
        'click .delete-note-button': 'deleteNote',
        'click .add-task-activity-button': 'addActivity',
        'click .task-user': 'selectUser',
        'click .delete-task-button': 'deleteTask',
    },

    deleteTask: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }

        var model = this.model;

        this.model.destroy({
            wait: true,
            success: function () {
                sw.tasks.remove(model);
                sw.router.navigate('/tasks', {trigger: true});
            },
        });
    },

    selectUser: function (event) {
        event.preventDefault();

        var userID = $(event.target).closest('.task-user').attr('data-user-id');

        this.model.save({
            user_id: userID,
        });
    },

    renderUser: function (model) {
        this.userDropdown.append(this.userTemplate(model.attributes));
    },

    resetActivities: function () {
        this.activityList.empty();
    },

    renderActivity: function (model) {
        var data = _.clone(model.attributes);
        if (data.due_date) {
            data.due_time = moment(data.due_date).format(sw.longDateFormat());
        } else {
            data.due_time = '';
        }
        if (data.marked_as_done_time) {
            data.done_class = "";
        } else {
            data.done_class = "hidden";
        }
        data.emails = sw.emails(data.person_email);
        data.phones = sw.phones(data.person_phone);
        this.activityList.append(this.activityTemplate(data));
    },

    addActivity: function () {
        sw.newActivityModal.render(sw.taskActivities, {
            task_id: this.model.get('id'),
            task_title: this.model.get('name'),
        });
    },

    deleteNote: function (event) {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var noteID = $(event.target).closest('.panel').attr('data-note-id'),
            model = sw.taskNotes.get(noteID);

        model.destroy({
            wait: true,
            success: function () {
                sw.taskNotes.remove(model);
            },
        });
    },

    removeNote: function (model) {
        this.$el.find('.panel[data-note-id="' + model.get('id') + '"]').remove();
    },

    addNote: function () {
        var model = new sw.Note(),
            view = this;

        model.save({
            name: this.$el.find('.notes-editor').val(),
            task_id: this.model.get('id'),
        }, {
            wait: true,
            success: function () {
                view.$el.find('.notes-editor').val('');

                sw.taskNotes.add(model);
            }
        });
    },

    selectOrg: function () {
        sw.editOrganizationModal.render(this.model);
    },

    clearOrg: function () {
        this.model.save({
            org_id: null,
            org_name: null,
        });
    },

    selectPerson: function () {
        sw.editTaskPersonModal.render(this.model);
    },

    clearPerson: function () {
        this.model.save({
            person_id: null,
            person_name: null,
        });
    },

    reopen: function () {
        this.model.save({
            won_time: null,
            lost_time: null,
        });
    },

    success: function () {
        this.model.save({
            won_time: new Date(),
        });
    },

    failed: function () {
        this.model.save({
            lost_time: new Date(),
        });
    },

    resetNotes: function () {
        this.notesList.empty();
    },

    renderNote: function (model) {
        var data = _.clone(model.attributes);
        data.created_time = moment(data.created_at).format(sw.longDateFormat());
        data.delete_label = sw.translate('Delete');
        this.notesList.append(this.noteTemplate(data));
    },

    renderStage: function (model) {
        this.workflowStageDropdown.append(this.workflowStageTemplate(model.attributes));
    },

    selectStage: function (event) {
        event.preventDefault();

        this.model.save({
            stage_id: $(event.target).closest('li').attr('data-workflow-stage-id'),
        });
    },

    updateTask: function (model) {
        if (!this.model) {
            return;
        }
        if (model.get('id') !== this.model.get('id')) {
            return;
        }
        this.renderTask();
    },

    editTaskName: function (event) {
        event.preventDefault();

        sw.taskNameModal.render(this.model);
    },

    editTaskValue: function (event) {
        event.preventDefault();

        sw.taskValueModal.render(this.model);
    },

    render: function (id) {
        var view = this;

        sw.taskNotes.reset();
        sw.taskNotes.fetch(
            {
                data: {
                    task_id: id,
                }
            }
        );

        sw.taskActivities.reset();
        sw.taskActivities.fetch(
            {
                data: {
                    task_id: id,
                }

            }
        );

        sw.lazyFetch(sw.stages, function () {
            sw.lazyFetch(sw.tasks, function () {
                view.model = sw.tasks.get(id);

                view.renderTask();

                view.$el.removeClass('hidden');
            });
        });

        sw.lazyFetch(sw.companyUsers);
    },

    renderTask: function () {
        this.$el.find('.task-user-name').text(this.model.get('owner_name'));

        this.$el.find('.task-name').text(this.model.get('name'));
        this.$el.find('.task-value').text(this.model.get('value') + ' ' + this.model.get('currency'));

        this.$el.find('.organization-name').text(this.model.get('org_name'));
        this.$el.find('.organization-name').attr('href', '#organization/' + this.model.get('org_id'));

        this.$el.find('.person-name').text(this.model.get('person_name'));
        this.$el.find('.person-name').attr('href', '#person/' + this.model.get('person_id'));

        this.$el.find('.task-workflow-stage-name').text(this.model.get('stage_name'));

        if (this.model.get('won_time') || this.model.get('lost_time')) {
            this.$el.find('.success-button').closest('div').addClass('hidden');
            this.$el.find('.failed-button').closest('div').addClass('hidden');
            this.$el.find('.reopen-button').closest('div').removeClass('hidden');
        } else {
            this.$el.find('.success-button').closest('div').removeClass('hidden');
            this.$el.find('.failed-button').closest('div').removeClass('hidden');
            this.$el.find('.reopen-button').closest('div').addClass('hidden');
        }

        if (this.model.get('won_time')) {
            this.$el.find('.success-label').closest('div').removeClass('hidden');
            this.$el.find('.success-at').removeClass('hidden');
            this.$el.find('.success-at').find('.value').text(moment(this.model.get('won_time')).format(sw.shortDateFormat()));
        } else {
            this.$el.find('.success-label').closest('div').addClass('hidden');
            this.$el.find('.success-at').addClass('hidden');
        }

        if (this.model.get('lost_time')) {
            this.$el.find('.failed-label').closest('div').removeClass('hidden');
            this.$el.find('.failed-at').removeClass('hidden');
            this.$el.find('.failed-at').find('.value').text(moment(this.model.get('lost_time')).format(sw.shortDateFormat()));
        } else {
            this.$el.find('.failed-label').closest('div').addClass('hidden');
            this.$el.find('.failed-at').addClass('hidden');
        }

        if (this.model.get('org_id')) {
            this.$el.find('.clear-org-button').removeClass('hidden');
        } else {
            this.$el.find('.clear-org-button').addClass('hidden');
        }

        if (this.model.get('person_id')) {
            this.$el.find('.clear-person-button').removeClass('hidden');
        } else {
            this.$el.find('.clear-person-button').addClass('hidden');
        }

        this.settingDate = true;
        if (this.model.get('expected_close_date')) {
            this.$el.find('#expectedCloseDate').datepicker('setDate',
                moment(this.model.get('expected_close_date')).toDate());
        } else {
            this.$el.find('#expectedCloseDate').datepicker('setDate', null);
        }
        this.settingDate = false;
    },
});

sw.BoardView = sw.FilteredView.extend({

    el: '.board-view',

    workflowTemplate: _.template($("#board-workflow-menu-item-template").html()),
    workflowDropdown: $('.board-workflow-dropdown'),

    boardTableTasks: $('.board-table-tasks'),
    boardStageTasksTemplate: _.template($("#board-stage-tasks-template").html()),

    boardStages: $('.board-table-stages'),
    stageTemplate: _.template($("#board-stage-template").html()),

    taskTemplate: _.template($('#board-task-template').html()),

    initialize: function () {
        this.boardStages.empty();
        this.boardTableTasks.empty();

        sw.tasks.on("reset", this.resetTasks, this);
        sw.tasks.on("add", this.renderTask, this);
        sw.tasks.on("change", this.updateTaskOnBoard, this);

        sw.workflows.on("reset", this.resetWorkflows, this);
        sw.workflows.on("add", this.renderWorkflow, this);
        sw.workflows.on("change", this.updateWorkflow, this);

        sw.stages.on("reset", this.resetStages, this);
        sw.stages.on("add", this.renderStage, this);

        sw.on(sw.events.userLoggedIn, this.renderActiveWorkflow, this);
    },

    events: {
        'click .add-task-button': 'addTask',
        'click .workflow-selection-item': 'selectWorkflow',
        'click .board-table-tasks td': 'addTaskToStage',
        'click .only-active-tasks': 'filterOnlyActiveTasks',
    },

    updateWorkflow: function (model) {
        var el = this.$el.find('.current-workflow-name');
        if (el.attr('data-workflow-id') === model.get('id')) {
            el.text(model.get('name'));
        }

        this.workflowDropdown.find('[data-workflow-id="' + model.get('id') + '"]').replaceWith(this.workflowTemplate(model.attributes));
    },

    resetTasks: function (models) {
        this.boardTableTasks.find('ul').empty();
        if (!models) {
            return;
        }
        var view = this;
        models.each(function (model) {
            view.renderTask(model);
        });
    },

    addTaskToStage: function (event) {
        var target = $(event.target),
            td,
            th;
        if (!target.is('td')) {
            return;
        }

        event.preventDefault();

        td = target;
        th = td.closest('table').find("thead tr th").eq(td.index());

        sw.taskModal.render({
            stage_id: td.attr('data-stage-id'),
            stage_name: th.text(),
        });
    },

    resetStages: function () {
        this.boardStages.empty();
        this.boardTableTasks.empty();
    },

    ondragstart: function (event) {
        var taskID = $(event.target).closest('li').attr('data-task-id');
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", taskID);
    },

    ondragover: function (event) {
        event.stopPropagation();
        event.preventDefault();
    },

    ondrop: function (event) {
        event.stopPropagation();
        event.preventDefault();
        var column = $(event.target).closest('td'),
            stageID = column.attr('data-stage-id'),
            taskID = event.dataTransfer.getData("text/plain"),
            task = sw.tasks.get(taskID);
        task.save({stage_id: stageID});

        sw.tutorialDone('dragTask');
    },

    updateTaskOnBoard: function (model) {
        var li = this.$el.find('li[data-task-id="' + model.get('id') + '"]');
        li.remove();
        this.renderTask(model);
    },

    renderTask: function (model) {
        var td = this.boardTableTasks.find('td[data-stage-id="' + model.get('stage_id') + '"]'),
            data = _.clone(model.attributes);
        data.org_or_person_name = data.org_name || data.person_name;
        if (data.value) {
            data.value_and_currency = data.value + ' ' + data.currency;
        } else {
            data.value_and_currency = '';
        }
        td.find('ul').append(this.taskTemplate(data));
    },

    renderActiveWorkflow: function (model) {
        if (sw.currentUser.get('active_workflow_name')) {
            var el = this.$el.find('.current-workflow-name');
            el.text(sw.currentUser.get('active_workflow_name'));
            el.attr('data-workflow-id', sw.currentUser.get('active_workflow_id'));
        }
    },

    resetWorkflows: function () {
        this.workflowDropdown.empty();
    },

    renderWorkflow: function (model) {
        this.workflowDropdown.append(this.workflowTemplate(model.attributes));
    },

    renderStage: function (model) {
        this.boardStages.append(this.stageTemplate(model.attributes));
        this.boardTableTasks.append(this.boardStageTasksTemplate(model.attributes));
    },

    render: function () {
        this.$el.removeClass('hidden');

        this.renderFilters();

        sw.lazyFetch(sw.workflows);

        var view = this;

        sw.lazyFetch(sw.stages, function () {
            view.fetchTasks();
        });

        sw.showTutorial(this);
    },

    selectWorkflow: function (event) {
        event.preventDefault();

        var li = $(event.target).closest('li'),
            workflowID = li.attr('data-workflow-id'),
            view = this;

        sw.currentUser.save(
            {'active_workflow_id': workflowID},
            {
                wait: true,
                success: function () {
                    var el = $('.current-workflow-name');
                    el.text(li.find('a').text());
                    el.attr('data-workflow-id', workflowID);

                    sw.stages.reset();
                    sw.stages.fetch({
                        success: function () {
                            view.fetchTasks();
                        }
                    });
                },
            }
        );
    },

    addTask: function () {
        sw.taskModal.render();
    },
});

sw.TeamView = sw.FilteredView.extend({

    el: '.team-view',

    workflowTemplate: _.template($("#team-workflow-menu-item-template").html()),
    workflowDropdown: $('.team-workflow-dropdown'),

    tableTasks: $('.team-table-tasks'),
    tasksTemplate: _.template($("#team-user-tasks-template").html()),

    teamUsers: $('.team-table-users'),
    userTemplate: _.template($("#team-user-template").html()),

    taskTemplate: _.template($('#team-task-template').html()),

    initialize: function () {
        this.teamUsers.empty();
        this.tableTasks.empty();

        sw.tasks.on("add", this.renderTask, this);
        sw.tasks.on("change", this.updateTask, this);
        sw.tasks.on("reset", this.resetTasks, this);

        sw.workflows.on("reset", this.resetWorkflows, this);
        sw.workflows.on("add", this.renderWorkflow, this);
        sw.workflows.on("change", this.updateWorkflow, this);

        sw.companyUsers.on("reset", this.resetUsers, this);
        sw.companyUsers.on("add", this.renderUser, this);
        sw.companyUsers.on("remove", this.removeUser, this);

        sw.on(sw.events.userLoggedIn, this.renderActiveWorkflow, this);
    },

    events: {
        'click .add-task-button': 'addTask',
        'click .workflow-selection-item': 'selectWorkflow',
        'click .team-table-tasks td': 'addTaskToUser',
        'click .only-active-tasks': 'filterOnlyActiveTasks',
    },

    updateWorkflow: function (model) {
        var el = this.$el.find('.current-workflow-name');
        if (el.attr('data-workflow-id') === model.get('id')) {
            el.text(model.get('name'));
        }

        this.workflowDropdown.find('[data-workflow-id="' + model.get('id') + '"]').replaceWith(this.workflowTemplate(model.attributes));
    },

    addTaskToUser: function (event) {
        var target = $(event.target),
            td,
            th;
        if (!target.is('td')) {
            return;
        }

        event.preventDefault();

        td = target;
        th = td.closest('table').find("thead tr th").eq(td.index());

        sw.taskModal.render({
            user_id: td.attr('data-user-id'),
            owner_name: th.text(),
        });
    },

    resetUsers: function () {
        this.teamUsers.empty();
        this.tableTasks.empty();
    },

    resetTasks: function (models) {
        this.tableTasks.empty();

        var view = this;

        sw.companyUsers.each(function (model) {
            view.tableTasks.append(view.tasksTemplate(model.attributes));
        });

        if (!models) {
            return;
        }

        models.each(function (model) {
            view.renderTask(model);
        });
    },

    ondragstart: function (event) {
        var taskID = $(event.target).closest('li').attr('data-task-id');
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", taskID);
    },

    ondragover: function (event) {
        event.stopPropagation();
        event.preventDefault();
    },

    ondrop: function (event) {
        event.stopPropagation();
        event.preventDefault();
        var column = $(event.target).closest('td'),
            userID = column.attr('data-user-id'),
            taskID = event.dataTransfer.getData("text/plain"),
            task = sw.tasks.get(taskID);
        task.save({user_id: userID});
    },

    updateTask: function (model) {
        var li = this.$el.find('li[data-task-id="' + model.get('id') + '"]');
        li.remove();
        this.renderTask(model);
    },

    renderTask: function (model) {
        var td = this.tableTasks.find('td[data-user-id="' + model.get('user_id') + '"]');
        td.find('ul').append(this.taskTemplate(model.attributes));
    },

    renderActiveWorkflow: function (model) {
        if (sw.currentUser.get('active_workflow_name')) {
            var el = this.$el.find('.current-workflow-name');
            el.text(sw.currentUser.get('active_workflow_name'));
            el.attr('data-workflow-id', sw.currentUser.get('active_workflow_id'));
        }
    },

    resetWorkflows: function () {
        this.workflowDropdown.empty();
    },

    renderWorkflow: function (model) {
        this.workflowDropdown.append(this.workflowTemplate(model.attributes));
    },

    renderUser: function (model) {
        this.teamUsers.append(this.userTemplate(model.attributes));
        this.tableTasks.append(this.tasksTemplate(model.attributes));
    },

    removeUser: function (model) {
        this.teamUsers.find('[data-user-id="' + model.get('user_id') + '"]').remove();
        this.tableTasks.find('[data-user-id="' + model.get('user_id') + '"]').remove();
    },

    render: function () {
        this.$el.removeClass('hidden');

        this.renderFilters();

        sw.lazyFetch(sw.workflows);

        var view = this;

        sw.lazyFetch(sw.companyUsers, function () {
            view.fetchTasks();
        });

        sw.showTutorial(this);
    },

    selectWorkflow: function (event) {
        event.preventDefault();

        var li = $(event.target).closest('li'),
            workflowID = li.attr('data-workflow-id'),
            view = this;

        sw.currentUser.save(
            {'active_workflow_id': workflowID},
            {
                wait: true,
                success: function () {
                    var el = $('.current-workflow-name');
                    el.text(li.find('a').text());
                    el.attr('data-workflow-id', workflowID);

                    view.fetchTasks();
                },
            }
        );
    },

    addTask: function () {
        sw.taskModal.render();
    },
});

sw.PeopleView = Backbone.View.extend({

    el: '.people-view',

    personTemplate: _.template($("#person-row-template").html()),
    peopleTable: $('.people-table-body'),

    initialize: function () {
        sw.people.on("reset", this.resetPersons, this);
        sw.people.on("add", this.renderPerson, this);
        sw.people.on("remove", this.removePerson, this);
        sw.people.on("change", this.updatePerson, this);
    },

    events: {
        'click .add-person-button': 'addPerson',
    },

    removePerson: function (model) {
        this.$el.find('tr[data-person-id="' + model.get('id') + '"]').remove();
    },

    updatePerson: function (model) {
        this.$el.find('tr[data-person-id="' + model.get('id') + '"]').replaceWith(this.renderTemplate(model));
    },

    addPerson: function () {
        var model = new sw.Person();
        sw.newPersonModal.render(model);
    },

    resetPersons: function () {
        this.peopleTable.empty();
    },

    renderTemplate: function (model) {
        var data = _.clone(model.attributes);
        if (data.next_activity_date) {
            data.next_activity_time = moment(data.next_activity_date).format(sw.longDateFormat());
        } else {
            data.next_activity_time = '';
        }
        data.phones = sw.phones(data.phone);
        data.emails = sw.emails(data.phone);
        return this.personTemplate(data);
    },

    renderPerson: function (model) {
        this.peopleTable.append(this.renderTemplate(model));
    },

    render: function () {
        this.$el.removeClass('hidden');

        sw.lazyFetch(sw.people);

        sw.showTutorial(this);
    },
});

sw.emails = function (phone) {
    return _.map(phone.split(', '), function (value) {
        return '<a href="mailto:' + value + '">' + value + '</a>';
    }).join(' ');
};

sw.phones = function (phone) {
    return _.map(phone.split(', '), function (value) {
        return '<a href="callto:' + value + '">' + value + '</a>';
    }).join(' ');
};

sw.WorkView = Backbone.View.extend({

    el: '.work-view',

    template: _.template($("#time-entry-row-template").html()),
    table: $('.time-entries-table'),

    timer: null,
    timerDisplay: $('.timer'),

    initialize: function () {
        sw.timeEntries.on("reset", this.resetTimeEntries, this);
        sw.timeEntries.on("add", this.renderTimeEntry, this);
        sw.timeEntries.on("remove", this.removeTimeEntry, this);
        sw.timeEntries.on("change", this.renderTimeEntry, this);

        var view = this;
        this.timer = window.setInterval(function () {
            view.onTimer();
        }, 1000);

        this.$el.find('.time-entry-filter-row input[type=text]').datepicker({
            autoclose: true,
        });
    },

    events: {
        'click .start-work-button': 'startWork',
        'click .stop-work-button': 'stopWork',
        'change #timeEntryDescription': 'changeDescription',
        'click .apply-filter': 'applyFilter',
        'click .clear-filter': 'clearFilter',
    },

    onTimer: function () {
        var model = sw.timeEntries.findWhere({finished_at: null});
        if (!model) {
            return;
        }
        this.timerDisplay.text(sw.duration(model).format('hh:mm:ss'));
    },

    calculateTotal: function () {
        var start = moment.duration(0),
            total = null,
            totalString = '00:00:00';

        sw.timeEntries.each(function (model) {
            total = start.add(sw.duration(model));
        });

        if (total) {
            totalString = total.format('hh:mm:ss');
        }

        this.table.parent().find('.total-duration').text(totalString);
    },

    changeDescription: function () {
        var model = sw.timeEntries.findWhere({finished_at: null});
        if (!model) {
            return;
        }
        model.save({
            name: this.$el.find('#timeEntryDescription').val(),
        }, {
            wait: true,
            success: function () {
                sw.timeEntries.add(model);
            },
        });
    },

    startWork: function (event) {
        event.preventDefault();

        var model = new sw.TimeEntry();

        model.save({
            name: this.$el.find('#timeEntryDescription').val(),
            started_at: new Date(),
        }, {
            wait: true,
            success: function () {
                sw.timeEntries.add(model);

                sw.tutorialDone('startWork');
            },
        });
    },

    stopWork: function (event) {
        event.preventDefault();

        var model = sw.timeEntries.findWhere({finished_at: null}),
            view = this;

        model.save({
            finished_at: new Date(),
        }, {
            wait: true,
            success: function () {
                view.$el.find('#timeEntryDescription').val('');
                view.$el.find('.start-work-button').removeClass('hidden');
                view.$el.find('.stop-work-button').addClass('hidden');
                view.timerDisplay.addClass('hidden');

                sw.tutorialDone('stopWork');
            },
        });
    },

    resetTimeEntries: function (models) {
        this.table.empty();

        var view = this;

        models.each(function (model) {
            view.renderTimeEntry(model);
        });
    },

    renderTimeEntry: function (model) {
        if (model.get('finished_at')) {
            var row = this.row(model);
            if (row.length) {
                row.replaceWith(this.renderTemplate(model));
            } else {
                this.table.prepend(this.renderTemplate(model));
            }

            this.calculateTotal();

            return;
        }

        this.$el.find('#timeEntryDescription').val(model.get('name'));

        this.$el.find('.start-work-button').addClass('hidden');
        this.$el.find('.stop-work-button').removeClass('hidden');

        this.onTimer();
        this.timerDisplay.removeClass('hidden');
    },

    renderTemplate: function (model) {
        var data = _.clone(model.attributes);
        data.started_time = moment(data.started_at).format(sw.longDateFormat());
        if (data.finished_at) {
            data.finished_time = moment(data.finished_at).format(sw.longDateFormat());
        } else {
            data.finished_time = '';
        }
        if (!data.name) {
            data.name = sw.translate('(no description)');
        }
        data.duration = sw.duration(model).format('hh:mm:ss');
        return this.template(data);
    },

    removeTimeEntry: function (model) {
        this.row(model).remove();

        this.calculateTotal();
    },

    row: function (model) {
        return this.table.find('tr[data-time-entry-id="' + model.get('id') + '"]');
    },

    applyFilter: function () {
        var fromDate = this.$el.find('#timeEntriesFrom').datepicker('getDate'),
            untilDate = this.$el.find('#timeEntriesUntil').datepicker('getDate');

        if (!fromDate) {
            Cookies.remove('time_entries_from');
        } else {
            Cookies.set('time_entries_from', fromDate.getTime());
        }
        if (!untilDate) {
            Cookies.remove('time_entries_until');
        } else {
            Cookies.set('time_entries_until', untilDate.getTime());
        }

        this.fetchTimeEntries();
    },

    clearFilter: function () {
        Cookies.remove('time_entries_from');
        Cookies.remove('time_entries_until');

        this.renderDateRangeFilter();

        this.fetchTimeEntries();
    },

    render: function () {
        this.$el.removeClass('hidden');

        this.fetchTimeEntries();

        this.$el.find('#timeEntryDescription').focus();

        this.renderDateRangeFilter();

        sw.showTutorial(this);
    },

    renderDateRangeFilter: function () {
        var filter = this.loadDateRangeFilter(),
            fromDate = null,
            untilDate = null;

        if (filter.time_entries_from) {
            fromDate = moment(filter.time_entries_from).toDate();
        }

        if (filter.time_entries_until) {
            untilDate = moment(filter.time_entries_until).toDate();
        }

        this.$el.find('#timeEntriesFrom').datepicker('setDate', fromDate);
        this.$el.find('#timeEntriesUntil').datepicker('setDate', untilDate);
    },

    loadDateRangeFilter: function () {
        var data = {},
            from = Cookies.get('time_entries_from'),
            until = Cookies.get('time_entries_until');

        if (from) {
            data.time_entries_from = new Date(parseInt(from, 10)).getTime();
        }
        if (until) {
            data.time_entries_until = new Date(parseInt(until, 10)).getTime();
        }

        return data;
    },

    fetchTimeEntries: function () {
        var data = this.loadDateRangeFilter(),
            exportCSV = this.$el.find('.export-csv'),
            href = exportCSV.attr('data-href');

        if (data.time_entries_from) {
            href = href + '&time_entries_from=' + data.time_entries_from;
        }
        if (data.time_entries_until) {
            href = href + '&time_entries_until=' + data.time_entries_until;
        }
        exportCSV.attr('href', href);

        sw.timeEntries.fetch({
            data: data,
            reset: true,
        });
    },
});

sw.NewUserModal = Backbone.View.extend({

    el: '#newUserModal',

    events: {
        'click .invite-user-button': 'inviteUser',
    },

    inviteUser: function () {
        var companyUser = new sw.CompanyUser({
            name: this.$el.find('#newUserName').val(),
            email: this.$el.find('#newUserEmail').val()
        }),
            dialog = this;
        companyUser.save({}, {
            wait: true,
            success: function () {
                sw.companyUsers.add(companyUser);
                dialog.$el.modal('hide');
                sw.tutorialDone('addUser');
            },
            error: function (ignore, response) {
                dialog.$el.find('.invitation-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function () {
        this.$el.find('#newUserName').val('');
        this.$el.find('#newUserEmail').val('');

        var dialog = this;

        dialog.$el.find('.invitation-error').addClass('hidden');

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newUserName').focus();
        });

        this.$el.modal('show');
    },
});

sw.NewCompanyModal = Backbone.View.extend({

    el: '#newCompanyModal',

    events: {
        'click .save-company-button': 'save',
    },

    save: function () {
        var model = new sw.Company({
            name: this.$el.find('#newCompanyName').val(),
        }),
            dialog = this;
        model.save({}, {
            wait: true,
            success: function () {
                sw.companies.add(model);
                dialog.$el.modal('hide');
                sw.router.navigate('/settings/workflows', {trigger: true});
            },
            error: function (ignore, response) {
                dialog.$el.find('.company-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function () {
        this.$el.find('#newCompanyName').val('');

        this.$el.find('.company-error').addClass('hidden');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newCompanyName').focus();
        });

        this.$el.modal('show');
    },
});

sw.NewPersonModal = Backbone.View.extend({

    el: '#newPersonModal',

    events: {
        'click .save-person-button': 'save',
    },

    collection: null,

    save: function () {
        var dialog = this,
            model = this.model;

        model.save({
            name: this.$el.find('#newPersonName').val(),
            org_id: this.$el.find('#newPersonOrganization').attr('data-org-id'),
            phone: this.$el.find('#newPersonPhone').val(),
            email: this.$el.find('#newPersonEmail').val(),
        }, {
            wait: true,
            success: function () {
                sw.people.add(model);
                if (dialog.collection) {
                    dialog.collection.add(model);
                }
                dialog.$el.modal('hide');

                sw.tutorialDone('addPerson');
            },
            error: function (ignore, response) {
                dialog.$el.find('.person-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (model, collection) {
        this.collection = collection;

        this.model = model;

        this.$el.find('.person-error').addClass('hidden');

        this.$el.find('#newPersonName').val(this.model.get('person_name'));

        this.$el.find('#newPersonPhone').val(this.model.get('phone'));

        this.$el.find('#newPersonEmail').val(this.model.get('email'));

        this.$el.find('#newPersonOrganization').val(this.model.get('org_name'));
        this.$el.find('#newPersonOrganization').attr('data-org-id', this.model.get('org_id'));

        var dialog = this;

        sw.lazyFetch(sw.organizations, function () {
            var items = sw.organizations.pluck('name');
            dialog.$el.find('#newPersonOrganization').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#newPersonOrganization').removeAttr('data-org-id');
                        return;
                    }
                    var org = sw.organizations.findWhere({name: ui.item.label});
                    dialog.$el.find('#newPersonOrganization').attr('data-org-id', org.get('id'));
                },
            });
        });

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newPersonName').focus();
        });

        this.$el.modal('show');
    },
});

sw.NewOrganizationModal = Backbone.View.extend({

    el: '#newOrganizationModal',

    events: {
        'click .save-organization-button': 'save',
    },

    save: function () {
        var model = new sw.Organization({
            name: this.$el.find('#newOrganizationName').val(),
            address: this.$el.find('#newOrganizationAddress').val(),
        }),
            dialog = this;
        model.save({}, {
            wait: true,
            success: function () {
                sw.organizations.add(model);
                dialog.$el.modal('hide');

                sw.tutorialDone('addOrganization');
            },
            error: function (ignore, response) {
                dialog.$el.find('.organization-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function () {
        this.$el.find('#newOrganizationName').val('');

        this.$el.find('#newOrganizationAddress').val('');

        this.$el.find('.organization-error').addClass('hidden');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newOrganizationName').focus();
        });

        this.$el.modal('show');
    },
});

sw.NewWorkflowModal = Backbone.View.extend({

    el: '#newWorkflowModal',

    events: {
        'click .save-workflow-button': 'saveWorkflow',
    },

    saveWorkflow: function () {
        var dialog = this,
            model = new sw.Workflow();
        model.set('name', $('#newWorkflowName').val());
        model.save({}, {
            wait: true,
            success: function () {
                sw.workflows.add(model);
                dialog.$el.modal('hide');
            },
            error: function (ignore, response) {
                dialog.$el.find('.workflow-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function () {
        this.$el.find('#newWorkflowName').val('');

        this.$el.find('.workflow-error').addClass('hidden');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newWorkflowName').focus();
        });

        this.$el.modal('show');
    },
});

sw.EditStageModal = Backbone.View.extend({

    el: '#editStageModal',

    model: null,

    events: {
        'click .save-stage-button': 'saveStage',
        'click .delete-stage-button': 'deleteStage',
    },

    deleteStage: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var dialog = this.$el,
            model = this.model;
        this.model.destroy({
            wait: true,
            success: function () {
                sw.workflowStages.remove(model);
                dialog.modal('hide');
            },
            error: function (ignore, response) {
                dialog.find('.stage-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    saveStage: function () {
        var dialog = this.$el;
        this.model.save(
            {
                name: this.$el.find('#stageName').val()
            },
            {
                wait: true,
                success: function () {
                    dialog.modal('hide');
                },
                error: function (ignore, response) {
                    dialog.find('.stage-error').removeClass('hidden').html(sw.translate(response.responseText));
                },
            }
        );
    },

    render: function (model) {
        this.model = model;

        this.$el.find('#stageName').val(model.get('name'));

        this.$el.find('.stage-error').addClass('hidden');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#stageName').focus();
        });

        this.$el.modal('show');
    },
});

sw.EditWorkflowModal = Backbone.View.extend({

    el: '#editWorkflowModal',

    model: null,

    events: {
        'click .save-workflow-button': 'save',
    },

    save: function () {
        var dialog = this.$el;
        this.model.save(
            {
                name: this.$el.find('#workflowName').val()
            },
            {
                wait: true,
                success: function () {
                    dialog.modal('hide');
                    sw.tutorialDone('editWorkflow');
                },
                error: function (ignore, response) {
                    dialog.find('.workflow-error').removeClass('hidden').html(sw.translate(response.responseText));
                },
            }
        );
    },

    render: function (model) {
        this.model = model;

        this.$el.find('#workflowName').val(model.get('name'));

        this.$el.find('.workflow-error').addClass('hidden');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#workflowName').focus();
        });

        this.$el.modal('show');
    },
});

sw.EditCompanyModal = Backbone.View.extend({

    el: '#editCompanyModal',

    model: null,

    events: {
        'click .save-button': 'save',
    },

    save: function () {
        var dialog = this.$el;
        this.model.save(
            {
                name: this.$el.find('#companyName').val()
            },
            {
                wait: true,
                success: function () {
                    dialog.modal('hide');

                    sw.tutorialDone('editCompany');
                },
                error: function (ignore, response) {
                    dialog.find('.company-error').removeClass('hidden').html(sw.translate(response.responseText));
                },
            }
        );
    },

    render: function (model) {
        this.model = model;

        this.$el.find('#companyName').val(model.get('name'));

        this.$el.find('.company-error').addClass('hidden');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#companyName').focus();
        });

        this.$el.modal('show');
    },
});

sw.NewStageModal = Backbone.View.extend({

    el: '#newStageModal',

    model: null,

    events: {
        'click .save-stage-button': 'saveStage',
    },

    saveStage: function () {
        var dialog = this.$el,
            model = this.model;
        this.model.save(
            {
                name: this.$el.find('#newStageName').val()
            },
            {
                wait: true,
                success: function () {
                    sw.workflowStages.add(model);
                    dialog.modal('hide');
                },
                error: function (ignore, response) {
                    dialog.find('.stage-error').removeClass('hidden').html(sw.translate(response.responseText));
                },
            }
        );
    },

    render: function (model) {
        this.model = model;

        this.$el.find('#newStageName').val('');

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newStageName').focus();
        });

        this.$el.find('.stage-error').addClass('hidden');

        this.$el.modal('show');
    },
});

sw.DeletedDataView = Backbone.View.extend({

    el: '.deleted-data-view',

    template: _.template($('#deleted-data-template').html()),
    table: $('.deleted-data-table'),

    initialize: function () {
        sw.deletedObjects.on("add", this.renderDeletedObject, this);
        sw.deletedObjects.on("reset", this.resetDeletedObjects, this);
        sw.deletedObjects.on("remove", this.removeDeletedObject, this);
    },

    events: {
        'click .undelete-button': 'undelete',
    },

    resetDeletedObjects: function () {
        this.table.empty();
    },

    removeDeletedObject: function (model) {
        this.table.find('tr[data-id="' + model.get('id') + '"]').remove();
    },

    undelete: function (event) {
        var tr = $(event.target).closest('tr'),
            id = tr.attr('data-id'),
            model = sw.deletedObjects.get(id);

        model.destroy({
            wait: true,
            data: JSON.stringify(model.attributes),
            success: function () {
                sw.deletedObjects.remove(model);
            },
            processData: true,
        });
    },

    renderDeletedObject: function (model) {
        var data = _.clone(model.attributes);
        data.deleted_time = moment(data.deleted_at).format(sw.longDateFormat());
        data.type_name = sw.translate(this.typeName(data.type));
        data.undelete_label = sw.translate('Undelete');
        this.table.append(this.template(data));
    },

    typeName: function (type) {
        if ('time_entries' === type) {
            return 'Time entry';
        }
        if ('workflows' === type) {
            return 'Workflow';
        }
        if ('activities' === type) {
            return 'Activity';
        }
        if ('activity_fields' === type) {
            return 'Activity field';
        }
        if ('activity_types' === type) {
            return 'Activity type';
        }
        if ('company_users' === type) {
            return 'Company user';
        }
        if ('contacts' === type) {
            return 'Contact';
        }
        if ('currencies' === type) {
            return 'Currency';
        }
        if ('files' === type) {
            return 'File';
        }
        if ('filters' === type) {
            return 'Filter';
        }
        if ('goals' === type) {
            return 'Goal';
        }
        if ('note_fields' === type) {
            return 'Note field';
        }
        if ('notes' === type) {
            return 'Note';
        }
        if ('organization_fields' === type) {
            return 'Organization field';
        }
        if ('organizations' === type) {
            return 'Organization';
        }
        if ('person_fields' === type) {
            return 'Person field';
        }
        if ('persons' === type) {
            return 'Person';
        }
        if ('products' === type) {
            return 'Product';
        }
        if ('product_fields' === type) {
            return 'Product field';
        }
        if ('push_notifications' === type) {
            return 'Push notification';
        }
        if ('stages' === type) {
            return 'Stage';
        }
        if ('task_fields' === type) {
            return 'Task field';
        }
        if ('tasks' === type) {
            return 'Task';
        }
        if ('prices' === type) {
            return 'Price';
        }
        return type;
    },

    render: function () {
        sw.lazyFetch(sw.deletedObjects);

        this.$el.removeClass('hidden');
    },

});

sw.SettingsView = Backbone.View.extend({

    el: '.settings-view',

    section: null, // sub section name, for example /settings/workflows <-

    id: null, // sub section ID, for example /settings/workflows/123 <-

    usersTable: $('.users-table-body'),
    userRowTemplate: _.template($("#user-row-template").html()),

    companiesTable: $('.companies-table-body'),
    companyRowTemplate: _.template($("#company-row-template").html()),

    workflowList: $('.workflow-list'),
    workflowListItemTemplate: _.template($('#workflow-list-item-template').html()),

    sortableStageList: $('.sortable-stage-list'),
    sortableStageListItemTemplate: _.template($('#sortable-stage-list-item-template').html()),

    initialize: function () {
        sw.companies.on("add", this.renderCompany, this);
        sw.companies.on("change", this.updateCompany, this);

        sw.companyUsers.on("add", this.renderCompanyUser, this);

        sw.workflows.on("reset", this.resetWorkflows, this);
        sw.workflows.on("add", this.renderWorkflow, this);
        sw.workflows.on("remove", this.removeWorkflow, this);
        sw.workflows.on("change", this.updateWorkflow, this);

        sw.workflowStages.on("reset", this.resetWorkflowStages, this);
        sw.workflowStages.on("add", this.renderWorkflowStage, this);
        sw.workflowStages.on("change", this.updateWorkflowStage, this);
        sw.workflowStages.on("remove", this.removeStage, this);

        sw.currentUser.on("change", this.renderCurrentUser, this);

        var dialog = this;

        this.sortableStageList.sortable({
            stop: function () {
                var stages = dialog.sortableStageList.find('li'),
                    i,
                    stageID,
                    stage;
                for (i = 0; i < stages.length; i = i + 1) {
                    stageID = $(stages[i]).attr('data-stage-id');
                    stage = sw.workflowStages.get(stageID);
                    stage.save({order_nr: i});
                }
            }
        });
    },

    events: {
        'click .add-user-button': 'addUser',
        'click .remove-user-button': 'removeUser',
        'click .add-workflow-button': 'addWorkflow',
        'click .delete-workflow-button': 'deleteWorkflow',
        'click .edit-stage': 'editStage',
        'click .edit-workflow-button': 'editWorkflow',
        'click .add-stage-button': 'addStage',
        'click .add-company-button': 'addCompany',
        'click .edit-company': 'editCompany',
        'click .remove-company-button': 'removeCompany',
    },

    addCompany: function () {
        var company = new sw.Company();
        sw.newCompanyModal.render(company);
    },

    renderCurrentUser: function (model) {
        var el = this.$el.find('.active-company-name');
        el.text(model.get('active_company_name'));
        el.attr('data-company-id', model.get('active_company_id'));
    },

    editCompany: function (event) {
        event.preventDefault();

        var id = $(event.target).closest('tr').attr('data-company-id'),
            model = sw.companies.get(id);

        sw.editCompanyModal.render(model);
    },

    editWorkflow: function (event) {
        var model = sw.workflows.get(this.id);
        sw.editWorkflowModal.render(model);
    },

    addStage: function (event) {
        event.preventDefault();
        var stage = new sw.Stage();
        stage.set('workflow_id', this.id);
        sw.newStageModal.render(stage);
    },

    editStage: function (event) {
        event.preventDefault();
        var stageID = $(event.target).closest('li').attr('data-stage-id'),
            stage = sw.workflowStages.get(stageID);
        sw.editStageModal.render(stage);
    },

    resetWorkflowStages: function () {
        this.sortableStageList.empty();
    },

    renderWorkflowStage: function (model) {
        this.sortableStageList.append(this.sortableStageListItemTemplate(model.attributes));

        sw.showTutorial(this, this.section, this.id);
    },

    renderCompany: function (model) {
        var data = _.clone(model.attributes);
        data.remove_label = sw.translate('Remove company');
        this.companiesTable.append(this.companyRowTemplate(data));

        sw.showTutorial(this, this.section, this.id);
    },

    updateWorkflow: function (model) {
        var li = this.workflowList.find('[data-workflow-id="' + model.get('id') + '"]'),
            data = _.clone(model.attributes);
        data.activeClass = 'active';
        li.replaceWith(this.workflowListItemTemplate(data));
    },

    updateCompany: function (model) {
        var data = _.clone(model.attributes),
            el = null;

        data.remove_label = sw.translate('Remove company');
        this.companiesTable.find('tr[data-company-id="' + model.get('id') + '"]').replaceWith(this.companyRowTemplate(data));

        el = this.$el.find('.active-company-name');
        if (el.attr('data-company-id') === model.get('id')) {
            el.text(model.get('name'));
        }
    },

    updateWorkflowStage: function (model) {
        var html = this.sortableStageListItemTemplate(model.attributes),
            li = this.sortableStageList.find('[data-stage-id="' + model.get('id') + '"]');
        li.replaceWith(html);
    },

    removeWorkflow: function () {
        this.$el.find('[data-workflow-id="' + this.id + '"]').remove();
    },

    removeStage: function (model) {
        this.sortableStageList.find('[data-stage-id="' + model.get('id') + '"]').remove();
    },

    deleteWorkflow: function () {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var model = sw.workflows.get(this.id);
        model.destroy({
            wait: true,
            success: function () {
                sw.workflows.remove(model);
                sw.router.navigate('/settings/workflows', {trigger: true});
            },
            error: function (ignore, response) {
                alert(sw.translate(response.responseText));
            },
        });
    },

    addWorkflow: function () {
        sw.newWorkflowModal.render();
    },

    addUser: function () {
        sw.newUserModal.render();
    },

    removeUser: function (event) {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var row = $(event.target).closest('tr'),
            id = row.attr('data-company-user-id'),
            companyUser = sw.companyUsers.get(id);
        companyUser.destroy({wait: true});
        row.remove();
        sw.companyUsers.remove(companyUser);
    },

    removeCompany: function (event) {
        if (!confirm(sw.translate('Are you sure?'))) {
            return;
        }
        var row = $(event.target).closest('tr'),
            id = row.attr('data-company-id'),
            model = sw.companies.get(id);
        model.destroy({wait: true});
        row.remove();
        sw.companies.remove(model);
    },

    renderCompanyUser: function (model) {
        var data = _.clone(model.attributes);
        data.remove_label = sw.translate('Remove user');
        this.usersTable.append(this.userRowTemplate(data));
    },

    resetWorkflows: function () {
        this.workflowList.empty();
    },

    renderWorkflow: function (model) {
        var data = _.clone(model.attributes);
        if (model.id === this.id) {
            data.activeClass = "active";
        } else {
            data.activeClass = "";
        }
        this.workflowList.append(this.workflowListItemTemplate(data));

        sw.showTutorial(this, this.section, this.id);
    },

    render: function (section, id) {
        this.section = section;
        this.id = id;

        this.$el.find('.settings-menu').removeClass('active');
        this.$el.find('.settings-menu-' + section).addClass('active');

        this.$el.find('.settings-subview').addClass('hidden');
        this.$el.find('.settings-subview-' + section).removeClass('hidden');

        this.$el.removeClass('hidden');

        if (section === 'users') {
            sw.lazyFetch(sw.companyUsers);
        }
        if (section === 'workflows') {
            this.$el.find('.workflow-list-item').removeClass('active');

            sw.lazyFetch(sw.workflows);

            this.$el.find('[data-workflow-id="' + this.id + '"]').addClass('active');

            if (this.id) {
                this.$el.find('.workflow-buttons').removeClass('hidden');
                this.sortableStageList.removeClass('hidden');
            } else {
                this.$el.find('.workflow-buttons').addClass('hidden');
                this.sortableStageList.addClass('hidden');
            }

            sw.workflowStages.reset();
            sw.workflowStages.fetch(
                {
                    data: {
                        workflow_id: this.id,
                    }
                }
            );
        }

        sw.showTutorial(this, this.section, this.id);
    },
});

sw.OrganizationsView = Backbone.View.extend({

    el: '.organizations-view',

    organizationTemplate: _.template($("#organization-row-template").html()),
    organizationsTable: $('.organizations-table-body'),

    initialize: function () {
        sw.organizations.on("reset", this.resetOrganizations, this);
        sw.organizations.on("remove", this.removeOrganization, this);
        sw.organizations.on("add", this.renderOrganization, this);
        sw.organizations.on("change", this.updateOrganization, this);
    },

    events: {
        'click .add-organization-button': 'addOrganization',
    },

    removeOrganization: function (model) {
        this.$el.find('tr[data-task-id="' + model.get('id') + '"]').remove();
    },

    updateOrganization: function (model) {
        this.$el.find('tr[data-task-id="' + model.get('id') + '"]').replaceWith(this.renderTemplate(model));
    },

    renderTemplate: function (model) {
        var data = _.clone(model.attributes);
        if (data.next_activity_date) {
            data.next_activity_time = moment(data.next_activity_date).format(sw.longDateFormat());
        } else {
            data.next_activity_time = '';
        }
        return this.organizationTemplate(data);
    },

    addOrganization: function () {
        sw.newOrganizationModal.render();
    },

    resetOrganizations: function () {
        this.organizationsTable.empty();
    },

    renderOrganization: function (model) {
        this.organizationsTable.append(this.renderTemplate(model));
    },

    render: function () {
        this.$el.removeClass('hidden');

        sw.lazyFetch(sw.organizations);

        sw.showTutorial(this);
    },
});

sw.SignupView = Backbone.View.extend({

    el: '.not-logged-in',

    initialize: function () {
        sw.on(sw.events.userLoggedIn, this.hide, this);
        sw.on(sw.events.userLoggedOut, this.render, this);
    },

    hide: function () {
        this.$el.addClass('hidden');
    },

    render: function () {
        this.$el.removeClass('hidden');
    },

    events: {
        'click .facebook_button': 'startFacebookLogin',
        'click .google_button': 'startGoogleLogin',
        'click .signup': 'signup',
        'submit form': 'createUser',
    },

    startFacebookLogin: function () {
        sw.startFacebookLogin();
    },

    startGoogleLogin: function () {
        sw.startGoogleLogin();
    },

    createUser: function (event) {
        event.preventDefault();

        var data = {
            email: $('#signupEmail').val(),
            password: $('#signupPassword').val(),
        };

        $.ajax('/api/me', {method: 'POST', data: JSON.stringify(data)})
            .success(function (data) {
                $('#signupModal').modal('hide');
                $('.signup-error').addClass('hidden');

                sw.currentUser.set(JSON.parse(data));

                sw.trigger(sw.events.userLoggedIn);
            })
            .error(function (response) {
                $('.signup-error').removeClass('hidden').html(sw.translate(response.responseText));
            });
    },

    signup: function (event) {
        event.preventDefault();

        var dialog = this;

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#signupEmail').focus();
        });

        $('#signupModal').modal('show');

        ga('send', {
            hitType: 'event',
            eventAction: 'signup'
        });
    },
});

sw.startFacebookLogin = function () {
    $.ajax('/api/facebook_login_url')
        .success(function (url) {
            window.location = url;
        })
        .error(function (err) {
            console.log(err);
        });
};

sw.startGoogleLogin = function () {
    $.ajax('/api/google_login_url')
        .success(function (url) {
            window.location = url;
        })
        .error(function (err) {
            console.log(err);
        });
};

sw.ActivitiesView = Backbone.View.extend({

    el: $('.activities-view'),

    template: _.template($('#activity-row-template').html()),
    table: $('.activity-table'),

    initialize: function () {
        sw.activities.on("reset", this.resetActivities, this);
        sw.activities.on("add", this.renderActivity, this);
        sw.activities.on("change", this.updateActivity, this);
        sw.activities.on("remove", this.removeActivity, this);
    },

    events: {
        'click .add-activity-button': 'addActivity',
    },

    resetActivities: function () {
        this.table.empty();
    },

    updateActivity: function (model) {
        var tr = this.table.find('tr[data-task-id="' + model.get('id') + '"]');
        if (tr.length) {
            tr.replaceWith(this.renderTemplate(model));
        }
    },

    removeActivity: function (model) {
        this.table.find('tr[data-task-id="' + model.get('id') + '"]').remove();
    },

    renderTemplate: function (model) {
        var data = _.clone(model.attributes);
        if (data.marked_as_done_time) {
            data.done_class = "";
        } else {
            data.done_class = "hidden";
        }
        if (data.due_date) {
            data.due_time = moment(data.due_date).format(sw.longDateFormat());
        } else {
            data.due_time = '';
        }
        data.emails = sw.emails(data.person_email);
        data.phones = sw.phones(data.person_phone);
        return this.template(data);
    },

    renderActivity: function (model) {
        this.table.append(this.renderTemplate(model));
    },

    addActivity: function () {
        sw.newActivityModal.render(sw.activities);
    },

    render: function () {
        this.$el.removeClass('hidden');

        sw.lazyFetch(sw.activities);

        sw.showTutorial(this);
    },

});

sw.NewActivityModal = Backbone.View.extend({

    el: $('#newActivityModal'),

    initialize: function () {
        sw.activityTypes.on("add", this.renderActivityType, this);

        sw.companyUsers.on("add", this.renderUser, this);

        this.$el.find('#newActivityDate').datepicker({
            autoclose: true,
        });
    },

    events: {
        'click .save-activity-button': 'save',
        'click .activity-type': 'selectType',
        'click .activity-user': 'selectUser',
    },

    collection: null,

    activityDropdown: $('.activity-type-item-dropdown'),
    activityTemplate: _.template($('#activity-type-item-template').html()),

    userDropdown: $('.activity-user-item-dropdown'),
    userTemplate: _.template($('#activity-user-item-template').html()),

    renderUser: function (model) {
        this.userDropdown.append(this.userTemplate(model.attributes));
    },

    renderActivityType: function (model) {
        var data = _.clone(model.attributes);
        data.label = sw.translate(data.name);
        this.activityDropdown.append(this.activityTemplate(data));
    },

    selectUser: function (event) {
        event.preventDefault();

        var id = $(event.target).closest('li').attr('data-company-user-id'),
            model = sw.companyUsers.get(id);

        this.$el.find('.activity-user-name').text(model.get('name'));
        this.$el.find('.activity-user-name').attr('data-user-id', model.get('user_id'));
    },

    selectType: function (event) {
        event.preventDefault();

        var id = $(event.target).closest('li').attr('data-type-id'),
            model = sw.activityTypes.get(id);

        this.$el.find('.activity-type-name').text(sw.translate(model.get('name')));
        this.$el.find('.activity-type-name').attr('data-type-id', model.get('id'));
    },

    save: function () {
        var model = this.model,
            dialog = this,
            dateInput = this.$el.find('#newActivityDate').datepicker('getDate'),
            timeInput = this.$el.find('#newActivityTime').val(),
            date = moment(dateInput),
            time = moment(timeInput, ['h:m a', 'H:m']),
            datetime = null,
            doneAt = null;

        if (dateInput && date.isValid()) {
            datetime = moment();
            datetime.set({
                'year': date.year(),
                'month': date.month(),
                'date': date.date()
            });
        }
        if (datetime && time.isValid()) {
            datetime.set({
                'hour': time.hour(),
                'minute': time.minute(),
                'second': 0,
                'millisecond': 0,
            });
        }

        model.save({
            name: this.$el.find('#newActivityName').val(),
            type_id: this.$el.find('.activity-type-name').attr('data-type-id'),
            assigned_to_user_id: this.$el.find('.activity-user-name').attr('data-user-id'),
            due_date: datetime,
            duration: this.$el.find('#newActivityDuration').val(),
            task_id: this.$el.find('#newActivityTask').attr('data-task-id'),
            person_id: this.$el.find('#newActivityPerson').attr('data-person-id'),
            org_id: this.$el.find('#newActivityOrganization').attr('data-organization-id'),
            marked_as_done_time: doneAt,
            done: true,
        }, {
            wait: true,
            success: function () {
                dialog.$el.modal('hide');
                dialog.collection.add(model);

                sw.tutorialDone('addActivity');
            },
            error: function (ignore, response) {
                dialog.$el.find('.activity-error').removeClass('hidden').html(sw.translate(response.responseText));
            },
        });
    },

    render: function (collection, data) {
        this.collection = collection;

        this.model = new sw.Activity(data);

        this.$el.find('.activity-error').addClass('hidden');

        this.$el.find('#newActivityName').val('');

        this.$el.find('.activity-type-name').text(sw.translate('Activity type'));
        this.$el.find('.activity-type-name').removeAttr('data-type-id');

        this.$el.find('#newActivityDate').val('');
        this.$el.find('#newActivityTime').val('');

        this.$el.find('#newActivityDuration').val('');

        this.$el.find('.activity-user-name').text(sw.translate('Assigned to'));
        this.$el.find('.activity-user-name').removeAttr('data-user-id');

        this.$el.find('#newActivityTask').attr('data-task-id', this.model.get('task_id'));
        this.$el.find('#newActivityTask').val(this.model.get('task_title'));

        this.$el.find('#newActivityPerson').attr('data-person-id', this.model.get('person_id'));
        this.$el.find('#newActivityPerson').val(this.model.get('person_name'));

        this.$el.find('#newActivityOrganization').attr('data-organization-id', this.model.get('org_id'));
        this.$el.find('#newActivityOrganization').val(this.model.get('org_name'));

        var dialog = this;
        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#newActivityName').focus();
        });

        sw.lazyFetch(sw.activityTypes);
        sw.lazyFetch(sw.companyUsers);

        sw.lazyFetch(sw.organizations, function () {
            var items = sw.organizations.pluck('name');
            dialog.$el.find('#newActivityOrganization').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#newActivityOrganization').removeAttr('data-organization-id');
                        return;
                    }
                    var model = sw.organizations.findWhere({name: ui.item.label});
                    dialog.$el.find('#newActivityOrganization').attr('data-organization-id', model.get('id'));
                },
            });
        });

        sw.lazyFetch(sw.people, function () {
            var items = sw.people.pluck('name');
            dialog.$el.find('#newActivityPerson').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#newActivityPerson').removeAttr('data-person-id');
                        return;
                    }
                    var model = sw.people.findWhere({name: ui.item.label});
                    dialog.$el.find('#newActivityPerson').attr('data-person-id', model.get('id'));
                },
            });
        });

        sw.lazyFetch(sw.tasks, function () {
            var items = sw.tasks.pluck('name');
            dialog.$el.find('#newActivityTask').autocomplete({
                source: items,
                change: function (event, ui) {
                    if (!ui.item) {
                        dialog.$el.find('#newActivityTask').removeAttr('data-task-id');
                        return;
                    }
                    var model = sw.tasks.findWhere({name: ui.item.label});
                    dialog.$el.find('#newActivityTask').attr('data-task-id', model.get('id'));
                },
            });
        });

        this.$el.modal('show');
    },
});

sw.ActivationModal = Backbone.View.extend({

    el: '#activationModal',

    events: {
        'click .set-password-button': 'setPassword',
    },

    setPassword: function () {
        var id = this.$el.attr('data-activation-id'),
            data = JSON.stringify({password: this.$el.find('#newPassword').val()}),
            dialog = this;
        $.ajax('/api/activate/' + id, {method: 'POST', data: data})
            .success(function (data) {
                sw.currentUser.set(JSON.parse(data));

                sw.trigger(sw.events.userLoggedIn);

                dialog.$el.modal('hide');

                sw.router.navigate('/', {trigger: true});
            })
            .error(function (response) {
                dialog.$el.find('.activation-error').removeClass('hidden').html(sw.translate(response.responseText));
            });
    },

    render: function (activationID) {
        this.$el.find('#newPassword').val('');

        var dialog = this;

        $.ajax('/api/activate/' + activationID, {method: 'GET'})
            .success(function (data) {
                dialog.$el.attr('data-activation-id', activationID);

                dialog.$el.find('.activation-error').addClass('hidden');

                dialog.$el.on("shown.bs.modal", function () {
                    dialog.$el.find('#newPassword').focus();
                });

                dialog.$el.modal('show');
            })
            .error(function (response) {
                alert('This activation link is not valid, sorry!');
                sw.router.navigate('/', {trigger: true});
            });
    },
});

sw.LoginModal = Backbone.View.extend({

    el: $('#loginModal'),

    events: {
        'click .facebook_button': 'startFacebookLogin',
        'click .google_button': 'startGoogleLogin',
        'submit form': 'login',
    },

    startFacebookLogin: function () {
        sw.startFacebookLogin();
    },

    startGoogleLogin: function () {
        sw.startGoogleLogin();
    },

    login: function (event) {
        event.preventDefault();

        var data = {
            email: $('#loginEmail').val(),
            password: $('#loginPassword').val(),
        };

        $.ajax('/api/me', {method: 'POST', data: JSON.stringify(data)})
            .success(function (data) {
                $('#loginModal').modal('hide');
                $('.login-error').addClass('hidden');

                sw.currentUser.set(JSON.parse(data));

                sw.trigger(sw.events.userLoggedIn);

                sw.router.navigate('#', {trigger: true});
            })
            .error(function (response) {
                $('.login-error').removeClass('hidden').html(sw.translate(response.responseText));
            });
    },

    render: function () {
        var dialog = this;

        this.$el.on("shown.bs.modal", function () {
            dialog.$el.find('#loginEmail').focus();
        });

        this.$el.modal('show');
    },

});

sw.Router = Backbone.Router.extend({

    routes: {
        'activate/:id': 'activate',
        'settings': 'settings',
        'settings/:section': 'settings',
        'settings/:section/:id': 'settings',
        'tasks': 'tasks',
        'board': 'board',
        'activities': 'activities',
        'people': 'people',
        'organizations': 'organizations',
        'team': 'team',
        '': 'appInfo',
        '_=_': 'appInfo', // Facebook login
        'task/:id': 'task',
        'person/:id': 'person',
        'organization/:id': 'organization',
        'activity/:id': 'activity',
        'deleted_data': 'deleted_data',
        'work': 'work',
        'timeentry/:id': 'timeentry',
        'login': 'login',
    },

    login: function () {
        sw.loginModal.render();
    },

    deleted_data: function () {
        document.title = sw.translate('Deleted data');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        sw.deletedDataView.render();
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    timeentry: function (id) {
        document.title = sw.translate('Time entry');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.work-menu').addClass('active');
        sw.timeEntryView.render(id);
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    person: function (id) {
        document.title = sw.translate('Person');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.people-menu').addClass('active');
        sw.personView.render(id);
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    work: function () {
        document.title = sw.translate('Work');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.work-menu').addClass('active');
        sw.workView.render();
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    activity: function (id) {
        document.title = sw.translate('Activity');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.activities-menu').addClass('active');
        sw.activityView.render(id);
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    organization: function (id) {
        document.title = sw.translate('Organization');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.organizations-menu').addClass('active');
        sw.organizationView.render(id);
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    task: function (id) {
        document.title = sw.translate('Task');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.tasks-menu').addClass('active');
        sw.taskView.render(id);
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    team: function () {
        document.title = sw.translate('Team');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.team-menu').addClass('active');
        sw.teamView.render();
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    activate: function (id) {
        sw.activationModal = new sw.ActivationModal();
        sw.activationModal.render(id);
    },

    appInfo: function () {
        document.title = 'superwork.io';
        $('.app-view').addClass('hidden');
        $('.app-info').removeClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        sw.appView.renderStartTutorialButton();
    },

    settings: function (section, id) {
        if (section === '' || !section) {
            sw.router.navigate('/settings/companies', {trigger: true});
            return;
        }
        document.title = sw.translate('Settings');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        sw.settingsView.render(section, id);
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    activities: function () {
        document.title = sw.translate('Activities');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        $('.logged-in-menu li').removeClass('active');
        $('.activities-menu').addClass('active');
        sw.activitiesView.render();
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    tasks: function () {
        document.title = sw.translate('Tasks');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        sw.tasksView.render();
        $('.logged-in-menu li').removeClass('active');
        $('.tasks-menu').addClass('active');
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    board: function () {
        document.title = sw.translate('Board');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        sw.boardView.render();
        $('.logged-in-menu li').removeClass('active');
        $('.board-menu').addClass('active');
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    people: function () {
        document.title = sw.translate('People');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        sw.peopleView.render();
        $('.logged-in-menu li').removeClass('active');
        $('.people-menu').addClass('active');
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

    organizations: function () {
        document.title = sw.translate('Organizations');
        $('.app-view').addClass('hidden');
        $('.app-info').addClass('hidden');
        sw.organizationsView.render();
        $('.logged-in-menu li').removeClass('active');
        $('.organizations-menu').addClass('active');
        $("html, body").animate({ scrollTop: 0 }, "slow");
    },

});

sw.lazyFetch = function (collection, success) {
    if (collection.isSynced) {
        if (success) {
            success();
        }
        return;
    }
    collection.fetch({
        success: function () {
            collection.isSynced = true;
            if (success) {
                success();
            }
        }
    });
};

$(function () {

    sw.workflows = new sw.Workflows();
    sw.companies = new sw.Companies();
    sw.tasks = new sw.Tasks();
    sw.stages = new sw.Stages();
    sw.organizations = new sw.Organizations();
    sw.people = new sw.People();
    sw.currencies = new sw.Currencies();
    sw.tasks = new sw.Tasks();
    sw.companyUsers = new sw.CompanyUsers();
    sw.workflowStages = new sw.Stages();
    sw.timeline = new sw.Timeline();
    sw.activities = new sw.Activities();
    sw.taskNotes = new sw.Notes();
    sw.taskActivities = new sw.Activities();
    sw.personNotes = new sw.Notes();
    sw.personTasks = new sw.Tasks();
    sw.personActivities = new sw.Activities();
    sw.organizationNotes = new sw.Notes();
    sw.organizationTasks = new sw.Tasks();
    sw.organizationActivities = new sw.Activities();
    sw.organizationPeople = new sw.People();
    sw.activityTypes = new sw.ActivityTypes();
    sw.personContacts = new sw.Contacts();
    sw.deletedObjects = new sw.DeletedObjects();
    sw.timeEntries = new sw.TimeEntries();
    sw.userEvents = new sw.UserEvents();

    sw.signupView = new sw.SignupView();
    sw.thanksView = new sw.ThanksView();
    sw.navView = new sw.NavView();
    sw.tasksView = new sw.TasksView();
    sw.peopleView = new sw.PeopleView();
    sw.organizationsView = new sw.OrganizationsView();
    sw.settingsView = new sw.SettingsView();
    sw.boardView = new sw.BoardView();
    sw.taskModal = new sw.TaskModal();
    sw.newUserModal = new sw.NewUserModal();
    sw.newWorkflowModal = new sw.NewWorkflowModal();
    sw.passwordModal = new sw.PasswordModal();
    sw.editStageModal = new sw.EditStageModal();
    sw.newStageModal = new sw.NewStageModal();
    sw.editWorkflowModal = new sw.EditWorkflowModal();
    sw.newCompanyModal = new sw.NewCompanyModal();
    sw.newPersonModal = new sw.NewPersonModal();
    sw.newOrganizationModal = new sw.NewOrganizationModal();
    sw.activitiesView = new sw.ActivitiesView();
    sw.newActivityModal = new sw.NewActivityModal();
    sw.taskView = new sw.TaskView();
    sw.taskNameModal = new sw.TaskNameModal();
    sw.taskValueModal = new sw.TaskValueModal();
    sw.editTaskPersonModal = new sw.EditTaskPersonModal();
    sw.editOrganizationModal = new sw.EditOrganizationModal();
    sw.teamView = new sw.TeamView();
    sw.personView = new sw.PersonView();
    sw.personNameModal = new sw.PersonNameModal();
    sw.organizationView = new sw.OrganizationView();
    sw.organizationNameModal = new sw.OrganizationNameModal();
    sw.activityView = new sw.ActivityView();
    sw.activityNameModal = new sw.ActivityNameModal();
    sw.editTaskModal = new sw.EditTaskModal();
    sw.contactModal = new sw.ContactModal();
    sw.deletedDataView = new sw.DeletedDataView();
    sw.workView = new sw.WorkView();
    sw.loginModal = new sw.LoginModal();
    sw.editCompanyModal = new sw.EditCompanyModal();
    sw.timeEntryView = new sw.TimeEntryView();
    sw.appView = new sw.AppView();
    sw.tutorialDoneModal = new sw.TutorialDoneModal();

    sw.router = new sw.Router();

    Backbone.history.start({pushState: false});

    sw.currentUser.fetch({
        success: function () {
            sw.trigger(sw.events.userLoggedIn);

            if (!Backbone.history.getFragment().length) {
                sw.router.navigate('/', {trigger: true});
            }
        },
        error: function () {
            sw.trigger(sw.events.userLoggedOut);

            $('.app-view').addClass('hidden');
        }
    });
});
