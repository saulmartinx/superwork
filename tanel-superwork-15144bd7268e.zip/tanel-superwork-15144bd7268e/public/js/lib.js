/*! jQuery v1.11.3 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
function processRelativeTime(t,e,i,n){var s={s:["mõne sekundi","mõni sekund","paar sekundit"],m:["ühe minuti","üks minut"],mm:[t+" minuti",t+" minutit"],h:["ühe tunni","tund aega","üks tund"],hh:[t+" tunni",t+" tundi"],d:["ühe päeva","üks päev"],M:["kuu aja","kuu aega","üks kuu"],MM:[t+" kuu",t+" kuud"],y:["ühe aasta","aasta","üks aasta"],yy:[t+" aasta",t+" aastat"]}
return e?s[i][2]?s[i][2]:s[i][1]:n?s[i][0]:s[i][1]}if(!function(t,e){"object"==typeof module&&"object"==typeof module.exports?module.exports=t.document?e(t,!0):function(t){if(!t.document)throw new Error("jQuery requires a window with a document")
return e(t)}:e(t)}("undefined"!=typeof window?window:this,function(t,e){function i(t){var e="length"in t&&t.length,i=st.type(t)
return"function"!==i&&!st.isWindow(t)&&(!(1!==t.nodeType||!e)||("array"===i||0===e||"number"==typeof e&&e>0&&e-1 in t))}function n(t,e,i){if(st.isFunction(e))return st.grep(t,function(t,n){return!!e.call(t,n,t)!==i})
if(e.nodeType)return st.grep(t,function(t){return t===e!==i})
if("string"==typeof e){if(dt.test(e))return st.filter(e,t,i)
e=st.filter(e,t)}return st.grep(t,function(t){return st.inArray(t,e)>=0!==i})}function s(t,e){do t=t[e]
while(t&&1!==t.nodeType)
return t}function r(t){var e=bt[t]={}
return st.each(t.match(_t)||[],function(t,i){e[i]=!0}),e}function o(){pt.addEventListener?(pt.removeEventListener("DOMContentLoaded",a,!1),t.removeEventListener("load",a,!1)):(pt.detachEvent("onreadystatechange",a),t.detachEvent("onload",a))}function a(){(pt.addEventListener||"load"===event.type||"complete"===pt.readyState)&&(o(),st.ready())}function l(t,e,i){if(void 0===i&&1===t.nodeType){var n="data-"+e.replace(Tt,"-$1").toLowerCase()
if(i=t.getAttribute(n),"string"==typeof i){try{i="true"===i||"false"!==i&&("null"===i?null:+i+""===i?+i:Dt.test(i)?st.parseJSON(i):i)}catch(t){}st.data(t,e,i)}else i=void 0}return i}function u(t){var e
for(e in t)if(("data"!==e||!st.isEmptyObject(t[e]))&&"toJSON"!==e)return!1
return!0}function h(t,e,i,n){if(st.acceptData(t)){var s,r,o=st.expando,a=t.nodeType,l=a?st.cache:t,u=a?t[o]:t[o]&&o
if(u&&l[u]&&(n||l[u].data)||void 0!==i||"string"!=typeof e)return u||(u=a?t[o]=G.pop()||st.guid++:o),l[u]||(l[u]=a?{}:{toJSON:st.noop}),("object"==typeof e||"function"==typeof e)&&(n?l[u]=st.extend(l[u],e):l[u].data=st.extend(l[u].data,e)),r=l[u],n||(r.data||(r.data={}),r=r.data),void 0!==i&&(r[st.camelCase(e)]=i),"string"==typeof e?(s=r[e],null==s&&(s=r[st.camelCase(e)])):s=r,s}}function c(t,e,i){if(st.acceptData(t)){var n,s,r=t.nodeType,o=r?st.cache:t,a=r?t[st.expando]:st.expando
if(o[a]){if(e&&(n=i?o[a]:o[a].data)){st.isArray(e)?e=e.concat(st.map(e,st.camelCase)):e in n?e=[e]:(e=st.camelCase(e),e=e in n?[e]:e.split(" ")),s=e.length
for(;s--;)delete n[e[s]]
if(i?!u(n):!st.isEmptyObject(n))return}(i||(delete o[a].data,u(o[a])))&&(r?st.cleanData([t],!0):it.deleteExpando||o!=o.window?delete o[a]:o[a]=null)}}}function d(){return!0}function f(){return!1}function p(){try{return pt.activeElement}catch(t){}}function m(t){var e=Ht.split("|"),i=t.createDocumentFragment()
if(i.createElement)for(;e.length;)i.createElement(e.pop())
return i}function g(t,e){var i,n,s=0,r=typeof t.getElementsByTagName!==kt?t.getElementsByTagName(e||"*"):typeof t.querySelectorAll!==kt?t.querySelectorAll(e||"*"):void 0
if(!r)for(r=[],i=t.childNodes||t;null!=(n=i[s]);s++)!e||st.nodeName(n,e)?r.push(n):st.merge(r,g(n,e))
return void 0===e||e&&st.nodeName(t,e)?st.merge([t],r):r}function v(t){Nt.test(t.type)&&(t.defaultChecked=t.checked)}function y(t,e){return st.nodeName(t,"table")&&st.nodeName(11!==e.nodeType?e:e.firstChild,"tr")?t.getElementsByTagName("tbody")[0]||t.appendChild(t.ownerDocument.createElement("tbody")):t}function _(t){return t.type=(null!==st.find.attr(t,"type"))+"/"+t.type,t}function b(t){var e=zt.exec(t.type)
return e?t.type=e[1]:t.removeAttribute("type"),t}function w(t,e){for(var i,n=0;null!=(i=t[n]);n++)st._data(i,"globalEval",!e||st._data(e[n],"globalEval"))}function x(t,e){if(1===e.nodeType&&st.hasData(t)){var i,n,s,r=st._data(t),o=st._data(e,r),a=r.events
if(a){delete o.handle,o.events={}
for(i in a)for(n=0,s=a[i].length;s>n;n++)st.event.add(e,i,a[i][n])}o.data&&(o.data=st.extend({},o.data))}}function k(t,e){var i,n,s
if(1===e.nodeType){if(i=e.nodeName.toLowerCase(),!it.noCloneEvent&&e[st.expando]){s=st._data(e)
for(n in s.events)st.removeEvent(e,n,s.handle)
e.removeAttribute(st.expando)}"script"===i&&e.text!==t.text?(_(e).text=t.text,b(e)):"object"===i?(e.parentNode&&(e.outerHTML=t.outerHTML),it.html5Clone&&t.innerHTML&&!st.trim(e.innerHTML)&&(e.innerHTML=t.innerHTML)):"input"===i&&Nt.test(t.type)?(e.defaultChecked=e.checked=t.checked,e.value!==t.value&&(e.value=t.value)):"option"===i?e.defaultSelected=e.selected=t.defaultSelected:("input"===i||"textarea"===i)&&(e.defaultValue=t.defaultValue)}}function D(e,i){var n,s=st(i.createElement(e)).appendTo(i.body),r=t.getDefaultComputedStyle&&(n=t.getDefaultComputedStyle(s[0]))?n.display:st.css(s[0],"display")
return s.detach(),r}function T(t){var e=pt,i=Kt[t]
return i||(i=D(t,e),"none"!==i&&i||(Zt=(Zt||st("<iframe frameborder='0' width='0' height='0'/>")).appendTo(e.documentElement),e=(Zt[0].contentWindow||Zt[0].contentDocument).document,e.write(),e.close(),i=D(t,e),Zt.detach()),Kt[t]=i),i}function C(t,e){return{get:function(){var i=t()
if(null!=i)return i?void delete this.get:(this.get=e).apply(this,arguments)}}}function S(t,e){if(e in t)return e
for(var i=e.charAt(0).toUpperCase()+e.slice(1),n=e,s=de.length;s--;)if(e=de[s]+i,e in t)return e
return n}function M(t,e){for(var i,n,s,r=[],o=0,a=t.length;a>o;o++)n=t[o],n.style&&(r[o]=st._data(n,"olddisplay"),i=n.style.display,e?(r[o]||"none"!==i||(n.style.display=""),""===n.style.display&&Mt(n)&&(r[o]=st._data(n,"olddisplay",T(n.nodeName)))):(s=Mt(n),(i&&"none"!==i||!s)&&st._data(n,"olddisplay",s?i:st.css(n,"display"))))
for(o=0;a>o;o++)n=t[o],n.style&&(e&&"none"!==n.style.display&&""!==n.style.display||(n.style.display=e?r[o]||"":"none"))
return t}function E(t,e,i){var n=le.exec(e)
return n?Math.max(0,n[1]-(i||0))+(n[2]||"px"):e}function N(t,e,i,n,s){for(var r=i===(n?"border":"content")?4:"width"===e?1:0,o=0;4>r;r+=2)"margin"===i&&(o+=st.css(t,i+St[r],!0,s)),n?("content"===i&&(o-=st.css(t,"padding"+St[r],!0,s)),"margin"!==i&&(o-=st.css(t,"border"+St[r]+"Width",!0,s))):(o+=st.css(t,"padding"+St[r],!0,s),"padding"!==i&&(o+=st.css(t,"border"+St[r]+"Width",!0,s)))
return o}function A(t,e,i){var n=!0,s="width"===e?t.offsetWidth:t.offsetHeight,r=te(t),o=it.boxSizing&&"border-box"===st.css(t,"boxSizing",!1,r)
if(0>=s||null==s){if(s=ee(t,e,r),(0>s||null==s)&&(s=t.style[e]),ne.test(s))return s
n=o&&(it.boxSizingReliable()||s===t.style[e]),s=parseFloat(s)||0}return s+N(t,e,i||(o?"border":"content"),n,r)+"px"}function O(t,e,i,n,s){return new O.prototype.init(t,e,i,n,s)}function P(){return setTimeout(function(){fe=void 0}),fe=st.now()}function I(t,e){var i,n={height:t},s=0
for(e=e?1:0;4>s;s+=2-e)i=St[s],n["margin"+i]=n["padding"+i]=t
return e&&(n.opacity=n.width=t),n}function L(t,e,i){for(var n,s=(_e[e]||[]).concat(_e["*"]),r=0,o=s.length;o>r;r++)if(n=s[r].call(i,e,t))return n}function H(t,e,i){var n,s,r,o,a,l,u,h,c=this,d={},f=t.style,p=t.nodeType&&Mt(t),m=st._data(t,"fxshow")
i.queue||(a=st._queueHooks(t,"fx"),null==a.unqueued&&(a.unqueued=0,l=a.empty.fire,a.empty.fire=function(){a.unqueued||l()}),a.unqueued++,c.always(function(){c.always(function(){a.unqueued--,st.queue(t,"fx").length||a.empty.fire()})})),1===t.nodeType&&("height"in e||"width"in e)&&(i.overflow=[f.overflow,f.overflowX,f.overflowY],u=st.css(t,"display"),h="none"===u?st._data(t,"olddisplay")||T(t.nodeName):u,"inline"===h&&"none"===st.css(t,"float")&&(it.inlineBlockNeedsLayout&&"inline"!==T(t.nodeName)?f.zoom=1:f.display="inline-block")),i.overflow&&(f.overflow="hidden",it.shrinkWrapBlocks()||c.always(function(){f.overflow=i.overflow[0],f.overflowX=i.overflow[1],f.overflowY=i.overflow[2]}))
for(n in e)if(s=e[n],me.exec(s)){if(delete e[n],r=r||"toggle"===s,s===(p?"hide":"show")){if("show"!==s||!m||void 0===m[n])continue
p=!0}d[n]=m&&m[n]||st.style(t,n)}else u=void 0
if(st.isEmptyObject(d))"inline"===("none"===u?T(t.nodeName):u)&&(f.display=u)
else{m?"hidden"in m&&(p=m.hidden):m=st._data(t,"fxshow",{}),r&&(m.hidden=!p),p?st(t).show():c.done(function(){st(t).hide()}),c.done(function(){var e
st._removeData(t,"fxshow")
for(e in d)st.style(t,e,d[e])})
for(n in d)o=L(p?m[n]:0,n,c),n in m||(m[n]=o.start,p&&(o.end=o.start,o.start="width"===n||"height"===n?1:0))}}function j(t,e){var i,n,s,r,o
for(i in t)if(n=st.camelCase(i),s=e[n],r=t[i],st.isArray(r)&&(s=r[1],r=t[i]=r[0]),i!==n&&(t[n]=r,delete t[i]),o=st.cssHooks[n],o&&"expand"in o){r=o.expand(r),delete t[n]
for(i in r)i in t||(t[i]=r[i],e[i]=s)}else e[n]=s}function W(t,e,i){var n,s,r=0,o=ye.length,a=st.Deferred().always(function(){delete l.elem}),l=function(){if(s)return!1
for(var e=fe||P(),i=Math.max(0,u.startTime+u.duration-e),n=i/u.duration||0,r=1-n,o=0,l=u.tweens.length;l>o;o++)u.tweens[o].run(r)
return a.notifyWith(t,[u,r,i]),1>r&&l?i:(a.resolveWith(t,[u]),!1)},u=a.promise({elem:t,props:st.extend({},e),opts:st.extend(!0,{specialEasing:{}},i),originalProperties:e,originalOptions:i,startTime:fe||P(),duration:i.duration,tweens:[],createTween:function(e,i){var n=st.Tween(t,u.opts,e,i,u.opts.specialEasing[e]||u.opts.easing)
return u.tweens.push(n),n},stop:function(e){var i=0,n=e?u.tweens.length:0
if(s)return this
for(s=!0;n>i;i++)u.tweens[i].run(1)
return e?a.resolveWith(t,[u,e]):a.rejectWith(t,[u,e]),this}}),h=u.props
for(j(h,u.opts.specialEasing);o>r;r++)if(n=ye[r].call(u,t,h,u.opts))return n
return st.map(h,L,u),st.isFunction(u.opts.start)&&u.opts.start.call(t,u),st.fx.timer(st.extend(l,{elem:t,anim:u,queue:u.opts.queue})),u.progress(u.opts.progress).done(u.opts.done,u.opts.complete).fail(u.opts.fail).always(u.opts.always)}function F(t){return function(e,i){"string"!=typeof e&&(i=e,e="*")
var n,s=0,r=e.toLowerCase().match(_t)||[]
if(st.isFunction(i))for(;n=r[s++];)"+"===n.charAt(0)?(n=n.slice(1)||"*",(t[n]=t[n]||[]).unshift(i)):(t[n]=t[n]||[]).push(i)}}function $(t,e,i,n){function s(a){var l
return r[a]=!0,st.each(t[a]||[],function(t,a){var u=a(e,i,n)
return"string"!=typeof u||o||r[u]?o?!(l=u):void 0:(e.dataTypes.unshift(u),s(u),!1)}),l}var r={},o=t===Ye
return s(e.dataTypes[0])||!r["*"]&&s("*")}function U(t,e){var i,n,s=st.ajaxSettings.flatOptions||{}
for(n in e)void 0!==e[n]&&((s[n]?t:i||(i={}))[n]=e[n])
return i&&st.extend(!0,t,i),t}function R(t,e,i){for(var n,s,r,o,a=t.contents,l=t.dataTypes;"*"===l[0];)l.shift(),void 0===s&&(s=t.mimeType||e.getResponseHeader("Content-Type"))
if(s)for(o in a)if(a[o]&&a[o].test(s)){l.unshift(o)
break}if(l[0]in i)r=l[0]
else{for(o in i){if(!l[0]||t.converters[o+" "+l[0]]){r=o
break}n||(n=o)}r=r||n}return r?(r!==l[0]&&l.unshift(r),i[r]):void 0}function Y(t,e,i,n){var s,r,o,a,l,u={},h=t.dataTypes.slice()
if(h[1])for(o in t.converters)u[o.toLowerCase()]=t.converters[o]
for(r=h.shift();r;)if(t.responseFields[r]&&(i[t.responseFields[r]]=e),!l&&n&&t.dataFilter&&(e=t.dataFilter(e,t.dataType)),l=r,r=h.shift())if("*"===r)r=l
else if("*"!==l&&l!==r){if(o=u[l+" "+r]||u["* "+r],!o)for(s in u)if(a=s.split(" "),a[1]===r&&(o=u[l+" "+a[0]]||u["* "+a[0]])){o===!0?o=u[s]:u[s]!==!0&&(r=a[0],h.unshift(a[1]))
break}if(o!==!0)if(o&&t.throws)e=o(e)
else try{e=o(e)}catch(t){return{state:"parsererror",error:o?t:"No conversion from "+l+" to "+r}}}return{state:"success",data:e}}function q(t,e,i,n){var s
if(st.isArray(e))st.each(e,function(e,s){i||Be.test(t)?n(t,s):q(t+"["+("object"==typeof s?e:"")+"]",s,i,n)})
else if(i||"object"!==st.type(e))n(t,e)
else for(s in e)q(t+"["+s+"]",e[s],i,n)}function V(){try{return new t.XMLHttpRequest}catch(t){}}function B(){try{return new t.ActiveXObject("Microsoft.XMLHTTP")}catch(t){}}function z(t){return st.isWindow(t)?t:9===t.nodeType&&(t.defaultView||t.parentWindow)}var G=[],X=G.slice,J=G.concat,Q=G.push,Z=G.indexOf,K={},tt=K.toString,et=K.hasOwnProperty,it={},nt="1.11.3",st=function(t,e){return new st.fn.init(t,e)},rt=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,ot=/^-ms-/,at=/-([\da-z])/gi,lt=function(t,e){return e.toUpperCase()}
st.fn=st.prototype={jquery:nt,constructor:st,selector:"",length:0,toArray:function(){return X.call(this)},get:function(t){return null!=t?0>t?this[t+this.length]:this[t]:X.call(this)},pushStack:function(t){var e=st.merge(this.constructor(),t)
return e.prevObject=this,e.context=this.context,e},each:function(t,e){return st.each(this,t,e)},map:function(t){return this.pushStack(st.map(this,function(e,i){return t.call(e,i,e)}))},slice:function(){return this.pushStack(X.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},eq:function(t){var e=this.length,i=+t+(0>t?e:0)
return this.pushStack(i>=0&&e>i?[this[i]]:[])},end:function(){return this.prevObject||this.constructor(null)},push:Q,sort:G.sort,splice:G.splice},st.extend=st.fn.extend=function(){var t,e,i,n,s,r,o=arguments[0]||{},a=1,l=arguments.length,u=!1
for("boolean"==typeof o&&(u=o,o=arguments[a]||{},a++),"object"==typeof o||st.isFunction(o)||(o={}),a===l&&(o=this,a--);l>a;a++)if(null!=(s=arguments[a]))for(n in s)t=o[n],i=s[n],o!==i&&(u&&i&&(st.isPlainObject(i)||(e=st.isArray(i)))?(e?(e=!1,r=t&&st.isArray(t)?t:[]):r=t&&st.isPlainObject(t)?t:{},o[n]=st.extend(u,r,i)):void 0!==i&&(o[n]=i))
return o},st.extend({expando:"jQuery"+(nt+Math.random()).replace(/\D/g,""),isReady:!0,error:function(t){throw new Error(t)},noop:function(){},isFunction:function(t){return"function"===st.type(t)},isArray:Array.isArray||function(t){return"array"===st.type(t)},isWindow:function(t){return null!=t&&t==t.window},isNumeric:function(t){return!st.isArray(t)&&t-parseFloat(t)+1>=0},isEmptyObject:function(t){var e
for(e in t)return!1
return!0},isPlainObject:function(t){var e
if(!t||"object"!==st.type(t)||t.nodeType||st.isWindow(t))return!1
try{if(t.constructor&&!et.call(t,"constructor")&&!et.call(t.constructor.prototype,"isPrototypeOf"))return!1}catch(t){return!1}if(it.ownLast)for(e in t)return et.call(t,e)
for(e in t);return void 0===e||et.call(t,e)},type:function(t){return null==t?t+"":"object"==typeof t||"function"==typeof t?K[tt.call(t)]||"object":typeof t},globalEval:function(e){e&&st.trim(e)&&(t.execScript||function(e){t.eval.call(t,e)})(e)},camelCase:function(t){return t.replace(ot,"ms-").replace(at,lt)},nodeName:function(t,e){return t.nodeName&&t.nodeName.toLowerCase()===e.toLowerCase()},each:function(t,e,n){var s,r=0,o=t.length,a=i(t)
if(n){if(a)for(;o>r&&(s=e.apply(t[r],n),s!==!1);r++);else for(r in t)if(s=e.apply(t[r],n),s===!1)break}else if(a)for(;o>r&&(s=e.call(t[r],r,t[r]),s!==!1);r++);else for(r in t)if(s=e.call(t[r],r,t[r]),s===!1)break
return t},trim:function(t){return null==t?"":(t+"").replace(rt,"")},makeArray:function(t,e){var n=e||[]
return null!=t&&(i(Object(t))?st.merge(n,"string"==typeof t?[t]:t):Q.call(n,t)),n},inArray:function(t,e,i){var n
if(e){if(Z)return Z.call(e,t,i)
for(n=e.length,i=i?0>i?Math.max(0,n+i):i:0;n>i;i++)if(i in e&&e[i]===t)return i}return-1},merge:function(t,e){for(var i=+e.length,n=0,s=t.length;i>n;)t[s++]=e[n++]
if(i!==i)for(;void 0!==e[n];)t[s++]=e[n++]
return t.length=s,t},grep:function(t,e,i){for(var n,s=[],r=0,o=t.length,a=!i;o>r;r++)n=!e(t[r],r),n!==a&&s.push(t[r])
return s},map:function(t,e,n){var s,r=0,o=t.length,a=i(t),l=[]
if(a)for(;o>r;r++)s=e(t[r],r,n),null!=s&&l.push(s)
else for(r in t)s=e(t[r],r,n),null!=s&&l.push(s)
return J.apply([],l)},guid:1,proxy:function(t,e){var i,n,s
return"string"==typeof e&&(s=t[e],e=t,t=s),st.isFunction(t)?(i=X.call(arguments,2),n=function(){return t.apply(e||this,i.concat(X.call(arguments)))},n.guid=t.guid=t.guid||st.guid++,n):void 0},now:function(){return+new Date},support:it}),st.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(t,e){K["[object "+e+"]"]=e.toLowerCase()})
var ut=function(t){function e(t,e,i,n){var s,r,o,a,l,u,c,f,p,m
if((e?e.ownerDocument||e:$)!==O&&A(e),e=e||O,i=i||[],a=e.nodeType,"string"!=typeof t||!t||1!==a&&9!==a&&11!==a)return i
if(!n&&I){if(11!==a&&(s=yt.exec(t)))if(o=s[1]){if(9===a){if(r=e.getElementById(o),!r||!r.parentNode)return i
if(r.id===o)return i.push(r),i}else if(e.ownerDocument&&(r=e.ownerDocument.getElementById(o))&&W(e,r)&&r.id===o)return i.push(r),i}else{if(s[2])return Z.apply(i,e.getElementsByTagName(t)),i
if((o=s[3])&&w.getElementsByClassName)return Z.apply(i,e.getElementsByClassName(o)),i}if(w.qsa&&(!L||!L.test(t))){if(f=c=F,p=e,m=1!==a&&t,1===a&&"object"!==e.nodeName.toLowerCase()){for(u=T(t),(c=e.getAttribute("id"))?f=c.replace(bt,"\\$&"):e.setAttribute("id",f),f="[id='"+f+"'] ",l=u.length;l--;)u[l]=f+d(u[l])
p=_t.test(t)&&h(e.parentNode)||e,m=u.join(",")}if(m)try{return Z.apply(i,p.querySelectorAll(m)),i}catch(t){}finally{c||e.removeAttribute("id")}}}return S(t.replace(lt,"$1"),e,i,n)}function i(){function t(i,n){return e.push(i+" ")>x.cacheLength&&delete t[e.shift()],t[i+" "]=n}var e=[]
return t}function n(t){return t[F]=!0,t}function s(t){var e=O.createElement("div")
try{return!!t(e)}catch(t){return!1}finally{e.parentNode&&e.parentNode.removeChild(e),e=null}}function r(t,e){for(var i=t.split("|"),n=t.length;n--;)x.attrHandle[i[n]]=e}function o(t,e){var i=e&&t,n=i&&1===t.nodeType&&1===e.nodeType&&(~e.sourceIndex||z)-(~t.sourceIndex||z)
if(n)return n
if(i)for(;i=i.nextSibling;)if(i===e)return-1
return t?1:-1}function a(t){return function(e){var i=e.nodeName.toLowerCase()
return"input"===i&&e.type===t}}function l(t){return function(e){var i=e.nodeName.toLowerCase()
return("input"===i||"button"===i)&&e.type===t}}function u(t){return n(function(e){return e=+e,n(function(i,n){for(var s,r=t([],i.length,e),o=r.length;o--;)i[s=r[o]]&&(i[s]=!(n[s]=i[s]))})})}function h(t){return t&&"undefined"!=typeof t.getElementsByTagName&&t}function c(){}function d(t){for(var e=0,i=t.length,n="";i>e;e++)n+=t[e].value
return n}function f(t,e,i){var n=e.dir,s=i&&"parentNode"===n,r=R++
return e.first?function(e,i,r){for(;e=e[n];)if(1===e.nodeType||s)return t(e,i,r)}:function(e,i,o){var a,l,u=[U,r]
if(o){for(;e=e[n];)if((1===e.nodeType||s)&&t(e,i,o))return!0}else for(;e=e[n];)if(1===e.nodeType||s){if(l=e[F]||(e[F]={}),(a=l[n])&&a[0]===U&&a[1]===r)return u[2]=a[2]
if(l[n]=u,u[2]=t(e,i,o))return!0}}}function p(t){return t.length>1?function(e,i,n){for(var s=t.length;s--;)if(!t[s](e,i,n))return!1
return!0}:t[0]}function m(t,i,n){for(var s=0,r=i.length;r>s;s++)e(t,i[s],n)
return n}function g(t,e,i,n,s){for(var r,o=[],a=0,l=t.length,u=null!=e;l>a;a++)(r=t[a])&&(!i||i(r,n,s))&&(o.push(r),u&&e.push(a))
return o}function v(t,e,i,s,r,o){return s&&!s[F]&&(s=v(s)),r&&!r[F]&&(r=v(r,o)),n(function(n,o,a,l){var u,h,c,d=[],f=[],p=o.length,v=n||m(e||"*",a.nodeType?[a]:a,[]),y=!t||!n&&e?v:g(v,d,t,a,l),_=i?r||(n?t:p||s)?[]:o:y
if(i&&i(y,_,a,l),s)for(u=g(_,f),s(u,[],a,l),h=u.length;h--;)(c=u[h])&&(_[f[h]]=!(y[f[h]]=c))
if(n){if(r||t){if(r){for(u=[],h=_.length;h--;)(c=_[h])&&u.push(y[h]=c)
r(null,_=[],u,l)}for(h=_.length;h--;)(c=_[h])&&(u=r?tt(n,c):d[h])>-1&&(n[u]=!(o[u]=c))}}else _=g(_===o?_.splice(p,_.length):_),r?r(null,o,_,l):Z.apply(o,_)})}function y(t){for(var e,i,n,s=t.length,r=x.relative[t[0].type],o=r||x.relative[" "],a=r?1:0,l=f(function(t){return t===e},o,!0),u=f(function(t){return tt(e,t)>-1},o,!0),h=[function(t,i,n){var s=!r&&(n||i!==M)||((e=i).nodeType?l(t,i,n):u(t,i,n))
return e=null,s}];s>a;a++)if(i=x.relative[t[a].type])h=[f(p(h),i)]
else{if(i=x.filter[t[a].type].apply(null,t[a].matches),i[F]){for(n=++a;s>n&&!x.relative[t[n].type];n++);return v(a>1&&p(h),a>1&&d(t.slice(0,a-1).concat({value:" "===t[a-2].type?"*":""})).replace(lt,"$1"),i,n>a&&y(t.slice(a,n)),s>n&&y(t=t.slice(n)),s>n&&d(t))}h.push(i)}return p(h)}function _(t,i){var s=i.length>0,r=t.length>0,o=function(n,o,a,l,u){var h,c,d,f=0,p="0",m=n&&[],v=[],y=M,_=n||r&&x.find.TAG("*",u),b=U+=null==y?1:Math.random()||.1,w=_.length
for(u&&(M=o!==O&&o);p!==w&&null!=(h=_[p]);p++){if(r&&h){for(c=0;d=t[c++];)if(d(h,o,a)){l.push(h)
break}u&&(U=b)}s&&((h=!d&&h)&&f--,n&&m.push(h))}if(f+=p,s&&p!==f){for(c=0;d=i[c++];)d(m,v,o,a)
if(n){if(f>0)for(;p--;)m[p]||v[p]||(v[p]=J.call(l))
v=g(v)}Z.apply(l,v),u&&!n&&v.length>0&&f+i.length>1&&e.uniqueSort(l)}return u&&(U=b,M=y),m}
return s?n(o):o}var b,w,x,k,D,T,C,S,M,E,N,A,O,P,I,L,H,j,W,F="sizzle"+1*new Date,$=t.document,U=0,R=0,Y=i(),q=i(),V=i(),B=function(t,e){return t===e&&(N=!0),0},z=1<<31,G={}.hasOwnProperty,X=[],J=X.pop,Q=X.push,Z=X.push,K=X.slice,tt=function(t,e){for(var i=0,n=t.length;n>i;i++)if(t[i]===e)return i
return-1},et="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",it="[\\x20\\t\\r\\n\\f]",nt="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",st=nt.replace("w","w#"),rt="\\["+it+"*("+nt+")(?:"+it+"*([*^$|!~]?=)"+it+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+st+"))|)"+it+"*\\]",ot=":("+nt+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+rt+")*)|.*)\\)|)",at=new RegExp(it+"+","g"),lt=new RegExp("^"+it+"+|((?:^|[^\\\\])(?:\\\\.)*)"+it+"+$","g"),ut=new RegExp("^"+it+"*,"+it+"*"),ht=new RegExp("^"+it+"*([>+~]|"+it+")"+it+"*"),ct=new RegExp("="+it+"*([^\\]'\"]*?)"+it+"*\\]","g"),dt=new RegExp(ot),ft=new RegExp("^"+st+"$"),pt={ID:new RegExp("^#("+nt+")"),CLASS:new RegExp("^\\.("+nt+")"),TAG:new RegExp("^("+nt.replace("w","w*")+")"),ATTR:new RegExp("^"+rt),PSEUDO:new RegExp("^"+ot),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+it+"*(even|odd|(([+-]|)(\\d*)n|)"+it+"*(?:([+-]|)"+it+"*(\\d+)|))"+it+"*\\)|)","i"),bool:new RegExp("^(?:"+et+")$","i"),needsContext:new RegExp("^"+it+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+it+"*((?:-\\d)?\\d*)"+it+"*\\)|)(?=[^-]|$)","i")},mt=/^(?:input|select|textarea|button)$/i,gt=/^h\d$/i,vt=/^[^{]+\{\s*\[native \w/,yt=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,_t=/[+~]/,bt=/'|\\/g,wt=new RegExp("\\\\([\\da-f]{1,6}"+it+"?|("+it+")|.)","ig"),xt=function(t,e,i){var n="0x"+e-65536
return n!==n||i?e:0>n?String.fromCharCode(n+65536):String.fromCharCode(n>>10|55296,1023&n|56320)},kt=function(){A()}
try{Z.apply(X=K.call($.childNodes),$.childNodes),X[$.childNodes.length].nodeType}catch(t){Z={apply:X.length?function(t,e){Q.apply(t,K.call(e))}:function(t,e){for(var i=t.length,n=0;t[i++]=e[n++];);t.length=i-1}}}w=e.support={},D=e.isXML=function(t){var e=t&&(t.ownerDocument||t).documentElement
return!!e&&"HTML"!==e.nodeName},A=e.setDocument=function(t){var e,i,n=t?t.ownerDocument||t:$
return n!==O&&9===n.nodeType&&n.documentElement?(O=n,P=n.documentElement,i=n.defaultView,i&&i!==i.top&&(i.addEventListener?i.addEventListener("unload",kt,!1):i.attachEvent&&i.attachEvent("onunload",kt)),I=!D(n),w.attributes=s(function(t){return t.className="i",!t.getAttribute("className")}),w.getElementsByTagName=s(function(t){return t.appendChild(n.createComment("")),!t.getElementsByTagName("*").length}),w.getElementsByClassName=vt.test(n.getElementsByClassName),w.getById=s(function(t){return P.appendChild(t).id=F,!n.getElementsByName||!n.getElementsByName(F).length}),w.getById?(x.find.ID=function(t,e){if("undefined"!=typeof e.getElementById&&I){var i=e.getElementById(t)
return i&&i.parentNode?[i]:[]}},x.filter.ID=function(t){var e=t.replace(wt,xt)
return function(t){return t.getAttribute("id")===e}}):(delete x.find.ID,x.filter.ID=function(t){var e=t.replace(wt,xt)
return function(t){var i="undefined"!=typeof t.getAttributeNode&&t.getAttributeNode("id")
return i&&i.value===e}}),x.find.TAG=w.getElementsByTagName?function(t,e){return"undefined"!=typeof e.getElementsByTagName?e.getElementsByTagName(t):w.qsa?e.querySelectorAll(t):void 0}:function(t,e){var i,n=[],s=0,r=e.getElementsByTagName(t)
if("*"===t){for(;i=r[s++];)1===i.nodeType&&n.push(i)
return n}return r},x.find.CLASS=w.getElementsByClassName&&function(t,e){return I?e.getElementsByClassName(t):void 0},H=[],L=[],(w.qsa=vt.test(n.querySelectorAll))&&(s(function(t){P.appendChild(t).innerHTML="<a id='"+F+"'></a><select id='"+F+"-\f]' msallowcapture=''><option selected=''></option></select>",t.querySelectorAll("[msallowcapture^='']").length&&L.push("[*^$]="+it+"*(?:''|\"\")"),t.querySelectorAll("[selected]").length||L.push("\\["+it+"*(?:value|"+et+")"),t.querySelectorAll("[id~="+F+"-]").length||L.push("~="),t.querySelectorAll(":checked").length||L.push(":checked"),t.querySelectorAll("a#"+F+"+*").length||L.push(".#.+[+~]")}),s(function(t){var e=n.createElement("input")
e.setAttribute("type","hidden"),t.appendChild(e).setAttribute("name","D"),t.querySelectorAll("[name=d]").length&&L.push("name"+it+"*[*^$|!~]?="),t.querySelectorAll(":enabled").length||L.push(":enabled",":disabled"),t.querySelectorAll("*,:x"),L.push(",.*:")})),(w.matchesSelector=vt.test(j=P.matches||P.webkitMatchesSelector||P.mozMatchesSelector||P.oMatchesSelector||P.msMatchesSelector))&&s(function(t){w.disconnectedMatch=j.call(t,"div"),j.call(t,"[s!='']:x"),H.push("!=",ot)}),L=L.length&&new RegExp(L.join("|")),H=H.length&&new RegExp(H.join("|")),e=vt.test(P.compareDocumentPosition),W=e||vt.test(P.contains)?function(t,e){var i=9===t.nodeType?t.documentElement:t,n=e&&e.parentNode
return t===n||!(!n||1!==n.nodeType||!(i.contains?i.contains(n):t.compareDocumentPosition&&16&t.compareDocumentPosition(n)))}:function(t,e){if(e)for(;e=e.parentNode;)if(e===t)return!0
return!1},B=e?function(t,e){if(t===e)return N=!0,0
var i=!t.compareDocumentPosition-!e.compareDocumentPosition
return i?i:(i=(t.ownerDocument||t)===(e.ownerDocument||e)?t.compareDocumentPosition(e):1,1&i||!w.sortDetached&&e.compareDocumentPosition(t)===i?t===n||t.ownerDocument===$&&W($,t)?-1:e===n||e.ownerDocument===$&&W($,e)?1:E?tt(E,t)-tt(E,e):0:4&i?-1:1)}:function(t,e){if(t===e)return N=!0,0
var i,s=0,r=t.parentNode,a=e.parentNode,l=[t],u=[e]
if(!r||!a)return t===n?-1:e===n?1:r?-1:a?1:E?tt(E,t)-tt(E,e):0
if(r===a)return o(t,e)
for(i=t;i=i.parentNode;)l.unshift(i)
for(i=e;i=i.parentNode;)u.unshift(i)
for(;l[s]===u[s];)s++
return s?o(l[s],u[s]):l[s]===$?-1:u[s]===$?1:0},n):O},e.matches=function(t,i){return e(t,null,null,i)},e.matchesSelector=function(t,i){if((t.ownerDocument||t)!==O&&A(t),i=i.replace(ct,"='$1']"),!(!w.matchesSelector||!I||H&&H.test(i)||L&&L.test(i)))try{var n=j.call(t,i)
if(n||w.disconnectedMatch||t.document&&11!==t.document.nodeType)return n}catch(t){}return e(i,O,null,[t]).length>0},e.contains=function(t,e){return(t.ownerDocument||t)!==O&&A(t),W(t,e)},e.attr=function(t,e){(t.ownerDocument||t)!==O&&A(t)
var i=x.attrHandle[e.toLowerCase()],n=i&&G.call(x.attrHandle,e.toLowerCase())?i(t,e,!I):void 0
return void 0!==n?n:w.attributes||!I?t.getAttribute(e):(n=t.getAttributeNode(e))&&n.specified?n.value:null},e.error=function(t){throw new Error("Syntax error, unrecognized expression: "+t)},e.uniqueSort=function(t){var e,i=[],n=0,s=0
if(N=!w.detectDuplicates,E=!w.sortStable&&t.slice(0),t.sort(B),N){for(;e=t[s++];)e===t[s]&&(n=i.push(s))
for(;n--;)t.splice(i[n],1)}return E=null,t},k=e.getText=function(t){var e,i="",n=0,s=t.nodeType
if(s){if(1===s||9===s||11===s){if("string"==typeof t.textContent)return t.textContent
for(t=t.firstChild;t;t=t.nextSibling)i+=k(t)}else if(3===s||4===s)return t.nodeValue}else for(;e=t[n++];)i+=k(e)
return i},x=e.selectors={cacheLength:50,createPseudo:n,match:pt,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(t){return t[1]=t[1].replace(wt,xt),t[3]=(t[3]||t[4]||t[5]||"").replace(wt,xt),"~="===t[2]&&(t[3]=" "+t[3]+" "),t.slice(0,4)},CHILD:function(t){return t[1]=t[1].toLowerCase(),"nth"===t[1].slice(0,3)?(t[3]||e.error(t[0]),t[4]=+(t[4]?t[5]+(t[6]||1):2*("even"===t[3]||"odd"===t[3])),t[5]=+(t[7]+t[8]||"odd"===t[3])):t[3]&&e.error(t[0]),t},PSEUDO:function(t){var e,i=!t[6]&&t[2]
return pt.CHILD.test(t[0])?null:(t[3]?t[2]=t[4]||t[5]||"":i&&dt.test(i)&&(e=T(i,!0))&&(e=i.indexOf(")",i.length-e)-i.length)&&(t[0]=t[0].slice(0,e),t[2]=i.slice(0,e)),t.slice(0,3))}},filter:{TAG:function(t){var e=t.replace(wt,xt).toLowerCase()
return"*"===t?function(){return!0}:function(t){return t.nodeName&&t.nodeName.toLowerCase()===e}},CLASS:function(t){var e=Y[t+" "]
return e||(e=new RegExp("(^|"+it+")"+t+"("+it+"|$)"))&&Y(t,function(t){return e.test("string"==typeof t.className&&t.className||"undefined"!=typeof t.getAttribute&&t.getAttribute("class")||"")})},ATTR:function(t,i,n){return function(s){var r=e.attr(s,t)
return null==r?"!="===i:!i||(r+="","="===i?r===n:"!="===i?r!==n:"^="===i?n&&0===r.indexOf(n):"*="===i?n&&r.indexOf(n)>-1:"$="===i?n&&r.slice(-n.length)===n:"~="===i?(" "+r.replace(at," ")+" ").indexOf(n)>-1:"|="===i&&(r===n||r.slice(0,n.length+1)===n+"-"))}},CHILD:function(t,e,i,n,s){var r="nth"!==t.slice(0,3),o="last"!==t.slice(-4),a="of-type"===e
return 1===n&&0===s?function(t){return!!t.parentNode}:function(e,i,l){var u,h,c,d,f,p,m=r!==o?"nextSibling":"previousSibling",g=e.parentNode,v=a&&e.nodeName.toLowerCase(),y=!l&&!a
if(g){if(r){for(;m;){for(c=e;c=c[m];)if(a?c.nodeName.toLowerCase()===v:1===c.nodeType)return!1
p=m="only"===t&&!p&&"nextSibling"}return!0}if(p=[o?g.firstChild:g.lastChild],o&&y){for(h=g[F]||(g[F]={}),u=h[t]||[],f=u[0]===U&&u[1],d=u[0]===U&&u[2],c=f&&g.childNodes[f];c=++f&&c&&c[m]||(d=f=0)||p.pop();)if(1===c.nodeType&&++d&&c===e){h[t]=[U,f,d]
break}}else if(y&&(u=(e[F]||(e[F]={}))[t])&&u[0]===U)d=u[1]
else for(;(c=++f&&c&&c[m]||(d=f=0)||p.pop())&&((a?c.nodeName.toLowerCase()!==v:1!==c.nodeType)||!++d||(y&&((c[F]||(c[F]={}))[t]=[U,d]),c!==e)););return d-=s,d===n||d%n===0&&d/n>=0}}},PSEUDO:function(t,i){var s,r=x.pseudos[t]||x.setFilters[t.toLowerCase()]||e.error("unsupported pseudo: "+t)
return r[F]?r(i):r.length>1?(s=[t,t,"",i],x.setFilters.hasOwnProperty(t.toLowerCase())?n(function(t,e){for(var n,s=r(t,i),o=s.length;o--;)n=tt(t,s[o]),t[n]=!(e[n]=s[o])}):function(t){return r(t,0,s)}):r}},pseudos:{not:n(function(t){var e=[],i=[],s=C(t.replace(lt,"$1"))
return s[F]?n(function(t,e,i,n){for(var r,o=s(t,null,n,[]),a=t.length;a--;)(r=o[a])&&(t[a]=!(e[a]=r))}):function(t,n,r){return e[0]=t,s(e,null,r,i),e[0]=null,!i.pop()}}),has:n(function(t){return function(i){return e(t,i).length>0}}),contains:n(function(t){return t=t.replace(wt,xt),function(e){return(e.textContent||e.innerText||k(e)).indexOf(t)>-1}}),lang:n(function(t){return ft.test(t||"")||e.error("unsupported lang: "+t),t=t.replace(wt,xt).toLowerCase(),function(e){var i
do if(i=I?e.lang:e.getAttribute("xml:lang")||e.getAttribute("lang"))return i=i.toLowerCase(),i===t||0===i.indexOf(t+"-")
while((e=e.parentNode)&&1===e.nodeType)
return!1}}),target:function(e){var i=t.location&&t.location.hash
return i&&i.slice(1)===e.id},root:function(t){return t===P},focus:function(t){return t===O.activeElement&&(!O.hasFocus||O.hasFocus())&&!!(t.type||t.href||~t.tabIndex)},enabled:function(t){return t.disabled===!1},disabled:function(t){return t.disabled===!0},checked:function(t){var e=t.nodeName.toLowerCase()
return"input"===e&&!!t.checked||"option"===e&&!!t.selected},selected:function(t){return t.parentNode&&t.parentNode.selectedIndex,t.selected===!0},empty:function(t){for(t=t.firstChild;t;t=t.nextSibling)if(t.nodeType<6)return!1
return!0},parent:function(t){return!x.pseudos.empty(t)},header:function(t){return gt.test(t.nodeName)},input:function(t){return mt.test(t.nodeName)},button:function(t){var e=t.nodeName.toLowerCase()
return"input"===e&&"button"===t.type||"button"===e},text:function(t){var e
return"input"===t.nodeName.toLowerCase()&&"text"===t.type&&(null==(e=t.getAttribute("type"))||"text"===e.toLowerCase())},first:u(function(){return[0]}),last:u(function(t,e){return[e-1]}),eq:u(function(t,e,i){return[0>i?i+e:i]}),even:u(function(t,e){for(var i=0;e>i;i+=2)t.push(i)
return t}),odd:u(function(t,e){for(var i=1;e>i;i+=2)t.push(i)
return t}),lt:u(function(t,e,i){for(var n=0>i?i+e:i;--n>=0;)t.push(n)
return t}),gt:u(function(t,e,i){for(var n=0>i?i+e:i;++n<e;)t.push(n)
return t})}},x.pseudos.nth=x.pseudos.eq
for(b in{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})x.pseudos[b]=a(b)
for(b in{submit:!0,reset:!0})x.pseudos[b]=l(b)
return c.prototype=x.filters=x.pseudos,x.setFilters=new c,T=e.tokenize=function(t,i){var n,s,r,o,a,l,u,h=q[t+" "]
if(h)return i?0:h.slice(0)
for(a=t,l=[],u=x.preFilter;a;){(!n||(s=ut.exec(a)))&&(s&&(a=a.slice(s[0].length)||a),l.push(r=[])),n=!1,(s=ht.exec(a))&&(n=s.shift(),r.push({value:n,type:s[0].replace(lt," ")}),a=a.slice(n.length))
for(o in x.filter)!(s=pt[o].exec(a))||u[o]&&!(s=u[o](s))||(n=s.shift(),r.push({value:n,type:o,matches:s}),a=a.slice(n.length))
if(!n)break}return i?a.length:a?e.error(t):q(t,l).slice(0)},C=e.compile=function(t,e){var i,n=[],s=[],r=V[t+" "]
if(!r){for(e||(e=T(t)),i=e.length;i--;)r=y(e[i]),r[F]?n.push(r):s.push(r)
r=V(t,_(s,n)),r.selector=t}return r},S=e.select=function(t,e,i,n){var s,r,o,a,l,u="function"==typeof t&&t,c=!n&&T(t=u.selector||t)
if(i=i||[],1===c.length){if(r=c[0]=c[0].slice(0),r.length>2&&"ID"===(o=r[0]).type&&w.getById&&9===e.nodeType&&I&&x.relative[r[1].type]){if(e=(x.find.ID(o.matches[0].replace(wt,xt),e)||[])[0],!e)return i
u&&(e=e.parentNode),t=t.slice(r.shift().value.length)}for(s=pt.needsContext.test(t)?0:r.length;s--&&(o=r[s],!x.relative[a=o.type]);)if((l=x.find[a])&&(n=l(o.matches[0].replace(wt,xt),_t.test(r[0].type)&&h(e.parentNode)||e))){if(r.splice(s,1),t=n.length&&d(r),!t)return Z.apply(i,n),i
break}}return(u||C(t,c))(n,e,!I,i,_t.test(t)&&h(e.parentNode)||e),i},w.sortStable=F.split("").sort(B).join("")===F,w.detectDuplicates=!!N,A(),w.sortDetached=s(function(t){return 1&t.compareDocumentPosition(O.createElement("div"))}),s(function(t){return t.innerHTML="<a href='#'></a>","#"===t.firstChild.getAttribute("href")})||r("type|href|height|width",function(t,e,i){return i?void 0:t.getAttribute(e,"type"===e.toLowerCase()?1:2)}),w.attributes&&s(function(t){return t.innerHTML="<input/>",t.firstChild.setAttribute("value",""),""===t.firstChild.getAttribute("value")})||r("value",function(t,e,i){return i||"input"!==t.nodeName.toLowerCase()?void 0:t.defaultValue}),s(function(t){return null==t.getAttribute("disabled")})||r(et,function(t,e,i){var n
return i?void 0:t[e]===!0?e.toLowerCase():(n=t.getAttributeNode(e))&&n.specified?n.value:null}),e}(t)
st.find=ut,st.expr=ut.selectors,st.expr[":"]=st.expr.pseudos,st.unique=ut.uniqueSort,st.text=ut.getText,st.isXMLDoc=ut.isXML,st.contains=ut.contains
var ht=st.expr.match.needsContext,ct=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,dt=/^.[^:#\[\.,]*$/
st.filter=function(t,e,i){var n=e[0]
return i&&(t=":not("+t+")"),1===e.length&&1===n.nodeType?st.find.matchesSelector(n,t)?[n]:[]:st.find.matches(t,st.grep(e,function(t){return 1===t.nodeType}))},st.fn.extend({find:function(t){var e,i=[],n=this,s=n.length
if("string"!=typeof t)return this.pushStack(st(t).filter(function(){for(e=0;s>e;e++)if(st.contains(n[e],this))return!0}))
for(e=0;s>e;e++)st.find(t,n[e],i)
return i=this.pushStack(s>1?st.unique(i):i),i.selector=this.selector?this.selector+" "+t:t,i},filter:function(t){return this.pushStack(n(this,t||[],!1))},not:function(t){return this.pushStack(n(this,t||[],!0))},is:function(t){return!!n(this,"string"==typeof t&&ht.test(t)?st(t):t||[],!1).length}})
var ft,pt=t.document,mt=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,gt=st.fn.init=function(t,e){var i,n
if(!t)return this
if("string"==typeof t){if(i="<"===t.charAt(0)&&">"===t.charAt(t.length-1)&&t.length>=3?[null,t,null]:mt.exec(t),!i||!i[1]&&e)return!e||e.jquery?(e||ft).find(t):this.constructor(e).find(t)
if(i[1]){if(e=e instanceof st?e[0]:e,st.merge(this,st.parseHTML(i[1],e&&e.nodeType?e.ownerDocument||e:pt,!0)),ct.test(i[1])&&st.isPlainObject(e))for(i in e)st.isFunction(this[i])?this[i](e[i]):this.attr(i,e[i])
return this}if(n=pt.getElementById(i[2]),n&&n.parentNode){if(n.id!==i[2])return ft.find(t)
this.length=1,this[0]=n}return this.context=pt,this.selector=t,this}return t.nodeType?(this.context=this[0]=t,this.length=1,this):st.isFunction(t)?"undefined"!=typeof ft.ready?ft.ready(t):t(st):(void 0!==t.selector&&(this.selector=t.selector,this.context=t.context),st.makeArray(t,this))}
gt.prototype=st.fn,ft=st(pt)
var vt=/^(?:parents|prev(?:Until|All))/,yt={children:!0,contents:!0,next:!0,prev:!0}
st.extend({dir:function(t,e,i){for(var n=[],s=t[e];s&&9!==s.nodeType&&(void 0===i||1!==s.nodeType||!st(s).is(i));)1===s.nodeType&&n.push(s),s=s[e]
return n},sibling:function(t,e){for(var i=[];t;t=t.nextSibling)1===t.nodeType&&t!==e&&i.push(t)
return i}}),st.fn.extend({has:function(t){var e,i=st(t,this),n=i.length
return this.filter(function(){for(e=0;n>e;e++)if(st.contains(this,i[e]))return!0})},closest:function(t,e){for(var i,n=0,s=this.length,r=[],o=ht.test(t)||"string"!=typeof t?st(t,e||this.context):0;s>n;n++)for(i=this[n];i&&i!==e;i=i.parentNode)if(i.nodeType<11&&(o?o.index(i)>-1:1===i.nodeType&&st.find.matchesSelector(i,t))){r.push(i)
break}return this.pushStack(r.length>1?st.unique(r):r)},index:function(t){return t?"string"==typeof t?st.inArray(this[0],st(t)):st.inArray(t.jquery?t[0]:t,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(t,e){return this.pushStack(st.unique(st.merge(this.get(),st(t,e))))},addBack:function(t){return this.add(null==t?this.prevObject:this.prevObject.filter(t))}}),st.each({parent:function(t){var e=t.parentNode
return e&&11!==e.nodeType?e:null},parents:function(t){return st.dir(t,"parentNode")},parentsUntil:function(t,e,i){return st.dir(t,"parentNode",i)},next:function(t){return s(t,"nextSibling")},prev:function(t){return s(t,"previousSibling")},nextAll:function(t){return st.dir(t,"nextSibling")},prevAll:function(t){return st.dir(t,"previousSibling")},nextUntil:function(t,e,i){return st.dir(t,"nextSibling",i)},prevUntil:function(t,e,i){return st.dir(t,"previousSibling",i)},siblings:function(t){return st.sibling((t.parentNode||{}).firstChild,t)},children:function(t){return st.sibling(t.firstChild)},contents:function(t){return st.nodeName(t,"iframe")?t.contentDocument||t.contentWindow.document:st.merge([],t.childNodes)}},function(t,e){st.fn[t]=function(i,n){var s=st.map(this,e,i)
return"Until"!==t.slice(-5)&&(n=i),n&&"string"==typeof n&&(s=st.filter(n,s)),this.length>1&&(yt[t]||(s=st.unique(s)),vt.test(t)&&(s=s.reverse())),this.pushStack(s)}})
var _t=/\S+/g,bt={}
st.Callbacks=function(t){t="string"==typeof t?bt[t]||r(t):st.extend({},t)
var e,i,n,s,o,a,l=[],u=!t.once&&[],h=function(r){for(i=t.memory&&r,n=!0,o=a||0,a=0,s=l.length,e=!0;l&&s>o;o++)if(l[o].apply(r[0],r[1])===!1&&t.stopOnFalse){i=!1
break}e=!1,l&&(u?u.length&&h(u.shift()):i?l=[]:c.disable())},c={add:function(){if(l){var n=l.length
!function e(i){st.each(i,function(i,n){var s=st.type(n)
"function"===s?t.unique&&c.has(n)||l.push(n):n&&n.length&&"string"!==s&&e(n)})}(arguments),e?s=l.length:i&&(a=n,h(i))}return this},remove:function(){return l&&st.each(arguments,function(t,i){for(var n;(n=st.inArray(i,l,n))>-1;)l.splice(n,1),e&&(s>=n&&s--,o>=n&&o--)}),this},has:function(t){return t?st.inArray(t,l)>-1:!(!l||!l.length)},empty:function(){return l=[],s=0,this},disable:function(){return l=u=i=void 0,this},disabled:function(){return!l},lock:function(){return u=void 0,i||c.disable(),this},locked:function(){return!u},fireWith:function(t,i){return!l||n&&!u||(i=i||[],i=[t,i.slice?i.slice():i],e?u.push(i):h(i)),this},fire:function(){return c.fireWith(this,arguments),this},fired:function(){return!!n}}
return c},st.extend({Deferred:function(t){var e=[["resolve","done",st.Callbacks("once memory"),"resolved"],["reject","fail",st.Callbacks("once memory"),"rejected"],["notify","progress",st.Callbacks("memory")]],i="pending",n={state:function(){return i},always:function(){return s.done(arguments).fail(arguments),this},then:function(){var t=arguments
return st.Deferred(function(i){st.each(e,function(e,r){var o=st.isFunction(t[e])&&t[e]
s[r[1]](function(){var t=o&&o.apply(this,arguments)
t&&st.isFunction(t.promise)?t.promise().done(i.resolve).fail(i.reject).progress(i.notify):i[r[0]+"With"](this===n?i.promise():this,o?[t]:arguments)})}),t=null}).promise()},promise:function(t){return null!=t?st.extend(t,n):n}},s={}
return n.pipe=n.then,st.each(e,function(t,r){var o=r[2],a=r[3]
n[r[1]]=o.add,a&&o.add(function(){i=a},e[1^t][2].disable,e[2][2].lock),s[r[0]]=function(){return s[r[0]+"With"](this===s?n:this,arguments),this},s[r[0]+"With"]=o.fireWith}),n.promise(s),t&&t.call(s,s),s},when:function(t){var e,i,n,s=0,r=X.call(arguments),o=r.length,a=1!==o||t&&st.isFunction(t.promise)?o:0,l=1===a?t:st.Deferred(),u=function(t,i,n){return function(s){i[t]=this,n[t]=arguments.length>1?X.call(arguments):s,n===e?l.notifyWith(i,n):--a||l.resolveWith(i,n)}}
if(o>1)for(e=new Array(o),i=new Array(o),n=new Array(o);o>s;s++)r[s]&&st.isFunction(r[s].promise)?r[s].promise().done(u(s,n,r)).fail(l.reject).progress(u(s,i,e)):--a
return a||l.resolveWith(n,r),l.promise()}})
var wt
st.fn.ready=function(t){return st.ready.promise().done(t),this},st.extend({isReady:!1,readyWait:1,holdReady:function(t){t?st.readyWait++:st.ready(!0)},ready:function(t){if(t===!0?!--st.readyWait:!st.isReady){if(!pt.body)return setTimeout(st.ready)
st.isReady=!0,t!==!0&&--st.readyWait>0||(wt.resolveWith(pt,[st]),st.fn.triggerHandler&&(st(pt).triggerHandler("ready"),st(pt).off("ready")))}}}),st.ready.promise=function(e){if(!wt)if(wt=st.Deferred(),"complete"===pt.readyState)setTimeout(st.ready)
else if(pt.addEventListener)pt.addEventListener("DOMContentLoaded",a,!1),t.addEventListener("load",a,!1)
else{pt.attachEvent("onreadystatechange",a),t.attachEvent("onload",a)
var i=!1
try{i=null==t.frameElement&&pt.documentElement}catch(t){}i&&i.doScroll&&!function t(){if(!st.isReady){try{i.doScroll("left")}catch(e){return setTimeout(t,50)}o(),st.ready()}}()}return wt.promise(e)}
var xt,kt="undefined"
for(xt in st(it))break
it.ownLast="0"!==xt,it.inlineBlockNeedsLayout=!1,st(function(){var t,e,i,n
i=pt.getElementsByTagName("body")[0],i&&i.style&&(e=pt.createElement("div"),n=pt.createElement("div"),n.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",i.appendChild(n).appendChild(e),typeof e.style.zoom!==kt&&(e.style.cssText="display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1",it.inlineBlockNeedsLayout=t=3===e.offsetWidth,t&&(i.style.zoom=1)),i.removeChild(n))}),function(){var t=pt.createElement("div")
if(null==it.deleteExpando){it.deleteExpando=!0
try{delete t.test}catch(t){it.deleteExpando=!1}}t=null}(),st.acceptData=function(t){var e=st.noData[(t.nodeName+" ").toLowerCase()],i=+t.nodeType||1
return(1===i||9===i)&&(!e||e!==!0&&t.getAttribute("classid")===e)}
var Dt=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,Tt=/([A-Z])/g
st.extend({cache:{},noData:{"applet ":!0,"embed ":!0,"object ":"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"},hasData:function(t){return t=t.nodeType?st.cache[t[st.expando]]:t[st.expando],!!t&&!u(t)},data:function(t,e,i){return h(t,e,i)},removeData:function(t,e){return c(t,e)},_data:function(t,e,i){return h(t,e,i,!0)},_removeData:function(t,e){return c(t,e,!0)}}),st.fn.extend({data:function(t,e){var i,n,s,r=this[0],o=r&&r.attributes
if(void 0===t){if(this.length&&(s=st.data(r),1===r.nodeType&&!st._data(r,"parsedAttrs"))){for(i=o.length;i--;)o[i]&&(n=o[i].name,0===n.indexOf("data-")&&(n=st.camelCase(n.slice(5)),l(r,n,s[n])))
st._data(r,"parsedAttrs",!0)}return s}return"object"==typeof t?this.each(function(){st.data(this,t)}):arguments.length>1?this.each(function(){st.data(this,t,e)}):r?l(r,t,st.data(r,t)):void 0},removeData:function(t){return this.each(function(){st.removeData(this,t)})}}),st.extend({queue:function(t,e,i){var n
return t?(e=(e||"fx")+"queue",n=st._data(t,e),i&&(!n||st.isArray(i)?n=st._data(t,e,st.makeArray(i)):n.push(i)),n||[]):void 0},dequeue:function(t,e){e=e||"fx"
var i=st.queue(t,e),n=i.length,s=i.shift(),r=st._queueHooks(t,e),o=function(){st.dequeue(t,e)}
"inprogress"===s&&(s=i.shift(),n--),s&&("fx"===e&&i.unshift("inprogress"),delete r.stop,s.call(t,o,r)),!n&&r&&r.empty.fire()},_queueHooks:function(t,e){var i=e+"queueHooks"
return st._data(t,i)||st._data(t,i,{empty:st.Callbacks("once memory").add(function(){st._removeData(t,e+"queue"),st._removeData(t,i)})})}}),st.fn.extend({queue:function(t,e){var i=2
return"string"!=typeof t&&(e=t,t="fx",i--),arguments.length<i?st.queue(this[0],t):void 0===e?this:this.each(function(){var i=st.queue(this,t,e)
st._queueHooks(this,t),"fx"===t&&"inprogress"!==i[0]&&st.dequeue(this,t)})},dequeue:function(t){return this.each(function(){st.dequeue(this,t)})},clearQueue:function(t){return this.queue(t||"fx",[])},promise:function(t,e){var i,n=1,s=st.Deferred(),r=this,o=this.length,a=function(){--n||s.resolveWith(r,[r])}
for("string"!=typeof t&&(e=t,t=void 0),t=t||"fx";o--;)i=st._data(r[o],t+"queueHooks"),i&&i.empty&&(n++,i.empty.add(a))
return a(),s.promise(e)}})
var Ct=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,St=["Top","Right","Bottom","Left"],Mt=function(t,e){return t=e||t,"none"===st.css(t,"display")||!st.contains(t.ownerDocument,t)},Et=st.access=function(t,e,i,n,s,r,o){var a=0,l=t.length,u=null==i
if("object"===st.type(i)){s=!0
for(a in i)st.access(t,e,a,i[a],!0,r,o)}else if(void 0!==n&&(s=!0,st.isFunction(n)||(o=!0),u&&(o?(e.call(t,n),e=null):(u=e,e=function(t,e,i){return u.call(st(t),i)})),e))for(;l>a;a++)e(t[a],i,o?n:n.call(t[a],a,e(t[a],i)))
return s?t:u?e.call(t):l?e(t[0],i):r},Nt=/^(?:checkbox|radio)$/i
!function(){var t=pt.createElement("input"),e=pt.createElement("div"),i=pt.createDocumentFragment()
if(e.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",it.leadingWhitespace=3===e.firstChild.nodeType,it.tbody=!e.getElementsByTagName("tbody").length,it.htmlSerialize=!!e.getElementsByTagName("link").length,it.html5Clone="<:nav></:nav>"!==pt.createElement("nav").cloneNode(!0).outerHTML,t.type="checkbox",t.checked=!0,i.appendChild(t),it.appendChecked=t.checked,e.innerHTML="<textarea>x</textarea>",it.noCloneChecked=!!e.cloneNode(!0).lastChild.defaultValue,i.appendChild(e),e.innerHTML="<input type='radio' checked='checked' name='t'/>",it.checkClone=e.cloneNode(!0).cloneNode(!0).lastChild.checked,it.noCloneEvent=!0,e.attachEvent&&(e.attachEvent("onclick",function(){it.noCloneEvent=!1}),e.cloneNode(!0).click()),null==it.deleteExpando){it.deleteExpando=!0
try{delete e.test}catch(t){it.deleteExpando=!1}}}(),function(){var e,i,n=pt.createElement("div")
for(e in{submit:!0,change:!0,focusin:!0})i="on"+e,(it[e+"Bubbles"]=i in t)||(n.setAttribute(i,"t"),it[e+"Bubbles"]=n.attributes[i].expando===!1)
n=null}()
var At=/^(?:input|select|textarea)$/i,Ot=/^key/,Pt=/^(?:mouse|pointer|contextmenu)|click/,It=/^(?:focusinfocus|focusoutblur)$/,Lt=/^([^.]*)(?:\.(.+)|)$/
st.event={global:{},add:function(t,e,i,n,s){var r,o,a,l,u,h,c,d,f,p,m,g=st._data(t)
if(g){for(i.handler&&(l=i,i=l.handler,s=l.selector),i.guid||(i.guid=st.guid++),(o=g.events)||(o=g.events={}),(h=g.handle)||(h=g.handle=function(t){return typeof st===kt||t&&st.event.triggered===t.type?void 0:st.event.dispatch.apply(h.elem,arguments)},h.elem=t),e=(e||"").match(_t)||[""],a=e.length;a--;)r=Lt.exec(e[a])||[],f=m=r[1],p=(r[2]||"").split(".").sort(),f&&(u=st.event.special[f]||{},f=(s?u.delegateType:u.bindType)||f,u=st.event.special[f]||{},c=st.extend({type:f,origType:m,data:n,handler:i,guid:i.guid,selector:s,needsContext:s&&st.expr.match.needsContext.test(s),namespace:p.join(".")},l),(d=o[f])||(d=o[f]=[],d.delegateCount=0,u.setup&&u.setup.call(t,n,p,h)!==!1||(t.addEventListener?t.addEventListener(f,h,!1):t.attachEvent&&t.attachEvent("on"+f,h))),u.add&&(u.add.call(t,c),c.handler.guid||(c.handler.guid=i.guid)),s?d.splice(d.delegateCount++,0,c):d.push(c),st.event.global[f]=!0)
t=null}},remove:function(t,e,i,n,s){var r,o,a,l,u,h,c,d,f,p,m,g=st.hasData(t)&&st._data(t)
if(g&&(h=g.events)){for(e=(e||"").match(_t)||[""],u=e.length;u--;)if(a=Lt.exec(e[u])||[],f=m=a[1],p=(a[2]||"").split(".").sort(),f){for(c=st.event.special[f]||{},f=(n?c.delegateType:c.bindType)||f,d=h[f]||[],a=a[2]&&new RegExp("(^|\\.)"+p.join("\\.(?:.*\\.|)")+"(\\.|$)"),l=r=d.length;r--;)o=d[r],!s&&m!==o.origType||i&&i.guid!==o.guid||a&&!a.test(o.namespace)||n&&n!==o.selector&&("**"!==n||!o.selector)||(d.splice(r,1),o.selector&&d.delegateCount--,c.remove&&c.remove.call(t,o))
l&&!d.length&&(c.teardown&&c.teardown.call(t,p,g.handle)!==!1||st.removeEvent(t,f,g.handle),delete h[f])}else for(f in h)st.event.remove(t,f+e[u],i,n,!0)
st.isEmptyObject(h)&&(delete g.handle,st._removeData(t,"events"))}},trigger:function(e,i,n,s){var r,o,a,l,u,h,c,d=[n||pt],f=et.call(e,"type")?e.type:e,p=et.call(e,"namespace")?e.namespace.split("."):[]
if(a=h=n=n||pt,3!==n.nodeType&&8!==n.nodeType&&!It.test(f+st.event.triggered)&&(f.indexOf(".")>=0&&(p=f.split("."),f=p.shift(),p.sort()),o=f.indexOf(":")<0&&"on"+f,e=e[st.expando]?e:new st.Event(f,"object"==typeof e&&e),e.isTrigger=s?2:3,e.namespace=p.join("."),e.namespace_re=e.namespace?new RegExp("(^|\\.)"+p.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,e.result=void 0,e.target||(e.target=n),i=null==i?[e]:st.makeArray(i,[e]),u=st.event.special[f]||{},s||!u.trigger||u.trigger.apply(n,i)!==!1)){if(!s&&!u.noBubble&&!st.isWindow(n)){for(l=u.delegateType||f,It.test(l+f)||(a=a.parentNode);a;a=a.parentNode)d.push(a),h=a
h===(n.ownerDocument||pt)&&d.push(h.defaultView||h.parentWindow||t)}for(c=0;(a=d[c++])&&!e.isPropagationStopped();)e.type=c>1?l:u.bindType||f,r=(st._data(a,"events")||{})[e.type]&&st._data(a,"handle"),r&&r.apply(a,i),r=o&&a[o],r&&r.apply&&st.acceptData(a)&&(e.result=r.apply(a,i),e.result===!1&&e.preventDefault())
if(e.type=f,!s&&!e.isDefaultPrevented()&&(!u._default||u._default.apply(d.pop(),i)===!1)&&st.acceptData(n)&&o&&n[f]&&!st.isWindow(n)){h=n[o],h&&(n[o]=null),st.event.triggered=f
try{n[f]()}catch(t){}st.event.triggered=void 0,h&&(n[o]=h)}return e.result}},dispatch:function(t){t=st.event.fix(t)
var e,i,n,s,r,o=[],a=X.call(arguments),l=(st._data(this,"events")||{})[t.type]||[],u=st.event.special[t.type]||{}
if(a[0]=t,t.delegateTarget=this,!u.preDispatch||u.preDispatch.call(this,t)!==!1){for(o=st.event.handlers.call(this,t,l),e=0;(s=o[e++])&&!t.isPropagationStopped();)for(t.currentTarget=s.elem,r=0;(n=s.handlers[r++])&&!t.isImmediatePropagationStopped();)(!t.namespace_re||t.namespace_re.test(n.namespace))&&(t.handleObj=n,t.data=n.data,i=((st.event.special[n.origType]||{}).handle||n.handler).apply(s.elem,a),void 0!==i&&(t.result=i)===!1&&(t.preventDefault(),t.stopPropagation()))
return u.postDispatch&&u.postDispatch.call(this,t),t.result}},handlers:function(t,e){var i,n,s,r,o=[],a=e.delegateCount,l=t.target
if(a&&l.nodeType&&(!t.button||"click"!==t.type))for(;l!=this;l=l.parentNode||this)if(1===l.nodeType&&(l.disabled!==!0||"click"!==t.type)){for(s=[],r=0;a>r;r++)n=e[r],i=n.selector+" ",void 0===s[i]&&(s[i]=n.needsContext?st(i,this).index(l)>=0:st.find(i,this,null,[l]).length),s[i]&&s.push(n)
s.length&&o.push({elem:l,handlers:s})}return a<e.length&&o.push({elem:this,handlers:e.slice(a)}),o},fix:function(t){if(t[st.expando])return t
var e,i,n,s=t.type,r=t,o=this.fixHooks[s]
for(o||(this.fixHooks[s]=o=Pt.test(s)?this.mouseHooks:Ot.test(s)?this.keyHooks:{}),n=o.props?this.props.concat(o.props):this.props,t=new st.Event(r),e=n.length;e--;)i=n[e],t[i]=r[i]
return t.target||(t.target=r.srcElement||pt),3===t.target.nodeType&&(t.target=t.target.parentNode),t.metaKey=!!t.metaKey,o.filter?o.filter(t,r):t},props:"altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(t,e){return null==t.which&&(t.which=null!=e.charCode?e.charCode:e.keyCode),t}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(t,e){var i,n,s,r=e.button,o=e.fromElement
return null==t.pageX&&null!=e.clientX&&(n=t.target.ownerDocument||pt,s=n.documentElement,i=n.body,t.pageX=e.clientX+(s&&s.scrollLeft||i&&i.scrollLeft||0)-(s&&s.clientLeft||i&&i.clientLeft||0),t.pageY=e.clientY+(s&&s.scrollTop||i&&i.scrollTop||0)-(s&&s.clientTop||i&&i.clientTop||0)),!t.relatedTarget&&o&&(t.relatedTarget=o===t.target?e.toElement:o),t.which||void 0===r||(t.which=1&r?1:2&r?3:4&r?2:0),t}},special:{load:{noBubble:!0},focus:{trigger:function(){if(this!==p()&&this.focus)try{return this.focus(),!1}catch(t){}},delegateType:"focusin"},blur:{trigger:function(){return this===p()&&this.blur?(this.blur(),!1):void 0},delegateType:"focusout"},click:{trigger:function(){return st.nodeName(this,"input")&&"checkbox"===this.type&&this.click?(this.click(),!1):void 0},_default:function(t){return st.nodeName(t.target,"a")}},beforeunload:{postDispatch:function(t){void 0!==t.result&&t.originalEvent&&(t.originalEvent.returnValue=t.result)}}},simulate:function(t,e,i,n){var s=st.extend(new st.Event,i,{type:t,isSimulated:!0,originalEvent:{}})
n?st.event.trigger(s,null,e):st.event.dispatch.call(e,s),s.isDefaultPrevented()&&i.preventDefault()}},st.removeEvent=pt.removeEventListener?function(t,e,i){t.removeEventListener&&t.removeEventListener(e,i,!1)}:function(t,e,i){var n="on"+e
t.detachEvent&&(typeof t[n]===kt&&(t[n]=null),t.detachEvent(n,i))},st.Event=function(t,e){return this instanceof st.Event?(t&&t.type?(this.originalEvent=t,this.type=t.type,this.isDefaultPrevented=t.defaultPrevented||void 0===t.defaultPrevented&&t.returnValue===!1?d:f):this.type=t,e&&st.extend(this,e),this.timeStamp=t&&t.timeStamp||st.now(),void(this[st.expando]=!0)):new st.Event(t,e)},st.Event.prototype={isDefaultPrevented:f,isPropagationStopped:f,isImmediatePropagationStopped:f,preventDefault:function(){var t=this.originalEvent
this.isDefaultPrevented=d,t&&(t.preventDefault?t.preventDefault():t.returnValue=!1)},stopPropagation:function(){var t=this.originalEvent
this.isPropagationStopped=d,t&&(t.stopPropagation&&t.stopPropagation(),t.cancelBubble=!0)},stopImmediatePropagation:function(){var t=this.originalEvent
this.isImmediatePropagationStopped=d,t&&t.stopImmediatePropagation&&t.stopImmediatePropagation(),this.stopPropagation()}},st.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(t,e){st.event.special[t]={delegateType:e,bindType:e,handle:function(t){var i,n=this,s=t.relatedTarget,r=t.handleObj
return(!s||s!==n&&!st.contains(n,s))&&(t.type=r.origType,i=r.handler.apply(this,arguments),t.type=e),i}}}),it.submitBubbles||(st.event.special.submit={setup:function(){return!st.nodeName(this,"form")&&void st.event.add(this,"click._submit keypress._submit",function(t){var e=t.target,i=st.nodeName(e,"input")||st.nodeName(e,"button")?e.form:void 0
i&&!st._data(i,"submitBubbles")&&(st.event.add(i,"submit._submit",function(t){t._submit_bubble=!0}),st._data(i,"submitBubbles",!0))})},postDispatch:function(t){t._submit_bubble&&(delete t._submit_bubble,this.parentNode&&!t.isTrigger&&st.event.simulate("submit",this.parentNode,t,!0))},teardown:function(){return!st.nodeName(this,"form")&&void st.event.remove(this,"._submit")}}),it.changeBubbles||(st.event.special.change={setup:function(){return At.test(this.nodeName)?(("checkbox"===this.type||"radio"===this.type)&&(st.event.add(this,"propertychange._change",function(t){"checked"===t.originalEvent.propertyName&&(this._just_changed=!0)}),st.event.add(this,"click._change",function(t){this._just_changed&&!t.isTrigger&&(this._just_changed=!1),st.event.simulate("change",this,t,!0)})),!1):void st.event.add(this,"beforeactivate._change",function(t){var e=t.target
At.test(e.nodeName)&&!st._data(e,"changeBubbles")&&(st.event.add(e,"change._change",function(t){!this.parentNode||t.isSimulated||t.isTrigger||st.event.simulate("change",this.parentNode,t,!0)}),st._data(e,"changeBubbles",!0))})},handle:function(t){var e=t.target
return this!==e||t.isSimulated||t.isTrigger||"radio"!==e.type&&"checkbox"!==e.type?t.handleObj.handler.apply(this,arguments):void 0},teardown:function(){return st.event.remove(this,"._change"),!At.test(this.nodeName)}}),it.focusinBubbles||st.each({focus:"focusin",blur:"focusout"},function(t,e){var i=function(t){st.event.simulate(e,t.target,st.event.fix(t),!0)}
st.event.special[e]={setup:function(){var n=this.ownerDocument||this,s=st._data(n,e)
s||n.addEventListener(t,i,!0),st._data(n,e,(s||0)+1)},teardown:function(){var n=this.ownerDocument||this,s=st._data(n,e)-1
s?st._data(n,e,s):(n.removeEventListener(t,i,!0),st._removeData(n,e))}}}),st.fn.extend({on:function(t,e,i,n,s){var r,o
if("object"==typeof t){"string"!=typeof e&&(i=i||e,e=void 0)
for(r in t)this.on(r,e,i,t[r],s)
return this}if(null==i&&null==n?(n=e,i=e=void 0):null==n&&("string"==typeof e?(n=i,i=void 0):(n=i,i=e,e=void 0)),n===!1)n=f
else if(!n)return this
return 1===s&&(o=n,n=function(t){return st().off(t),o.apply(this,arguments)},n.guid=o.guid||(o.guid=st.guid++)),this.each(function(){st.event.add(this,t,n,i,e)})},one:function(t,e,i,n){return this.on(t,e,i,n,1)},off:function(t,e,i){var n,s
if(t&&t.preventDefault&&t.handleObj)return n=t.handleObj,st(t.delegateTarget).off(n.namespace?n.origType+"."+n.namespace:n.origType,n.selector,n.handler),this
if("object"==typeof t){for(s in t)this.off(s,e,t[s])
return this}return(e===!1||"function"==typeof e)&&(i=e,e=void 0),i===!1&&(i=f),this.each(function(){st.event.remove(this,t,i,e)})},trigger:function(t,e){return this.each(function(){st.event.trigger(t,e,this)})},triggerHandler:function(t,e){var i=this[0]
return i?st.event.trigger(t,e,i,!0):void 0}})
var Ht="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",jt=/ jQuery\d+="(?:null|\d+)"/g,Wt=new RegExp("<(?:"+Ht+")[\\s/>]","i"),Ft=/^\s+/,$t=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,Ut=/<([\w:]+)/,Rt=/<tbody/i,Yt=/<|&#?\w+;/,qt=/<(?:script|style|link)/i,Vt=/checked\s*(?:[^=]|=\s*.checked.)/i,Bt=/^$|\/(?:java|ecma)script/i,zt=/^true\/(.*)/,Gt=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,Xt={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:it.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]},Jt=m(pt),Qt=Jt.appendChild(pt.createElement("div"))
Xt.optgroup=Xt.option,Xt.tbody=Xt.tfoot=Xt.colgroup=Xt.caption=Xt.thead,Xt.th=Xt.td,st.extend({clone:function(t,e,i){var n,s,r,o,a,l=st.contains(t.ownerDocument,t)
if(it.html5Clone||st.isXMLDoc(t)||!Wt.test("<"+t.nodeName+">")?r=t.cloneNode(!0):(Qt.innerHTML=t.outerHTML,Qt.removeChild(r=Qt.firstChild)),!(it.noCloneEvent&&it.noCloneChecked||1!==t.nodeType&&11!==t.nodeType||st.isXMLDoc(t)))for(n=g(r),a=g(t),o=0;null!=(s=a[o]);++o)n[o]&&k(s,n[o])
if(e)if(i)for(a=a||g(t),n=n||g(r),o=0;null!=(s=a[o]);o++)x(s,n[o])
else x(t,r)
return n=g(r,"script"),n.length>0&&w(n,!l&&g(t,"script")),n=a=s=null,r},buildFragment:function(t,e,i,n){for(var s,r,o,a,l,u,h,c=t.length,d=m(e),f=[],p=0;c>p;p++)if(r=t[p],r||0===r)if("object"===st.type(r))st.merge(f,r.nodeType?[r]:r)
else if(Yt.test(r)){for(a=a||d.appendChild(e.createElement("div")),l=(Ut.exec(r)||["",""])[1].toLowerCase(),h=Xt[l]||Xt._default,a.innerHTML=h[1]+r.replace($t,"<$1></$2>")+h[2],s=h[0];s--;)a=a.lastChild
if(!it.leadingWhitespace&&Ft.test(r)&&f.push(e.createTextNode(Ft.exec(r)[0])),!it.tbody)for(r="table"!==l||Rt.test(r)?"<table>"!==h[1]||Rt.test(r)?0:a:a.firstChild,s=r&&r.childNodes.length;s--;)st.nodeName(u=r.childNodes[s],"tbody")&&!u.childNodes.length&&r.removeChild(u)
for(st.merge(f,a.childNodes),a.textContent="";a.firstChild;)a.removeChild(a.firstChild)
a=d.lastChild}else f.push(e.createTextNode(r))
for(a&&d.removeChild(a),it.appendChecked||st.grep(g(f,"input"),v),p=0;r=f[p++];)if((!n||-1===st.inArray(r,n))&&(o=st.contains(r.ownerDocument,r),a=g(d.appendChild(r),"script"),o&&w(a),i))for(s=0;r=a[s++];)Bt.test(r.type||"")&&i.push(r)
return a=null,d},cleanData:function(t,e){for(var i,n,s,r,o=0,a=st.expando,l=st.cache,u=it.deleteExpando,h=st.event.special;null!=(i=t[o]);o++)if((e||st.acceptData(i))&&(s=i[a],r=s&&l[s])){if(r.events)for(n in r.events)h[n]?st.event.remove(i,n):st.removeEvent(i,n,r.handle)
l[s]&&(delete l[s],u?delete i[a]:typeof i.removeAttribute!==kt?i.removeAttribute(a):i[a]=null,G.push(s))}}}),st.fn.extend({text:function(t){return Et(this,function(t){return void 0===t?st.text(this):this.empty().append((this[0]&&this[0].ownerDocument||pt).createTextNode(t))},null,t,arguments.length)},append:function(){return this.domManip(arguments,function(t){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var e=y(this,t)
e.appendChild(t)}})},prepend:function(){return this.domManip(arguments,function(t){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var e=y(this,t)
e.insertBefore(t,e.firstChild)}})},before:function(){return this.domManip(arguments,function(t){this.parentNode&&this.parentNode.insertBefore(t,this)})},after:function(){return this.domManip(arguments,function(t){this.parentNode&&this.parentNode.insertBefore(t,this.nextSibling)})},remove:function(t,e){for(var i,n=t?st.filter(t,this):this,s=0;null!=(i=n[s]);s++)e||1!==i.nodeType||st.cleanData(g(i)),i.parentNode&&(e&&st.contains(i.ownerDocument,i)&&w(g(i,"script")),i.parentNode.removeChild(i))
return this},empty:function(){for(var t,e=0;null!=(t=this[e]);e++){for(1===t.nodeType&&st.cleanData(g(t,!1));t.firstChild;)t.removeChild(t.firstChild)
t.options&&st.nodeName(t,"select")&&(t.options.length=0)}return this},clone:function(t,e){return t=null!=t&&t,e=null==e?t:e,this.map(function(){return st.clone(this,t,e)})},html:function(t){return Et(this,function(t){var e=this[0]||{},i=0,n=this.length
if(void 0===t)return 1===e.nodeType?e.innerHTML.replace(jt,""):void 0
if(!("string"!=typeof t||qt.test(t)||!it.htmlSerialize&&Wt.test(t)||!it.leadingWhitespace&&Ft.test(t)||Xt[(Ut.exec(t)||["",""])[1].toLowerCase()])){t=t.replace($t,"<$1></$2>")
try{for(;n>i;i++)e=this[i]||{},1===e.nodeType&&(st.cleanData(g(e,!1)),e.innerHTML=t)
e=0}catch(t){}}e&&this.empty().append(t)},null,t,arguments.length)},replaceWith:function(){var t=arguments[0]
return this.domManip(arguments,function(e){t=this.parentNode,st.cleanData(g(this)),t&&t.replaceChild(e,this)}),t&&(t.length||t.nodeType)?this:this.remove()},detach:function(t){return this.remove(t,!0)},domManip:function(t,e){t=J.apply([],t)
var i,n,s,r,o,a,l=0,u=this.length,h=this,c=u-1,d=t[0],f=st.isFunction(d)
if(f||u>1&&"string"==typeof d&&!it.checkClone&&Vt.test(d))return this.each(function(i){var n=h.eq(i)
f&&(t[0]=d.call(this,i,n.html())),n.domManip(t,e)})
if(u&&(a=st.buildFragment(t,this[0].ownerDocument,!1,this),i=a.firstChild,1===a.childNodes.length&&(a=i),i)){for(r=st.map(g(a,"script"),_),s=r.length;u>l;l++)n=a,l!==c&&(n=st.clone(n,!0,!0),s&&st.merge(r,g(n,"script"))),e.call(this[l],n,l)
if(s)for(o=r[r.length-1].ownerDocument,st.map(r,b),l=0;s>l;l++)n=r[l],Bt.test(n.type||"")&&!st._data(n,"globalEval")&&st.contains(o,n)&&(n.src?st._evalUrl&&st._evalUrl(n.src):st.globalEval((n.text||n.textContent||n.innerHTML||"").replace(Gt,"")))
a=i=null}return this}}),st.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(t,e){st.fn[t]=function(t){for(var i,n=0,s=[],r=st(t),o=r.length-1;o>=n;n++)i=n===o?this:this.clone(!0),st(r[n])[e](i),Q.apply(s,i.get())
return this.pushStack(s)}})
var Zt,Kt={}
!function(){var t
it.shrinkWrapBlocks=function(){if(null!=t)return t
t=!1
var e,i,n
return i=pt.getElementsByTagName("body")[0],i&&i.style?(e=pt.createElement("div"),n=pt.createElement("div"),n.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",i.appendChild(n).appendChild(e),typeof e.style.zoom!==kt&&(e.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1",e.appendChild(pt.createElement("div")).style.width="5px",t=3!==e.offsetWidth),i.removeChild(n),t):void 0}}()
var te,ee,ie=/^margin/,ne=new RegExp("^("+Ct+")(?!px)[a-z%]+$","i"),se=/^(top|right|bottom|left)$/
t.getComputedStyle?(te=function(e){return e.ownerDocument.defaultView.opener?e.ownerDocument.defaultView.getComputedStyle(e,null):t.getComputedStyle(e,null)},ee=function(t,e,i){var n,s,r,o,a=t.style
return i=i||te(t),o=i?i.getPropertyValue(e)||i[e]:void 0,i&&(""!==o||st.contains(t.ownerDocument,t)||(o=st.style(t,e)),ne.test(o)&&ie.test(e)&&(n=a.width,s=a.minWidth,r=a.maxWidth,a.minWidth=a.maxWidth=a.width=o,o=i.width,a.width=n,a.minWidth=s,a.maxWidth=r)),void 0===o?o:o+""}):pt.documentElement.currentStyle&&(te=function(t){return t.currentStyle},ee=function(t,e,i){var n,s,r,o,a=t.style
return i=i||te(t),o=i?i[e]:void 0,null==o&&a&&a[e]&&(o=a[e]),ne.test(o)&&!se.test(e)&&(n=a.left,s=t.runtimeStyle,r=s&&s.left,r&&(s.left=t.currentStyle.left),a.left="fontSize"===e?"1em":o,o=a.pixelLeft+"px",a.left=n,r&&(s.left=r)),void 0===o?o:o+""||"auto"}),!function(){function e(){var e,i,n,s
i=pt.getElementsByTagName("body")[0],i&&i.style&&(e=pt.createElement("div"),n=pt.createElement("div"),n.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",i.appendChild(n).appendChild(e),e.style.cssText="-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute",r=o=!1,l=!0,t.getComputedStyle&&(r="1%"!==(t.getComputedStyle(e,null)||{}).top,o="4px"===(t.getComputedStyle(e,null)||{width:"4px"}).width,s=e.appendChild(pt.createElement("div")),s.style.cssText=e.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0",s.style.marginRight=s.style.width="0",e.style.width="1px",l=!parseFloat((t.getComputedStyle(s,null)||{}).marginRight),e.removeChild(s)),e.innerHTML="<table><tr><td></td><td>t</td></tr></table>",s=e.getElementsByTagName("td"),s[0].style.cssText="margin:0;border:0;padding:0;display:none",a=0===s[0].offsetHeight,a&&(s[0].style.display="",s[1].style.display="none",a=0===s[0].offsetHeight),i.removeChild(n))}var i,n,s,r,o,a,l
i=pt.createElement("div"),i.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",s=i.getElementsByTagName("a")[0],(n=s&&s.style)&&(n.cssText="float:left;opacity:.5",it.opacity="0.5"===n.opacity,it.cssFloat=!!n.cssFloat,i.style.backgroundClip="content-box",i.cloneNode(!0).style.backgroundClip="",it.clearCloneStyle="content-box"===i.style.backgroundClip,it.boxSizing=""===n.boxSizing||""===n.MozBoxSizing||""===n.WebkitBoxSizing,st.extend(it,{reliableHiddenOffsets:function(){return null==a&&e(),a},boxSizingReliable:function(){return null==o&&e(),o},pixelPosition:function(){return null==r&&e(),r},reliableMarginRight:function(){return null==l&&e(),l}}))}(),st.swap=function(t,e,i,n){var s,r,o={}
for(r in e)o[r]=t.style[r],t.style[r]=e[r]
s=i.apply(t,n||[])
for(r in e)t.style[r]=o[r]
return s}
var re=/alpha\([^)]*\)/i,oe=/opacity\s*=\s*([^)]*)/,ae=/^(none|table(?!-c[ea]).+)/,le=new RegExp("^("+Ct+")(.*)$","i"),ue=new RegExp("^([+-])=("+Ct+")","i"),he={position:"absolute",visibility:"hidden",display:"block"},ce={letterSpacing:"0",fontWeight:"400"},de=["Webkit","O","Moz","ms"]
st.extend({cssHooks:{opacity:{get:function(t,e){if(e){var i=ee(t,"opacity")
return""===i?"1":i}}}},cssNumber:{columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{float:it.cssFloat?"cssFloat":"styleFloat"},style:function(t,e,i,n){if(t&&3!==t.nodeType&&8!==t.nodeType&&t.style){var s,r,o,a=st.camelCase(e),l=t.style
if(e=st.cssProps[a]||(st.cssProps[a]=S(l,a)),o=st.cssHooks[e]||st.cssHooks[a],void 0===i)return o&&"get"in o&&void 0!==(s=o.get(t,!1,n))?s:l[e]
if(r=typeof i,"string"===r&&(s=ue.exec(i))&&(i=(s[1]+1)*s[2]+parseFloat(st.css(t,e)),r="number"),null!=i&&i===i&&("number"!==r||st.cssNumber[a]||(i+="px"),it.clearCloneStyle||""!==i||0!==e.indexOf("background")||(l[e]="inherit"),!(o&&"set"in o&&void 0===(i=o.set(t,i,n)))))try{l[e]=i}catch(t){}}},css:function(t,e,i,n){var s,r,o,a=st.camelCase(e)
return e=st.cssProps[a]||(st.cssProps[a]=S(t.style,a)),o=st.cssHooks[e]||st.cssHooks[a],o&&"get"in o&&(r=o.get(t,!0,i)),void 0===r&&(r=ee(t,e,n)),"normal"===r&&e in ce&&(r=ce[e]),""===i||i?(s=parseFloat(r),i===!0||st.isNumeric(s)?s||0:r):r}}),st.each(["height","width"],function(t,e){st.cssHooks[e]={get:function(t,i,n){return i?ae.test(st.css(t,"display"))&&0===t.offsetWidth?st.swap(t,he,function(){return A(t,e,n)}):A(t,e,n):void 0},set:function(t,i,n){var s=n&&te(t)
return E(t,i,n?N(t,e,n,it.boxSizing&&"border-box"===st.css(t,"boxSizing",!1,s),s):0)}}}),it.opacity||(st.cssHooks.opacity={get:function(t,e){return oe.test((e&&t.currentStyle?t.currentStyle.filter:t.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":e?"1":""},set:function(t,e){var i=t.style,n=t.currentStyle,s=st.isNumeric(e)?"alpha(opacity="+100*e+")":"",r=n&&n.filter||i.filter||""
i.zoom=1,(e>=1||""===e)&&""===st.trim(r.replace(re,""))&&i.removeAttribute&&(i.removeAttribute("filter"),""===e||n&&!n.filter)||(i.filter=re.test(r)?r.replace(re,s):r+" "+s)}}),st.cssHooks.marginRight=C(it.reliableMarginRight,function(t,e){return e?st.swap(t,{display:"inline-block"},ee,[t,"marginRight"]):void 0}),st.each({margin:"",padding:"",border:"Width"},function(t,e){st.cssHooks[t+e]={expand:function(i){for(var n=0,s={},r="string"==typeof i?i.split(" "):[i];4>n;n++)s[t+St[n]+e]=r[n]||r[n-2]||r[0]
return s}},ie.test(t)||(st.cssHooks[t+e].set=E)}),st.fn.extend({css:function(t,e){return Et(this,function(t,e,i){var n,s,r={},o=0
if(st.isArray(e)){for(n=te(t),s=e.length;s>o;o++)r[e[o]]=st.css(t,e[o],!1,n)
return r}return void 0!==i?st.style(t,e,i):st.css(t,e)},t,e,arguments.length>1)},show:function(){return M(this,!0)},hide:function(){return M(this)},toggle:function(t){return"boolean"==typeof t?t?this.show():this.hide():this.each(function(){Mt(this)?st(this).show():st(this).hide()})}}),st.Tween=O,O.prototype={constructor:O,init:function(t,e,i,n,s,r){this.elem=t,this.prop=i,this.easing=s||"swing",this.options=e,this.start=this.now=this.cur(),this.end=n,this.unit=r||(st.cssNumber[i]?"":"px")},cur:function(){var t=O.propHooks[this.prop]
return t&&t.get?t.get(this):O.propHooks._default.get(this)},run:function(t){var e,i=O.propHooks[this.prop]
return this.options.duration?this.pos=e=st.easing[this.easing](t,this.options.duration*t,0,1,this.options.duration):this.pos=e=t,this.now=(this.end-this.start)*e+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),i&&i.set?i.set(this):O.propHooks._default.set(this),this}},O.prototype.init.prototype=O.prototype,O.propHooks={_default:{get:function(t){var e
return null==t.elem[t.prop]||t.elem.style&&null!=t.elem.style[t.prop]?(e=st.css(t.elem,t.prop,""),e&&"auto"!==e?e:0):t.elem[t.prop]},set:function(t){st.fx.step[t.prop]?st.fx.step[t.prop](t):t.elem.style&&(null!=t.elem.style[st.cssProps[t.prop]]||st.cssHooks[t.prop])?st.style(t.elem,t.prop,t.now+t.unit):t.elem[t.prop]=t.now}}},O.propHooks.scrollTop=O.propHooks.scrollLeft={set:function(t){t.elem.nodeType&&t.elem.parentNode&&(t.elem[t.prop]=t.now)}},st.easing={linear:function(t){return t},swing:function(t){return.5-Math.cos(t*Math.PI)/2}},st.fx=O.prototype.init,st.fx.step={}
var fe,pe,me=/^(?:toggle|show|hide)$/,ge=new RegExp("^(?:([+-])=|)("+Ct+")([a-z%]*)$","i"),ve=/queueHooks$/,ye=[H],_e={"*":[function(t,e){var i=this.createTween(t,e),n=i.cur(),s=ge.exec(e),r=s&&s[3]||(st.cssNumber[t]?"":"px"),o=(st.cssNumber[t]||"px"!==r&&+n)&&ge.exec(st.css(i.elem,t)),a=1,l=20
if(o&&o[3]!==r){r=r||o[3],s=s||[],o=+n||1
do a=a||".5",o/=a,st.style(i.elem,t,o+r)
while(a!==(a=i.cur()/n)&&1!==a&&--l)}return s&&(o=i.start=+o||+n||0,i.unit=r,i.end=s[1]?o+(s[1]+1)*s[2]:+s[2]),i}]}
st.Animation=st.extend(W,{tweener:function(t,e){st.isFunction(t)?(e=t,t=["*"]):t=t.split(" ")
for(var i,n=0,s=t.length;s>n;n++)i=t[n],_e[i]=_e[i]||[],_e[i].unshift(e)},prefilter:function(t,e){e?ye.unshift(t):ye.push(t)}}),st.speed=function(t,e,i){var n=t&&"object"==typeof t?st.extend({},t):{complete:i||!i&&e||st.isFunction(t)&&t,duration:t,easing:i&&e||e&&!st.isFunction(e)&&e}
return n.duration=st.fx.off?0:"number"==typeof n.duration?n.duration:n.duration in st.fx.speeds?st.fx.speeds[n.duration]:st.fx.speeds._default,(null==n.queue||n.queue===!0)&&(n.queue="fx"),n.old=n.complete,n.complete=function(){st.isFunction(n.old)&&n.old.call(this),n.queue&&st.dequeue(this,n.queue)},n},st.fn.extend({fadeTo:function(t,e,i,n){return this.filter(Mt).css("opacity",0).show().end().animate({opacity:e},t,i,n)},animate:function(t,e,i,n){var s=st.isEmptyObject(t),r=st.speed(e,i,n),o=function(){var e=W(this,st.extend({},t),r);(s||st._data(this,"finish"))&&e.stop(!0)}
return o.finish=o,s||r.queue===!1?this.each(o):this.queue(r.queue,o)},stop:function(t,e,i){var n=function(t){var e=t.stop
delete t.stop,e(i)}
return"string"!=typeof t&&(i=e,e=t,t=void 0),e&&t!==!1&&this.queue(t||"fx",[]),this.each(function(){var e=!0,s=null!=t&&t+"queueHooks",r=st.timers,o=st._data(this)
if(s)o[s]&&o[s].stop&&n(o[s])
else for(s in o)o[s]&&o[s].stop&&ve.test(s)&&n(o[s])
for(s=r.length;s--;)r[s].elem!==this||null!=t&&r[s].queue!==t||(r[s].anim.stop(i),e=!1,r.splice(s,1));(e||!i)&&st.dequeue(this,t)})},finish:function(t){return t!==!1&&(t=t||"fx"),this.each(function(){var e,i=st._data(this),n=i[t+"queue"],s=i[t+"queueHooks"],r=st.timers,o=n?n.length:0
for(i.finish=!0,st.queue(this,t,[]),s&&s.stop&&s.stop.call(this,!0),e=r.length;e--;)r[e].elem===this&&r[e].queue===t&&(r[e].anim.stop(!0),r.splice(e,1))
for(e=0;o>e;e++)n[e]&&n[e].finish&&n[e].finish.call(this)
delete i.finish})}}),st.each(["toggle","show","hide"],function(t,e){var i=st.fn[e]
st.fn[e]=function(t,n,s){return null==t||"boolean"==typeof t?i.apply(this,arguments):this.animate(I(e,!0),t,n,s)}}),st.each({slideDown:I("show"),slideUp:I("hide"),slideToggle:I("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(t,e){st.fn[t]=function(t,i,n){return this.animate(e,t,i,n)}}),st.timers=[],st.fx.tick=function(){var t,e=st.timers,i=0
for(fe=st.now();i<e.length;i++)t=e[i],t()||e[i]!==t||e.splice(i--,1)
e.length||st.fx.stop(),fe=void 0},st.fx.timer=function(t){st.timers.push(t),t()?st.fx.start():st.timers.pop()},st.fx.interval=13,st.fx.start=function(){pe||(pe=setInterval(st.fx.tick,st.fx.interval))},st.fx.stop=function(){clearInterval(pe),pe=null},st.fx.speeds={slow:600,fast:200,_default:400},st.fn.delay=function(t,e){return t=st.fx?st.fx.speeds[t]||t:t,e=e||"fx",this.queue(e,function(e,i){var n=setTimeout(e,t)
i.stop=function(){clearTimeout(n)}})},function(){var t,e,i,n,s
e=pt.createElement("div"),e.setAttribute("className","t"),e.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",n=e.getElementsByTagName("a")[0],i=pt.createElement("select"),s=i.appendChild(pt.createElement("option")),t=e.getElementsByTagName("input")[0],n.style.cssText="top:1px",it.getSetAttribute="t"!==e.className,it.style=/top/.test(n.getAttribute("style")),it.hrefNormalized="/a"===n.getAttribute("href"),it.checkOn=!!t.value,it.optSelected=s.selected,it.enctype=!!pt.createElement("form").enctype,i.disabled=!0,it.optDisabled=!s.disabled,t=pt.createElement("input"),t.setAttribute("value",""),it.input=""===t.getAttribute("value"),t.value="t",t.setAttribute("type","radio"),it.radioValue="t"===t.value}()
var be=/\r/g
st.fn.extend({val:function(t){var e,i,n,s=this[0]
return arguments.length?(n=st.isFunction(t),this.each(function(i){var s
1===this.nodeType&&(s=n?t.call(this,i,st(this).val()):t,null==s?s="":"number"==typeof s?s+="":st.isArray(s)&&(s=st.map(s,function(t){return null==t?"":t+""})),e=st.valHooks[this.type]||st.valHooks[this.nodeName.toLowerCase()],e&&"set"in e&&void 0!==e.set(this,s,"value")||(this.value=s))})):s?(e=st.valHooks[s.type]||st.valHooks[s.nodeName.toLowerCase()],e&&"get"in e&&void 0!==(i=e.get(s,"value"))?i:(i=s.value,"string"==typeof i?i.replace(be,""):null==i?"":i)):void 0}}),st.extend({valHooks:{option:{get:function(t){var e=st.find.attr(t,"value")
return null!=e?e:st.trim(st.text(t))}},select:{get:function(t){for(var e,i,n=t.options,s=t.selectedIndex,r="select-one"===t.type||0>s,o=r?null:[],a=r?s+1:n.length,l=0>s?a:r?s:0;a>l;l++)if(i=n[l],!(!i.selected&&l!==s||(it.optDisabled?i.disabled:null!==i.getAttribute("disabled"))||i.parentNode.disabled&&st.nodeName(i.parentNode,"optgroup"))){if(e=st(i).val(),r)return e
o.push(e)}return o},set:function(t,e){for(var i,n,s=t.options,r=st.makeArray(e),o=s.length;o--;)if(n=s[o],st.inArray(st.valHooks.option.get(n),r)>=0)try{n.selected=i=!0}catch(t){n.scrollHeight}else n.selected=!1
return i||(t.selectedIndex=-1),s}}}}),st.each(["radio","checkbox"],function(){st.valHooks[this]={set:function(t,e){return st.isArray(e)?t.checked=st.inArray(st(t).val(),e)>=0:void 0}},it.checkOn||(st.valHooks[this].get=function(t){return null===t.getAttribute("value")?"on":t.value})})
var we,xe,ke=st.expr.attrHandle,De=/^(?:checked|selected)$/i,Te=it.getSetAttribute,Ce=it.input
st.fn.extend({attr:function(t,e){return Et(this,st.attr,t,e,arguments.length>1)},removeAttr:function(t){return this.each(function(){st.removeAttr(this,t)})}}),st.extend({attr:function(t,e,i){var n,s,r=t.nodeType
if(t&&3!==r&&8!==r&&2!==r)return typeof t.getAttribute===kt?st.prop(t,e,i):(1===r&&st.isXMLDoc(t)||(e=e.toLowerCase(),n=st.attrHooks[e]||(st.expr.match.bool.test(e)?xe:we)),void 0===i?n&&"get"in n&&null!==(s=n.get(t,e))?s:(s=st.find.attr(t,e),null==s?void 0:s):null!==i?n&&"set"in n&&void 0!==(s=n.set(t,i,e))?s:(t.setAttribute(e,i+""),i):void st.removeAttr(t,e))},removeAttr:function(t,e){var i,n,s=0,r=e&&e.match(_t)
if(r&&1===t.nodeType)for(;i=r[s++];)n=st.propFix[i]||i,st.expr.match.bool.test(i)?Ce&&Te||!De.test(i)?t[n]=!1:t[st.camelCase("default-"+i)]=t[n]=!1:st.attr(t,i,""),t.removeAttribute(Te?i:n)},attrHooks:{type:{set:function(t,e){if(!it.radioValue&&"radio"===e&&st.nodeName(t,"input")){var i=t.value
return t.setAttribute("type",e),i&&(t.value=i),e}}}}}),xe={set:function(t,e,i){return e===!1?st.removeAttr(t,i):Ce&&Te||!De.test(i)?t.setAttribute(!Te&&st.propFix[i]||i,i):t[st.camelCase("default-"+i)]=t[i]=!0,i}},st.each(st.expr.match.bool.source.match(/\w+/g),function(t,e){var i=ke[e]||st.find.attr
ke[e]=Ce&&Te||!De.test(e)?function(t,e,n){var s,r
return n||(r=ke[e],ke[e]=s,s=null!=i(t,e,n)?e.toLowerCase():null,ke[e]=r),s}:function(t,e,i){return i?void 0:t[st.camelCase("default-"+e)]?e.toLowerCase():null}}),Ce&&Te||(st.attrHooks.value={set:function(t,e,i){return st.nodeName(t,"input")?void(t.defaultValue=e):we&&we.set(t,e,i)}}),Te||(we={set:function(t,e,i){var n=t.getAttributeNode(i)
return n||t.setAttributeNode(n=t.ownerDocument.createAttribute(i)),n.value=e+="","value"===i||e===t.getAttribute(i)?e:void 0}},ke.id=ke.name=ke.coords=function(t,e,i){var n
return i?void 0:(n=t.getAttributeNode(e))&&""!==n.value?n.value:null},st.valHooks.button={get:function(t,e){var i=t.getAttributeNode(e)
return i&&i.specified?i.value:void 0},set:we.set},st.attrHooks.contenteditable={set:function(t,e,i){we.set(t,""!==e&&e,i)}},st.each(["width","height"],function(t,e){st.attrHooks[e]={set:function(t,i){return""===i?(t.setAttribute(e,"auto"),i):void 0}}})),it.style||(st.attrHooks.style={get:function(t){return t.style.cssText||void 0},set:function(t,e){return t.style.cssText=e+""}})
var Se=/^(?:input|select|textarea|button|object)$/i,Me=/^(?:a|area)$/i
st.fn.extend({prop:function(t,e){return Et(this,st.prop,t,e,arguments.length>1)},removeProp:function(t){return t=st.propFix[t]||t,this.each(function(){try{this[t]=void 0,delete this[t]}catch(t){}})}}),st.extend({propFix:{for:"htmlFor",class:"className"},prop:function(t,e,i){var n,s,r,o=t.nodeType
if(t&&3!==o&&8!==o&&2!==o)return r=1!==o||!st.isXMLDoc(t),r&&(e=st.propFix[e]||e,s=st.propHooks[e]),void 0!==i?s&&"set"in s&&void 0!==(n=s.set(t,i,e))?n:t[e]=i:s&&"get"in s&&null!==(n=s.get(t,e))?n:t[e]},propHooks:{tabIndex:{get:function(t){var e=st.find.attr(t,"tabindex")
return e?parseInt(e,10):Se.test(t.nodeName)||Me.test(t.nodeName)&&t.href?0:-1}}}}),it.hrefNormalized||st.each(["href","src"],function(t,e){st.propHooks[e]={get:function(t){return t.getAttribute(e,4)}}}),it.optSelected||(st.propHooks.selected={get:function(t){var e=t.parentNode
return e&&(e.selectedIndex,e.parentNode&&e.parentNode.selectedIndex),null}}),st.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){st.propFix[this.toLowerCase()]=this}),it.enctype||(st.propFix.enctype="encoding")
var Ee=/[\t\r\n\f]/g
st.fn.extend({addClass:function(t){var e,i,n,s,r,o,a=0,l=this.length,u="string"==typeof t&&t
if(st.isFunction(t))return this.each(function(e){st(this).addClass(t.call(this,e,this.className))})
if(u)for(e=(t||"").match(_t)||[];l>a;a++)if(i=this[a],n=1===i.nodeType&&(i.className?(" "+i.className+" ").replace(Ee," "):" ")){for(r=0;s=e[r++];)n.indexOf(" "+s+" ")<0&&(n+=s+" ")
o=st.trim(n),i.className!==o&&(i.className=o)}return this},removeClass:function(t){var e,i,n,s,r,o,a=0,l=this.length,u=0===arguments.length||"string"==typeof t&&t
if(st.isFunction(t))return this.each(function(e){st(this).removeClass(t.call(this,e,this.className))})
if(u)for(e=(t||"").match(_t)||[];l>a;a++)if(i=this[a],n=1===i.nodeType&&(i.className?(" "+i.className+" ").replace(Ee," "):"")){for(r=0;s=e[r++];)for(;n.indexOf(" "+s+" ")>=0;)n=n.replace(" "+s+" "," ")
o=t?st.trim(n):"",i.className!==o&&(i.className=o)}return this},toggleClass:function(t,e){var i=typeof t
return"boolean"==typeof e&&"string"===i?e?this.addClass(t):this.removeClass(t):this.each(st.isFunction(t)?function(i){st(this).toggleClass(t.call(this,i,this.className,e),e)}:function(){if("string"===i)for(var e,n=0,s=st(this),r=t.match(_t)||[];e=r[n++];)s.hasClass(e)?s.removeClass(e):s.addClass(e)
else(i===kt||"boolean"===i)&&(this.className&&st._data(this,"__className__",this.className),this.className=this.className||t===!1?"":st._data(this,"__className__")||"")})},hasClass:function(t){for(var e=" "+t+" ",i=0,n=this.length;n>i;i++)if(1===this[i].nodeType&&(" "+this[i].className+" ").replace(Ee," ").indexOf(e)>=0)return!0
return!1}}),st.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(t,e){st.fn[e]=function(t,i){return arguments.length>0?this.on(e,null,t,i):this.trigger(e)}}),st.fn.extend({hover:function(t,e){return this.mouseenter(t).mouseleave(e||t)},bind:function(t,e,i){return this.on(t,null,e,i)},unbind:function(t,e){return this.off(t,null,e)},delegate:function(t,e,i,n){return this.on(e,t,i,n)},undelegate:function(t,e,i){return 1===arguments.length?this.off(t,"**"):this.off(e,t||"**",i)}})
var Ne=st.now(),Ae=/\?/,Oe=/(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g
st.parseJSON=function(e){if(t.JSON&&t.JSON.parse)return t.JSON.parse(e+"")
var i,n=null,s=st.trim(e+"")
return s&&!st.trim(s.replace(Oe,function(t,e,s,r){return i&&e&&(n=0),0===n?t:(i=s||e,n+=!r-!s,"")}))?Function("return "+s)():st.error("Invalid JSON: "+e)},st.parseXML=function(e){var i,n
if(!e||"string"!=typeof e)return null
try{t.DOMParser?(n=new DOMParser,i=n.parseFromString(e,"text/xml")):(i=new ActiveXObject("Microsoft.XMLDOM"),i.async="false",i.loadXML(e))}catch(t){i=void 0}return i&&i.documentElement&&!i.getElementsByTagName("parsererror").length||st.error("Invalid XML: "+e),i}
var Pe,Ie,Le=/#.*$/,He=/([?&])_=[^&]*/,je=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,We=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,Fe=/^(?:GET|HEAD)$/,$e=/^\/\//,Ue=/^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,Re={},Ye={},qe="*/".concat("*")
try{Ie=location.href}catch(t){Ie=pt.createElement("a"),Ie.href="",Ie=Ie.href}Pe=Ue.exec(Ie.toLowerCase())||[],st.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:Ie,type:"GET",isLocal:We.test(Pe[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":qe,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":st.parseJSON,"text xml":st.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(t,e){return e?U(U(t,st.ajaxSettings),e):U(st.ajaxSettings,t)},ajaxPrefilter:F(Re),ajaxTransport:F(Ye),ajax:function(t,e){function i(t,e,i,n){var s,h,v,y,b,x=e
2!==_&&(_=2,a&&clearTimeout(a),u=void 0,o=n||"",w.readyState=t>0?4:0,s=t>=200&&300>t||304===t,i&&(y=R(c,w,i)),y=Y(c,y,w,s),s?(c.ifModified&&(b=w.getResponseHeader("Last-Modified"),b&&(st.lastModified[r]=b),b=w.getResponseHeader("etag"),b&&(st.etag[r]=b)),204===t||"HEAD"===c.type?x="nocontent":304===t?x="notmodified":(x=y.state,h=y.data,v=y.error,s=!v)):(v=x,(t||!x)&&(x="error",0>t&&(t=0))),w.status=t,w.statusText=(e||x)+"",s?p.resolveWith(d,[h,x,w]):p.rejectWith(d,[w,x,v]),w.statusCode(g),g=void 0,l&&f.trigger(s?"ajaxSuccess":"ajaxError",[w,c,s?h:v]),m.fireWith(d,[w,x]),l&&(f.trigger("ajaxComplete",[w,c]),--st.active||st.event.trigger("ajaxStop")))}"object"==typeof t&&(e=t,t=void 0),e=e||{}
var n,s,r,o,a,l,u,h,c=st.ajaxSetup({},e),d=c.context||c,f=c.context&&(d.nodeType||d.jquery)?st(d):st.event,p=st.Deferred(),m=st.Callbacks("once memory"),g=c.statusCode||{},v={},y={},_=0,b="canceled",w={readyState:0,getResponseHeader:function(t){var e
if(2===_){if(!h)for(h={};e=je.exec(o);)h[e[1].toLowerCase()]=e[2]
e=h[t.toLowerCase()]}return null==e?null:e},getAllResponseHeaders:function(){return 2===_?o:null},setRequestHeader:function(t,e){var i=t.toLowerCase()
return _||(t=y[i]=y[i]||t,v[t]=e),this},overrideMimeType:function(t){return _||(c.mimeType=t),this},statusCode:function(t){var e
if(t)if(2>_)for(e in t)g[e]=[g[e],t[e]]
else w.always(t[w.status])
return this},abort:function(t){var e=t||b
return u&&u.abort(e),i(0,e),this}}
if(p.promise(w).complete=m.add,w.success=w.done,w.error=w.fail,c.url=((t||c.url||Ie)+"").replace(Le,"").replace($e,Pe[1]+"//"),c.type=e.method||e.type||c.method||c.type,c.dataTypes=st.trim(c.dataType||"*").toLowerCase().match(_t)||[""],null==c.crossDomain&&(n=Ue.exec(c.url.toLowerCase()),c.crossDomain=!(!n||n[1]===Pe[1]&&n[2]===Pe[2]&&(n[3]||("http:"===n[1]?"80":"443"))===(Pe[3]||("http:"===Pe[1]?"80":"443")))),c.data&&c.processData&&"string"!=typeof c.data&&(c.data=st.param(c.data,c.traditional)),$(Re,c,e,w),2===_)return w
l=st.event&&c.global,l&&0===st.active++&&st.event.trigger("ajaxStart"),c.type=c.type.toUpperCase(),c.hasContent=!Fe.test(c.type),r=c.url,c.hasContent||(c.data&&(r=c.url+=(Ae.test(r)?"&":"?")+c.data,delete c.data),c.cache===!1&&(c.url=He.test(r)?r.replace(He,"$1_="+Ne++):r+(Ae.test(r)?"&":"?")+"_="+Ne++)),c.ifModified&&(st.lastModified[r]&&w.setRequestHeader("If-Modified-Since",st.lastModified[r]),st.etag[r]&&w.setRequestHeader("If-None-Match",st.etag[r])),(c.data&&c.hasContent&&c.contentType!==!1||e.contentType)&&w.setRequestHeader("Content-Type",c.contentType),w.setRequestHeader("Accept",c.dataTypes[0]&&c.accepts[c.dataTypes[0]]?c.accepts[c.dataTypes[0]]+("*"!==c.dataTypes[0]?", "+qe+"; q=0.01":""):c.accepts["*"])
for(s in c.headers)w.setRequestHeader(s,c.headers[s])
if(c.beforeSend&&(c.beforeSend.call(d,w,c)===!1||2===_))return w.abort()
b="abort"
for(s in{success:1,error:1,complete:1})w[s](c[s])
if(u=$(Ye,c,e,w)){w.readyState=1,l&&f.trigger("ajaxSend",[w,c]),c.async&&c.timeout>0&&(a=setTimeout(function(){w.abort("timeout")},c.timeout))
try{_=1,u.send(v,i)}catch(t){if(!(2>_))throw t
i(-1,t)}}else i(-1,"No Transport")
return w},getJSON:function(t,e,i){return st.get(t,e,i,"json")},getScript:function(t,e){return st.get(t,void 0,e,"script")}}),st.each(["get","post"],function(t,e){st[e]=function(t,i,n,s){return st.isFunction(i)&&(s=s||n,n=i,i=void 0),st.ajax({url:t,type:e,dataType:s,data:i,success:n})}}),st._evalUrl=function(t){return st.ajax({url:t,type:"GET",dataType:"script",async:!1,global:!1,throws:!0})},st.fn.extend({wrapAll:function(t){if(st.isFunction(t))return this.each(function(e){st(this).wrapAll(t.call(this,e))})
if(this[0]){var e=st(t,this[0].ownerDocument).eq(0).clone(!0)
this[0].parentNode&&e.insertBefore(this[0]),e.map(function(){for(var t=this;t.firstChild&&1===t.firstChild.nodeType;)t=t.firstChild
return t}).append(this)}return this},wrapInner:function(t){return this.each(st.isFunction(t)?function(e){st(this).wrapInner(t.call(this,e))}:function(){var e=st(this),i=e.contents()
i.length?i.wrapAll(t):e.append(t)})},wrap:function(t){var e=st.isFunction(t)
return this.each(function(i){st(this).wrapAll(e?t.call(this,i):t)})},unwrap:function(){return this.parent().each(function(){st.nodeName(this,"body")||st(this).replaceWith(this.childNodes)}).end()}}),st.expr.filters.hidden=function(t){return t.offsetWidth<=0&&t.offsetHeight<=0||!it.reliableHiddenOffsets()&&"none"===(t.style&&t.style.display||st.css(t,"display"))},st.expr.filters.visible=function(t){return!st.expr.filters.hidden(t)}
var Ve=/%20/g,Be=/\[\]$/,ze=/\r?\n/g,Ge=/^(?:submit|button|image|reset|file)$/i,Xe=/^(?:input|select|textarea|keygen)/i
st.param=function(t,e){var i,n=[],s=function(t,e){e=st.isFunction(e)?e():null==e?"":e,n[n.length]=encodeURIComponent(t)+"="+encodeURIComponent(e)}
if(void 0===e&&(e=st.ajaxSettings&&st.ajaxSettings.traditional),st.isArray(t)||t.jquery&&!st.isPlainObject(t))st.each(t,function(){s(this.name,this.value)})
else for(i in t)q(i,t[i],e,s)
return n.join("&").replace(Ve,"+")},st.fn.extend({serialize:function(){return st.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var t=st.prop(this,"elements")
return t?st.makeArray(t):this}).filter(function(){var t=this.type
return this.name&&!st(this).is(":disabled")&&Xe.test(this.nodeName)&&!Ge.test(t)&&(this.checked||!Nt.test(t))}).map(function(t,e){var i=st(this).val()
return null==i?null:st.isArray(i)?st.map(i,function(t){return{name:e.name,value:t.replace(ze,"\r\n")}}):{name:e.name,value:i.replace(ze,"\r\n")}}).get()}}),st.ajaxSettings.xhr=void 0!==t.ActiveXObject?function(){return!this.isLocal&&/^(get|post|head|put|delete|options)$/i.test(this.type)&&V()||B()}:V
var Je=0,Qe={},Ze=st.ajaxSettings.xhr()
t.attachEvent&&t.attachEvent("onunload",function(){for(var t in Qe)Qe[t](void 0,!0)}),it.cors=!!Ze&&"withCredentials"in Ze,Ze=it.ajax=!!Ze,Ze&&st.ajaxTransport(function(t){if(!t.crossDomain||it.cors){var e
return{send:function(i,n){var s,r=t.xhr(),o=++Je
if(r.open(t.type,t.url,t.async,t.username,t.password),t.xhrFields)for(s in t.xhrFields)r[s]=t.xhrFields[s]
t.mimeType&&r.overrideMimeType&&r.overrideMimeType(t.mimeType),t.crossDomain||i["X-Requested-With"]||(i["X-Requested-With"]="XMLHttpRequest")
for(s in i)void 0!==i[s]&&r.setRequestHeader(s,i[s]+"")
r.send(t.hasContent&&t.data||null),e=function(i,s){var a,l,u
if(e&&(s||4===r.readyState))if(delete Qe[o],e=void 0,r.onreadystatechange=st.noop,s)4!==r.readyState&&r.abort()
else{u={},a=r.status,"string"==typeof r.responseText&&(u.text=r.responseText)
try{l=r.statusText}catch(t){l=""}a||!t.isLocal||t.crossDomain?1223===a&&(a=204):a=u.text?200:404}u&&n(a,l,u,r.getAllResponseHeaders())},t.async?4===r.readyState?setTimeout(e):r.onreadystatechange=Qe[o]=e:e()},abort:function(){e&&e(void 0,!0)}}}}),st.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/(?:java|ecma)script/},converters:{"text script":function(t){return st.globalEval(t),t}}}),st.ajaxPrefilter("script",function(t){void 0===t.cache&&(t.cache=!1),t.crossDomain&&(t.type="GET",t.global=!1)}),st.ajaxTransport("script",function(t){if(t.crossDomain){var e,i=pt.head||st("head")[0]||pt.documentElement
return{send:function(n,s){e=pt.createElement("script"),e.async=!0,t.scriptCharset&&(e.charset=t.scriptCharset),e.src=t.url,e.onload=e.onreadystatechange=function(t,i){(i||!e.readyState||/loaded|complete/.test(e.readyState))&&(e.onload=e.onreadystatechange=null,e.parentNode&&e.parentNode.removeChild(e),e=null,i||s(200,"success"))},i.insertBefore(e,i.firstChild)},abort:function(){e&&e.onload(void 0,!0)}}}})
var Ke=[],ti=/(=)\?(?=&|$)|\?\?/
st.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var t=Ke.pop()||st.expando+"_"+Ne++
return this[t]=!0,t}}),st.ajaxPrefilter("json jsonp",function(e,i,n){var s,r,o,a=e.jsonp!==!1&&(ti.test(e.url)?"url":"string"==typeof e.data&&!(e.contentType||"").indexOf("application/x-www-form-urlencoded")&&ti.test(e.data)&&"data")
return a||"jsonp"===e.dataTypes[0]?(s=e.jsonpCallback=st.isFunction(e.jsonpCallback)?e.jsonpCallback():e.jsonpCallback,a?e[a]=e[a].replace(ti,"$1"+s):e.jsonp!==!1&&(e.url+=(Ae.test(e.url)?"&":"?")+e.jsonp+"="+s),e.converters["script json"]=function(){return o||st.error(s+" was not called"),o[0]},e.dataTypes[0]="json",r=t[s],t[s]=function(){o=arguments},n.always(function(){t[s]=r,e[s]&&(e.jsonpCallback=i.jsonpCallback,Ke.push(s)),o&&st.isFunction(r)&&r(o[0]),o=r=void 0}),"script"):void 0}),st.parseHTML=function(t,e,i){if(!t||"string"!=typeof t)return null
"boolean"==typeof e&&(i=e,e=!1),e=e||pt
var n=ct.exec(t),s=!i&&[]
return n?[e.createElement(n[1])]:(n=st.buildFragment([t],e,s),s&&s.length&&st(s).remove(),st.merge([],n.childNodes))}
var ei=st.fn.load
st.fn.load=function(t,e,i){if("string"!=typeof t&&ei)return ei.apply(this,arguments)
var n,s,r,o=this,a=t.indexOf(" ")
return a>=0&&(n=st.trim(t.slice(a,t.length)),t=t.slice(0,a)),st.isFunction(e)?(i=e,e=void 0):e&&"object"==typeof e&&(r="POST"),o.length>0&&st.ajax({url:t,type:r,dataType:"html",data:e}).done(function(t){s=arguments,o.html(n?st("<div>").append(st.parseHTML(t)).find(n):t)}).complete(i&&function(t,e){o.each(i,s||[t.responseText,e,t])}),this},st.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(t,e){st.fn[e]=function(t){return this.on(e,t)}}),st.expr.filters.animated=function(t){return st.grep(st.timers,function(e){return t===e.elem}).length}
var ii=t.document.documentElement
st.offset={setOffset:function(t,e,i){var n,s,r,o,a,l,u,h=st.css(t,"position"),c=st(t),d={}
"static"===h&&(t.style.position="relative"),a=c.offset(),r=st.css(t,"top"),l=st.css(t,"left"),u=("absolute"===h||"fixed"===h)&&st.inArray("auto",[r,l])>-1,u?(n=c.position(),o=n.top,s=n.left):(o=parseFloat(r)||0,s=parseFloat(l)||0),st.isFunction(e)&&(e=e.call(t,i,a)),null!=e.top&&(d.top=e.top-a.top+o),null!=e.left&&(d.left=e.left-a.left+s),"using"in e?e.using.call(t,d):c.css(d)}},st.fn.extend({offset:function(t){if(arguments.length)return void 0===t?this:this.each(function(e){st.offset.setOffset(this,t,e)})
var e,i,n={top:0,left:0},s=this[0],r=s&&s.ownerDocument
return r?(e=r.documentElement,st.contains(e,s)?(typeof s.getBoundingClientRect!==kt&&(n=s.getBoundingClientRect()),i=z(r),{top:n.top+(i.pageYOffset||e.scrollTop)-(e.clientTop||0),left:n.left+(i.pageXOffset||e.scrollLeft)-(e.clientLeft||0)}):n):void 0},position:function(){if(this[0]){var t,e,i={top:0,left:0},n=this[0]
return"fixed"===st.css(n,"position")?e=n.getBoundingClientRect():(t=this.offsetParent(),e=this.offset(),st.nodeName(t[0],"html")||(i=t.offset()),i.top+=st.css(t[0],"borderTopWidth",!0),i.left+=st.css(t[0],"borderLeftWidth",!0)),{top:e.top-i.top-st.css(n,"marginTop",!0),left:e.left-i.left-st.css(n,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){for(var t=this.offsetParent||ii;t&&!st.nodeName(t,"html")&&"static"===st.css(t,"position");)t=t.offsetParent
return t||ii})}}),st.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(t,e){var i=/Y/.test(e)
st.fn[t]=function(n){return Et(this,function(t,n,s){var r=z(t)
return void 0===s?r?e in r?r[e]:r.document.documentElement[n]:t[n]:void(r?r.scrollTo(i?st(r).scrollLeft():s,i?s:st(r).scrollTop()):t[n]=s)},t,n,arguments.length,null)}}),st.each(["top","left"],function(t,e){st.cssHooks[e]=C(it.pixelPosition,function(t,i){return i?(i=ee(t,e),ne.test(i)?st(t).position()[e]+"px":i):void 0})}),st.each({Height:"height",Width:"width"},function(t,e){st.each({padding:"inner"+t,content:e,"":"outer"+t},function(i,n){st.fn[n]=function(n,s){var r=arguments.length&&(i||"boolean"!=typeof n),o=i||(n===!0||s===!0?"margin":"border")
return Et(this,function(e,i,n){var s
return st.isWindow(e)?e.document.documentElement["client"+t]:9===e.nodeType?(s=e.documentElement,Math.max(e.body["scroll"+t],s["scroll"+t],e.body["offset"+t],s["offset"+t],s["client"+t])):void 0===n?st.css(e,i,o):st.style(e,i,n,o)},e,r?n:void 0,r,null)}})}),st.fn.size=function(){return this.length},st.fn.andSelf=st.fn.addBack,"function"==typeof define&&define.amd&&define("jquery",[],function(){return st})
var ni=t.jQuery,si=t.$
return st.noConflict=function(e){return t.$===st&&(t.$=si),e&&t.jQuery===st&&(t.jQuery=ni),st},typeof e===kt&&(t.jQuery=t.$=st),st}),"undefined"==typeof jQuery)throw new Error("Bootstrap's JavaScript requires jQuery");+function(t){"use strict"
var e=t.fn.jquery.split(" ")[0].split(".")
if(e[0]<2&&e[1]<9||1==e[0]&&9==e[1]&&e[2]<1||e[0]>2)throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 3")}(jQuery),+function(t){"use strict"
function e(){var t=document.createElement("bootstrap"),e={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"}
for(var i in e)if(void 0!==t.style[i])return{end:e[i]}
return!1}t.fn.emulateTransitionEnd=function(e){var i=!1,n=this
t(this).one("bsTransitionEnd",function(){i=!0})
var s=function(){i||t(n).trigger(t.support.transition.end)}
return setTimeout(s,e),this},t(function(){t.support.transition=e(),t.support.transition&&(t.event.special.bsTransitionEnd={bindType:t.support.transition.end,delegateType:t.support.transition.end,handle:function(e){return t(e.target).is(this)?e.handleObj.handler.apply(this,arguments):void 0}})})}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var i=t(this),s=i.data("bs.alert")
s||i.data("bs.alert",s=new n(this)),"string"==typeof e&&s[e].call(i)})}var i='[data-dismiss="alert"]',n=function(e){t(e).on("click",i,this.close)}
n.VERSION="3.3.6",n.TRANSITION_DURATION=150,n.prototype.close=function(e){function i(){o.detach().trigger("closed.bs.alert").remove()}var s=t(this),r=s.attr("data-target")
r||(r=s.attr("href"),r=r&&r.replace(/.*(?=#[^\s]*$)/,""))
var o=t(r)
e&&e.preventDefault(),o.length||(o=s.closest(".alert")),o.trigger(e=t.Event("close.bs.alert")),e.isDefaultPrevented()||(o.removeClass("in"),t.support.transition&&o.hasClass("fade")?o.one("bsTransitionEnd",i).emulateTransitionEnd(n.TRANSITION_DURATION):i())}
var s=t.fn.alert
t.fn.alert=e,t.fn.alert.Constructor=n,t.fn.alert.noConflict=function(){return t.fn.alert=s,this},t(document).on("click.bs.alert.data-api",i,n.prototype.close)}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var n=t(this),s=n.data("bs.button"),r="object"==typeof e&&e
s||n.data("bs.button",s=new i(this,r)),"toggle"==e?s.toggle():e&&s.setState(e)})}var i=function(e,n){this.$element=t(e),this.options=t.extend({},i.DEFAULTS,n),this.isLoading=!1}
i.VERSION="3.3.6",i.DEFAULTS={loadingText:"loading..."},i.prototype.setState=function(e){var i="disabled",n=this.$element,s=n.is("input")?"val":"html",r=n.data()
e+="Text",null==r.resetText&&n.data("resetText",n[s]()),setTimeout(t.proxy(function(){n[s](null==r[e]?this.options[e]:r[e]),"loadingText"==e?(this.isLoading=!0,n.addClass(i).attr(i,i)):this.isLoading&&(this.isLoading=!1,n.removeClass(i).removeAttr(i))},this),0)},i.prototype.toggle=function(){var t=!0,e=this.$element.closest('[data-toggle="buttons"]')
if(e.length){var i=this.$element.find("input")
"radio"==i.prop("type")?(i.prop("checked")&&(t=!1),e.find(".active").removeClass("active"),this.$element.addClass("active")):"checkbox"==i.prop("type")&&(i.prop("checked")!==this.$element.hasClass("active")&&(t=!1),this.$element.toggleClass("active")),i.prop("checked",this.$element.hasClass("active")),t&&i.trigger("change")}else this.$element.attr("aria-pressed",!this.$element.hasClass("active")),this.$element.toggleClass("active")}
var n=t.fn.button
t.fn.button=e,t.fn.button.Constructor=i,t.fn.button.noConflict=function(){return t.fn.button=n,this},t(document).on("click.bs.button.data-api",'[data-toggle^="button"]',function(i){var n=t(i.target)
n.hasClass("btn")||(n=n.closest(".btn")),e.call(n,"toggle"),t(i.target).is('input[type="radio"]')||t(i.target).is('input[type="checkbox"]')||i.preventDefault()}).on("focus.bs.button.data-api blur.bs.button.data-api",'[data-toggle^="button"]',function(e){t(e.target).closest(".btn").toggleClass("focus",/^focus(in)?$/.test(e.type))})}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var n=t(this),s=n.data("bs.carousel"),r=t.extend({},i.DEFAULTS,n.data(),"object"==typeof e&&e),o="string"==typeof e?e:r.slide
s||n.data("bs.carousel",s=new i(this,r)),"number"==typeof e?s.to(e):o?s[o]():r.interval&&s.pause().cycle()})}var i=function(e,i){this.$element=t(e),this.$indicators=this.$element.find(".carousel-indicators"),this.options=i,this.paused=null,this.sliding=null,this.interval=null,this.$active=null,this.$items=null,this.options.keyboard&&this.$element.on("keydown.bs.carousel",t.proxy(this.keydown,this)),"hover"==this.options.pause&&!("ontouchstart"in document.documentElement)&&this.$element.on("mouseenter.bs.carousel",t.proxy(this.pause,this)).on("mouseleave.bs.carousel",t.proxy(this.cycle,this))}
i.VERSION="3.3.6",i.TRANSITION_DURATION=600,i.DEFAULTS={interval:5e3,pause:"hover",wrap:!0,keyboard:!0},i.prototype.keydown=function(t){if(!/input|textarea/i.test(t.target.tagName)){switch(t.which){case 37:this.prev()
break
case 39:this.next()
break
default:return}t.preventDefault()}},i.prototype.cycle=function(e){return e||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(t.proxy(this.next,this),this.options.interval)),this},i.prototype.getItemIndex=function(t){return this.$items=t.parent().children(".item"),this.$items.index(t||this.$active)},i.prototype.getItemForDirection=function(t,e){var i=this.getItemIndex(e),n="prev"==t&&0===i||"next"==t&&i==this.$items.length-1
if(n&&!this.options.wrap)return e
var s="prev"==t?-1:1,r=(i+s)%this.$items.length
return this.$items.eq(r)},i.prototype.to=function(t){var e=this,i=this.getItemIndex(this.$active=this.$element.find(".item.active"))
return t>this.$items.length-1||0>t?void 0:this.sliding?this.$element.one("slid.bs.carousel",function(){e.to(t)}):i==t?this.pause().cycle():this.slide(t>i?"next":"prev",this.$items.eq(t))},i.prototype.pause=function(e){return e||(this.paused=!0),this.$element.find(".next, .prev").length&&t.support.transition&&(this.$element.trigger(t.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this},i.prototype.next=function(){return this.sliding?void 0:this.slide("next")},i.prototype.prev=function(){return this.sliding?void 0:this.slide("prev")},i.prototype.slide=function(e,n){var s=this.$element.find(".item.active"),r=n||this.getItemForDirection(e,s),o=this.interval,a="next"==e?"left":"right",l=this
if(r.hasClass("active"))return this.sliding=!1
var u=r[0],h=t.Event("slide.bs.carousel",{relatedTarget:u,direction:a})
if(this.$element.trigger(h),!h.isDefaultPrevented()){if(this.sliding=!0,o&&this.pause(),this.$indicators.length){this.$indicators.find(".active").removeClass("active")
var c=t(this.$indicators.children()[this.getItemIndex(r)])
c&&c.addClass("active")}var d=t.Event("slid.bs.carousel",{relatedTarget:u,direction:a})
return t.support.transition&&this.$element.hasClass("slide")?(r.addClass(e),r[0].offsetWidth,s.addClass(a),r.addClass(a),s.one("bsTransitionEnd",function(){r.removeClass([e,a].join(" ")).addClass("active"),s.removeClass(["active",a].join(" ")),l.sliding=!1,setTimeout(function(){l.$element.trigger(d)},0)}).emulateTransitionEnd(i.TRANSITION_DURATION)):(s.removeClass("active"),r.addClass("active"),this.sliding=!1,this.$element.trigger(d)),o&&this.cycle(),this}}
var n=t.fn.carousel
t.fn.carousel=e,t.fn.carousel.Constructor=i,t.fn.carousel.noConflict=function(){return t.fn.carousel=n,this}
var s=function(i){var n,s=t(this),r=t(s.attr("data-target")||(n=s.attr("href"))&&n.replace(/.*(?=#[^\s]+$)/,""))
if(r.hasClass("carousel")){var o=t.extend({},r.data(),s.data()),a=s.attr("data-slide-to")
a&&(o.interval=!1),e.call(r,o),a&&r.data("bs.carousel").to(a),i.preventDefault()}}
t(document).on("click.bs.carousel.data-api","[data-slide]",s).on("click.bs.carousel.data-api","[data-slide-to]",s),t(window).on("load",function(){t('[data-ride="carousel"]').each(function(){var i=t(this)
e.call(i,i.data())})})}(jQuery),+function(t){"use strict"
function e(e){var i,n=e.attr("data-target")||(i=e.attr("href"))&&i.replace(/.*(?=#[^\s]+$)/,"")
return t(n)}function i(e){return this.each(function(){var i=t(this),s=i.data("bs.collapse"),r=t.extend({},n.DEFAULTS,i.data(),"object"==typeof e&&e)
!s&&r.toggle&&/show|hide/.test(e)&&(r.toggle=!1),s||i.data("bs.collapse",s=new n(this,r)),"string"==typeof e&&s[e]()})}var n=function(e,i){this.$element=t(e),this.options=t.extend({},n.DEFAULTS,i),this.$trigger=t('[data-toggle="collapse"][href="#'+e.id+'"],[data-toggle="collapse"][data-target="#'+e.id+'"]'),this.transitioning=null,this.options.parent?this.$parent=this.getParent():this.addAriaAndCollapsedClass(this.$element,this.$trigger),this.options.toggle&&this.toggle()}
n.VERSION="3.3.6",n.TRANSITION_DURATION=350,n.DEFAULTS={toggle:!0},n.prototype.dimension=function(){var t=this.$element.hasClass("width")
return t?"width":"height"},n.prototype.show=function(){if(!this.transitioning&&!this.$element.hasClass("in")){var e,s=this.$parent&&this.$parent.children(".panel").children(".in, .collapsing")
if(!(s&&s.length&&(e=s.data("bs.collapse"),e&&e.transitioning))){var r=t.Event("show.bs.collapse")
if(this.$element.trigger(r),!r.isDefaultPrevented()){s&&s.length&&(i.call(s,"hide"),e||s.data("bs.collapse",null))
var o=this.dimension()
this.$element.removeClass("collapse").addClass("collapsing")[o](0).attr("aria-expanded",!0),this.$trigger.removeClass("collapsed").attr("aria-expanded",!0),this.transitioning=1
var a=function(){this.$element.removeClass("collapsing").addClass("collapse in")[o](""),this.transitioning=0,this.$element.trigger("shown.bs.collapse")}
if(!t.support.transition)return a.call(this)
var l=t.camelCase(["scroll",o].join("-"))
this.$element.one("bsTransitionEnd",t.proxy(a,this)).emulateTransitionEnd(n.TRANSITION_DURATION)[o](this.$element[0][l])}}}},n.prototype.hide=function(){if(!this.transitioning&&this.$element.hasClass("in")){var e=t.Event("hide.bs.collapse")
if(this.$element.trigger(e),!e.isDefaultPrevented()){var i=this.dimension()
this.$element[i](this.$element[i]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded",!1),this.$trigger.addClass("collapsed").attr("aria-expanded",!1),this.transitioning=1
var s=function(){this.transitioning=0,this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")}
return t.support.transition?void this.$element[i](0).one("bsTransitionEnd",t.proxy(s,this)).emulateTransitionEnd(n.TRANSITION_DURATION):s.call(this)}}},n.prototype.toggle=function(){this[this.$element.hasClass("in")?"hide":"show"]()},n.prototype.getParent=function(){return t(this.options.parent).find('[data-toggle="collapse"][data-parent="'+this.options.parent+'"]').each(t.proxy(function(i,n){var s=t(n)
this.addAriaAndCollapsedClass(e(s),s)},this)).end()},n.prototype.addAriaAndCollapsedClass=function(t,e){var i=t.hasClass("in")
t.attr("aria-expanded",i),e.toggleClass("collapsed",!i).attr("aria-expanded",i)}
var s=t.fn.collapse
t.fn.collapse=i,t.fn.collapse.Constructor=n,t.fn.collapse.noConflict=function(){return t.fn.collapse=s,this},t(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',function(n){var s=t(this)
s.attr("data-target")||n.preventDefault()
var r=e(s),o=r.data("bs.collapse"),a=o?"toggle":s.data()
i.call(r,a)})}(jQuery),+function(t){"use strict"
function e(e){var i=e.attr("data-target")
i||(i=e.attr("href"),i=i&&/#[A-Za-z]/.test(i)&&i.replace(/.*(?=#[^\s]*$)/,""))
var n=i&&t(i)
return n&&n.length?n:e.parent()}function i(i){i&&3===i.which||(t(s).remove(),t(r).each(function(){var n=t(this),s=e(n),r={relatedTarget:this}
s.hasClass("open")&&(i&&"click"==i.type&&/input|textarea/i.test(i.target.tagName)&&t.contains(s[0],i.target)||(s.trigger(i=t.Event("hide.bs.dropdown",r)),i.isDefaultPrevented()||(n.attr("aria-expanded","false"),s.removeClass("open").trigger(t.Event("hidden.bs.dropdown",r)))))}))}function n(e){return this.each(function(){var i=t(this),n=i.data("bs.dropdown")
n||i.data("bs.dropdown",n=new o(this)),"string"==typeof e&&n[e].call(i)})}var s=".dropdown-backdrop",r='[data-toggle="dropdown"]',o=function(e){t(e).on("click.bs.dropdown",this.toggle)}
o.VERSION="3.3.6",o.prototype.toggle=function(n){var s=t(this)
if(!s.is(".disabled, :disabled")){var r=e(s),o=r.hasClass("open")
if(i(),!o){"ontouchstart"in document.documentElement&&!r.closest(".navbar-nav").length&&t(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(t(this)).on("click",i)
var a={relatedTarget:this}
if(r.trigger(n=t.Event("show.bs.dropdown",a)),n.isDefaultPrevented())return
s.trigger("focus").attr("aria-expanded","true"),r.toggleClass("open").trigger(t.Event("shown.bs.dropdown",a))}return!1}},o.prototype.keydown=function(i){if(/(38|40|27|32)/.test(i.which)&&!/input|textarea/i.test(i.target.tagName)){var n=t(this)
if(i.preventDefault(),i.stopPropagation(),!n.is(".disabled, :disabled")){var s=e(n),o=s.hasClass("open")
if(!o&&27!=i.which||o&&27==i.which)return 27==i.which&&s.find(r).trigger("focus"),n.trigger("click")
var a=" li:not(.disabled):visible a",l=s.find(".dropdown-menu"+a)
if(l.length){var u=l.index(i.target)
38==i.which&&u>0&&u--,40==i.which&&u<l.length-1&&u++,~u||(u=0),l.eq(u).trigger("focus")}}}}
var a=t.fn.dropdown
t.fn.dropdown=n,t.fn.dropdown.Constructor=o,t.fn.dropdown.noConflict=function(){return t.fn.dropdown=a,this},t(document).on("click.bs.dropdown.data-api",i).on("click.bs.dropdown.data-api",".dropdown form",function(t){t.stopPropagation()}).on("click.bs.dropdown.data-api",r,o.prototype.toggle).on("keydown.bs.dropdown.data-api",r,o.prototype.keydown).on("keydown.bs.dropdown.data-api",".dropdown-menu",o.prototype.keydown)}(jQuery),+function(t){"use strict"
function e(e,n){return this.each(function(){var s=t(this),r=s.data("bs.modal"),o=t.extend({},i.DEFAULTS,s.data(),"object"==typeof e&&e)
r||s.data("bs.modal",r=new i(this,o)),"string"==typeof e?r[e](n):o.show&&r.show(n)})}var i=function(e,i){this.options=i,this.$body=t(document.body),this.$element=t(e),this.$dialog=this.$element.find(".modal-dialog"),this.$backdrop=null,this.isShown=null,this.originalBodyPad=null,this.scrollbarWidth=0,this.ignoreBackdropClick=!1,this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,t.proxy(function(){this.$element.trigger("loaded.bs.modal")},this))}
i.VERSION="3.3.6",i.TRANSITION_DURATION=300,i.BACKDROP_TRANSITION_DURATION=150,i.DEFAULTS={backdrop:!0,keyboard:!0,show:!0},i.prototype.toggle=function(t){return this.isShown?this.hide():this.show(t)},i.prototype.show=function(e){var n=this,s=t.Event("show.bs.modal",{relatedTarget:e})
this.$element.trigger(s),this.isShown||s.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.setScrollbar(),this.$body.addClass("modal-open"),this.escape(),this.resize(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',t.proxy(this.hide,this)),this.$dialog.on("mousedown.dismiss.bs.modal",function(){n.$element.one("mouseup.dismiss.bs.modal",function(e){t(e.target).is(n.$element)&&(n.ignoreBackdropClick=!0)})}),this.backdrop(function(){var s=t.support.transition&&n.$element.hasClass("fade")
n.$element.parent().length||n.$element.appendTo(n.$body),n.$element.show().scrollTop(0),n.adjustDialog(),s&&n.$element[0].offsetWidth,n.$element.addClass("in"),n.enforceFocus()
var r=t.Event("shown.bs.modal",{relatedTarget:e})
s?n.$dialog.one("bsTransitionEnd",function(){n.$element.trigger("focus").trigger(r)}).emulateTransitionEnd(i.TRANSITION_DURATION):n.$element.trigger("focus").trigger(r)}))},i.prototype.hide=function(e){e&&e.preventDefault(),e=t.Event("hide.bs.modal"),this.$element.trigger(e),this.isShown&&!e.isDefaultPrevented()&&(this.isShown=!1,this.escape(),this.resize(),t(document).off("focusin.bs.modal"),this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"),this.$dialog.off("mousedown.dismiss.bs.modal"),t.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",t.proxy(this.hideModal,this)).emulateTransitionEnd(i.TRANSITION_DURATION):this.hideModal())},i.prototype.enforceFocus=function(){t(document).off("focusin.bs.modal").on("focusin.bs.modal",t.proxy(function(t){this.$element[0]===t.target||this.$element.has(t.target).length||this.$element.trigger("focus")},this))},i.prototype.escape=function(){this.isShown&&this.options.keyboard?this.$element.on("keydown.dismiss.bs.modal",t.proxy(function(t){27==t.which&&this.hide()},this)):this.isShown||this.$element.off("keydown.dismiss.bs.modal")},i.prototype.resize=function(){this.isShown?t(window).on("resize.bs.modal",t.proxy(this.handleUpdate,this)):t(window).off("resize.bs.modal")},i.prototype.hideModal=function(){var t=this
this.$element.hide(),this.backdrop(function(){t.$body.removeClass("modal-open"),t.resetAdjustments(),t.resetScrollbar(),t.$element.trigger("hidden.bs.modal")})},i.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove(),this.$backdrop=null},i.prototype.backdrop=function(e){var n=this,s=this.$element.hasClass("fade")?"fade":""
if(this.isShown&&this.options.backdrop){var r=t.support.transition&&s
if(this.$backdrop=t(document.createElement("div")).addClass("modal-backdrop "+s).appendTo(this.$body),this.$element.on("click.dismiss.bs.modal",t.proxy(function(t){return this.ignoreBackdropClick?void(this.ignoreBackdropClick=!1):void(t.target===t.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus():this.hide()))},this)),r&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!e)return
r?this.$backdrop.one("bsTransitionEnd",e).emulateTransitionEnd(i.BACKDROP_TRANSITION_DURATION):e()}else if(!this.isShown&&this.$backdrop){this.$backdrop.removeClass("in")
var o=function(){n.removeBackdrop(),e&&e()}
t.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",o).emulateTransitionEnd(i.BACKDROP_TRANSITION_DURATION):o()}else e&&e()},i.prototype.handleUpdate=function(){this.adjustDialog()},i.prototype.adjustDialog=function(){var t=this.$element[0].scrollHeight>document.documentElement.clientHeight
this.$element.css({paddingLeft:!this.bodyIsOverflowing&&t?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!t?this.scrollbarWidth:""})},i.prototype.resetAdjustments=function(){this.$element.css({paddingLeft:"",paddingRight:""})},i.prototype.checkScrollbar=function(){var t=window.innerWidth
if(!t){var e=document.documentElement.getBoundingClientRect()
t=e.right-Math.abs(e.left)}this.bodyIsOverflowing=document.body.clientWidth<t,this.scrollbarWidth=this.measureScrollbar()},i.prototype.setScrollbar=function(){var t=parseInt(this.$body.css("padding-right")||0,10)
this.originalBodyPad=document.body.style.paddingRight||"",this.bodyIsOverflowing&&this.$body.css("padding-right",t+this.scrollbarWidth)},i.prototype.resetScrollbar=function(){this.$body.css("padding-right",this.originalBodyPad)},i.prototype.measureScrollbar=function(){var t=document.createElement("div")
t.className="modal-scrollbar-measure",this.$body.append(t)
var e=t.offsetWidth-t.clientWidth
return this.$body[0].removeChild(t),e}
var n=t.fn.modal
t.fn.modal=e,t.fn.modal.Constructor=i,t.fn.modal.noConflict=function(){return t.fn.modal=n,this},t(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(i){var n=t(this),s=n.attr("href"),r=t(n.attr("data-target")||s&&s.replace(/.*(?=#[^\s]+$)/,"")),o=r.data("bs.modal")?"toggle":t.extend({remote:!/#/.test(s)&&s},r.data(),n.data())
n.is("a")&&i.preventDefault(),r.one("show.bs.modal",function(t){t.isDefaultPrevented()||r.one("hidden.bs.modal",function(){n.is(":visible")&&n.trigger("focus")})}),e.call(r,o,this)})}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var n=t(this),s=n.data("bs.tooltip"),r="object"==typeof e&&e;(s||!/destroy|hide/.test(e))&&(s||n.data("bs.tooltip",s=new i(this,r)),"string"==typeof e&&s[e]())})}var i=function(t,e){this.type=null,this.options=null,this.enabled=null,this.timeout=null,this.hoverState=null,this.$element=null,this.inState=null,this.init("tooltip",t,e)}
i.VERSION="3.3.6",i.TRANSITION_DURATION=150,i.DEFAULTS={animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{selector:"body",padding:0}},i.prototype.init=function(e,i,n){if(this.enabled=!0,this.type=e,this.$element=t(i),this.options=this.getOptions(n),this.$viewport=this.options.viewport&&t(t.isFunction(this.options.viewport)?this.options.viewport.call(this,this.$element):this.options.viewport.selector||this.options.viewport),this.inState={click:!1,hover:!1,focus:!1},this.$element[0]instanceof document.constructor&&!this.options.selector)throw new Error("`selector` option must be specified when initializing "+this.type+" on the window.document object!")
for(var s=this.options.trigger.split(" "),r=s.length;r--;){var o=s[r]
if("click"==o)this.$element.on("click."+this.type,this.options.selector,t.proxy(this.toggle,this))
else if("manual"!=o){var a="hover"==o?"mouseenter":"focusin",l="hover"==o?"mouseleave":"focusout"
this.$element.on(a+"."+this.type,this.options.selector,t.proxy(this.enter,this)),this.$element.on(l+"."+this.type,this.options.selector,t.proxy(this.leave,this))}}this.options.selector?this._options=t.extend({},this.options,{trigger:"manual",selector:""}):this.fixTitle()},i.prototype.getDefaults=function(){return i.DEFAULTS},i.prototype.getOptions=function(e){return e=t.extend({},this.getDefaults(),this.$element.data(),e),e.delay&&"number"==typeof e.delay&&(e.delay={show:e.delay,hide:e.delay}),e},i.prototype.getDelegateOptions=function(){var e={},i=this.getDefaults()
return this._options&&t.each(this._options,function(t,n){i[t]!=n&&(e[t]=n)}),e},i.prototype.enter=function(e){var i=e instanceof this.constructor?e:t(e.currentTarget).data("bs."+this.type)
return i||(i=new this.constructor(e.currentTarget,this.getDelegateOptions()),t(e.currentTarget).data("bs."+this.type,i)),e instanceof t.Event&&(i.inState["focusin"==e.type?"focus":"hover"]=!0),i.tip().hasClass("in")||"in"==i.hoverState?void(i.hoverState="in"):(clearTimeout(i.timeout),i.hoverState="in",i.options.delay&&i.options.delay.show?void(i.timeout=setTimeout(function(){"in"==i.hoverState&&i.show()},i.options.delay.show)):i.show())},i.prototype.isInStateTrue=function(){for(var t in this.inState)if(this.inState[t])return!0
return!1},i.prototype.leave=function(e){var i=e instanceof this.constructor?e:t(e.currentTarget).data("bs."+this.type)
return i||(i=new this.constructor(e.currentTarget,this.getDelegateOptions()),t(e.currentTarget).data("bs."+this.type,i)),e instanceof t.Event&&(i.inState["focusout"==e.type?"focus":"hover"]=!1),i.isInStateTrue()?void 0:(clearTimeout(i.timeout),i.hoverState="out",i.options.delay&&i.options.delay.hide?void(i.timeout=setTimeout(function(){"out"==i.hoverState&&i.hide()},i.options.delay.hide)):i.hide())},i.prototype.show=function(){var e=t.Event("show.bs."+this.type)
if(this.hasContent()&&this.enabled){this.$element.trigger(e)
var n=t.contains(this.$element[0].ownerDocument.documentElement,this.$element[0])
if(e.isDefaultPrevented()||!n)return
var s=this,r=this.tip(),o=this.getUID(this.type)
this.setContent(),r.attr("id",o),this.$element.attr("aria-describedby",o),this.options.animation&&r.addClass("fade")
var a="function"==typeof this.options.placement?this.options.placement.call(this,r[0],this.$element[0]):this.options.placement,l=/\s?auto?\s?/i,u=l.test(a)
u&&(a=a.replace(l,"")||"top"),r.detach().css({top:0,left:0,display:"block"}).addClass(a).data("bs."+this.type,this),this.options.container?r.appendTo(this.options.container):r.insertAfter(this.$element),this.$element.trigger("inserted.bs."+this.type)
var h=this.getPosition(),c=r[0].offsetWidth,d=r[0].offsetHeight
if(u){var f=a,p=this.getPosition(this.$viewport)
a="bottom"==a&&h.bottom+d>p.bottom?"top":"top"==a&&h.top-d<p.top?"bottom":"right"==a&&h.right+c>p.width?"left":"left"==a&&h.left-c<p.left?"right":a,r.removeClass(f).addClass(a)}var m=this.getCalculatedOffset(a,h,c,d)
this.applyPlacement(m,a)
var g=function(){var t=s.hoverState
s.$element.trigger("shown.bs."+s.type),s.hoverState=null,"out"==t&&s.leave(s)}
t.support.transition&&this.$tip.hasClass("fade")?r.one("bsTransitionEnd",g).emulateTransitionEnd(i.TRANSITION_DURATION):g()}},i.prototype.applyPlacement=function(e,i){var n=this.tip(),s=n[0].offsetWidth,r=n[0].offsetHeight,o=parseInt(n.css("margin-top"),10),a=parseInt(n.css("margin-left"),10)
isNaN(o)&&(o=0),isNaN(a)&&(a=0),e.top+=o,e.left+=a,t.offset.setOffset(n[0],t.extend({using:function(t){n.css({top:Math.round(t.top),left:Math.round(t.left)})}},e),0),n.addClass("in")
var l=n[0].offsetWidth,u=n[0].offsetHeight
"top"==i&&u!=r&&(e.top=e.top+r-u)
var h=this.getViewportAdjustedDelta(i,e,l,u)
h.left?e.left+=h.left:e.top+=h.top
var c=/top|bottom/.test(i),d=c?2*h.left-s+l:2*h.top-r+u,f=c?"offsetWidth":"offsetHeight"
n.offset(e),this.replaceArrow(d,n[0][f],c)},i.prototype.replaceArrow=function(t,e,i){this.arrow().css(i?"left":"top",50*(1-t/e)+"%").css(i?"top":"left","")},i.prototype.setContent=function(){var t=this.tip(),e=this.getTitle()
t.find(".tooltip-inner")[this.options.html?"html":"text"](e),t.removeClass("fade in top bottom left right")},i.prototype.hide=function(e){function n(){"in"!=s.hoverState&&r.detach(),s.$element.removeAttr("aria-describedby").trigger("hidden.bs."+s.type),e&&e()}var s=this,r=t(this.$tip),o=t.Event("hide.bs."+this.type)
return this.$element.trigger(o),o.isDefaultPrevented()?void 0:(r.removeClass("in"),t.support.transition&&r.hasClass("fade")?r.one("bsTransitionEnd",n).emulateTransitionEnd(i.TRANSITION_DURATION):n(),this.hoverState=null,this)},i.prototype.fixTitle=function(){var t=this.$element;(t.attr("title")||"string"!=typeof t.attr("data-original-title"))&&t.attr("data-original-title",t.attr("title")||"").attr("title","")},i.prototype.hasContent=function(){return this.getTitle()},i.prototype.getPosition=function(e){e=e||this.$element
var i=e[0],n="BODY"==i.tagName,s=i.getBoundingClientRect()
null==s.width&&(s=t.extend({},s,{width:s.right-s.left,height:s.bottom-s.top}))
var r=n?{top:0,left:0}:e.offset(),o={scroll:n?document.documentElement.scrollTop||document.body.scrollTop:e.scrollTop()},a=n?{width:t(window).width(),height:t(window).height()}:null
return t.extend({},s,o,a,r)},i.prototype.getCalculatedOffset=function(t,e,i,n){return"bottom"==t?{top:e.top+e.height,left:e.left+e.width/2-i/2}:"top"==t?{top:e.top-n,left:e.left+e.width/2-i/2}:"left"==t?{top:e.top+e.height/2-n/2,left:e.left-i}:{top:e.top+e.height/2-n/2,left:e.left+e.width}},i.prototype.getViewportAdjustedDelta=function(t,e,i,n){var s={top:0,left:0}
if(!this.$viewport)return s
var r=this.options.viewport&&this.options.viewport.padding||0,o=this.getPosition(this.$viewport)
if(/right|left/.test(t)){var a=e.top-r-o.scroll,l=e.top+r-o.scroll+n
a<o.top?s.top=o.top-a:l>o.top+o.height&&(s.top=o.top+o.height-l)}else{var u=e.left-r,h=e.left+r+i
u<o.left?s.left=o.left-u:h>o.right&&(s.left=o.left+o.width-h)}return s},i.prototype.getTitle=function(){var t,e=this.$element,i=this.options
return t=e.attr("data-original-title")||("function"==typeof i.title?i.title.call(e[0]):i.title)},i.prototype.getUID=function(t){do t+=~~(1e6*Math.random())
while(document.getElementById(t))
return t},i.prototype.tip=function(){if(!this.$tip&&(this.$tip=t(this.options.template),1!=this.$tip.length))throw new Error(this.type+" `template` option must consist of exactly 1 top-level element!")
return this.$tip},i.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")},i.prototype.enable=function(){this.enabled=!0},i.prototype.disable=function(){this.enabled=!1},i.prototype.toggleEnabled=function(){this.enabled=!this.enabled},i.prototype.toggle=function(e){var i=this
e&&(i=t(e.currentTarget).data("bs."+this.type),i||(i=new this.constructor(e.currentTarget,this.getDelegateOptions()),t(e.currentTarget).data("bs."+this.type,i))),e?(i.inState.click=!i.inState.click,i.isInStateTrue()?i.enter(i):i.leave(i)):i.tip().hasClass("in")?i.leave(i):i.enter(i)},i.prototype.destroy=function(){var t=this
clearTimeout(this.timeout),this.hide(function(){t.$element.off("."+t.type).removeData("bs."+t.type),t.$tip&&t.$tip.detach(),t.$tip=null,t.$arrow=null,t.$viewport=null})}
var n=t.fn.tooltip
t.fn.tooltip=e,t.fn.tooltip.Constructor=i,t.fn.tooltip.noConflict=function(){return t.fn.tooltip=n,this}}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var n=t(this),s=n.data("bs.popover"),r="object"==typeof e&&e;(s||!/destroy|hide/.test(e))&&(s||n.data("bs.popover",s=new i(this,r)),"string"==typeof e&&s[e]())})}var i=function(t,e){this.init("popover",t,e)}
if(!t.fn.tooltip)throw new Error("Popover requires tooltip.js")
i.VERSION="3.3.6",i.DEFAULTS=t.extend({},t.fn.tooltip.Constructor.DEFAULTS,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'}),i.prototype=t.extend({},t.fn.tooltip.Constructor.prototype),i.prototype.constructor=i,i.prototype.getDefaults=function(){return i.DEFAULTS},i.prototype.setContent=function(){var t=this.tip(),e=this.getTitle(),i=this.getContent()
t.find(".popover-title")[this.options.html?"html":"text"](e),t.find(".popover-content").children().detach().end()[this.options.html?"string"==typeof i?"html":"append":"text"](i),t.removeClass("fade top bottom left right in"),t.find(".popover-title").html()||t.find(".popover-title").hide()},i.prototype.hasContent=function(){return this.getTitle()||this.getContent()},i.prototype.getContent=function(){var t=this.$element,e=this.options
return t.attr("data-content")||("function"==typeof e.content?e.content.call(t[0]):e.content)},i.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".arrow")}
var n=t.fn.popover
t.fn.popover=e,t.fn.popover.Constructor=i,t.fn.popover.noConflict=function(){return t.fn.popover=n,this}}(jQuery),+function(t){"use strict"
function e(i,n){this.$body=t(document.body),this.$scrollElement=t(t(i).is(document.body)?window:i),this.options=t.extend({},e.DEFAULTS,n),this.selector=(this.options.target||"")+" .nav li > a",this.offsets=[],this.targets=[],this.activeTarget=null,this.scrollHeight=0,this.$scrollElement.on("scroll.bs.scrollspy",t.proxy(this.process,this)),this.refresh(),this.process()}function i(i){return this.each(function(){var n=t(this),s=n.data("bs.scrollspy"),r="object"==typeof i&&i
s||n.data("bs.scrollspy",s=new e(this,r)),"string"==typeof i&&s[i]()})}e.VERSION="3.3.6",e.DEFAULTS={offset:10},e.prototype.getScrollHeight=function(){return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)},e.prototype.refresh=function(){var e=this,i="offset",n=0
this.offsets=[],this.targets=[],this.scrollHeight=this.getScrollHeight(),t.isWindow(this.$scrollElement[0])||(i="position",n=this.$scrollElement.scrollTop()),this.$body.find(this.selector).map(function(){var e=t(this),s=e.data("target")||e.attr("href"),r=/^#./.test(s)&&t(s)
return r&&r.length&&r.is(":visible")&&[[r[i]().top+n,s]]||null}).sort(function(t,e){return t[0]-e[0]}).each(function(){e.offsets.push(this[0]),e.targets.push(this[1])})},e.prototype.process=function(){var t,e=this.$scrollElement.scrollTop()+this.options.offset,i=this.getScrollHeight(),n=this.options.offset+i-this.$scrollElement.height(),s=this.offsets,r=this.targets,o=this.activeTarget
if(this.scrollHeight!=i&&this.refresh(),e>=n)return o!=(t=r[r.length-1])&&this.activate(t)
if(o&&e<s[0])return this.activeTarget=null,this.clear()
for(t=s.length;t--;)o!=r[t]&&e>=s[t]&&(void 0===s[t+1]||e<s[t+1])&&this.activate(r[t])},e.prototype.activate=function(e){this.activeTarget=e,this.clear()
var i=this.selector+'[data-target="'+e+'"],'+this.selector+'[href="'+e+'"]',n=t(i).parents("li").addClass("active")
n.parent(".dropdown-menu").length&&(n=n.closest("li.dropdown").addClass("active")),n.trigger("activate.bs.scrollspy")},e.prototype.clear=function(){t(this.selector).parentsUntil(this.options.target,".active").removeClass("active")}
var n=t.fn.scrollspy
t.fn.scrollspy=i,t.fn.scrollspy.Constructor=e,t.fn.scrollspy.noConflict=function(){return t.fn.scrollspy=n,this},t(window).on("load.bs.scrollspy.data-api",function(){t('[data-spy="scroll"]').each(function(){var e=t(this)
i.call(e,e.data())})})}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var n=t(this),s=n.data("bs.tab")
s||n.data("bs.tab",s=new i(this)),"string"==typeof e&&s[e]()})}var i=function(e){this.element=t(e)}
i.VERSION="3.3.6",i.TRANSITION_DURATION=150,i.prototype.show=function(){var e=this.element,i=e.closest("ul:not(.dropdown-menu)"),n=e.data("target")
if(n||(n=e.attr("href"),n=n&&n.replace(/.*(?=#[^\s]*$)/,"")),!e.parent("li").hasClass("active")){var s=i.find(".active:last a"),r=t.Event("hide.bs.tab",{relatedTarget:e[0]}),o=t.Event("show.bs.tab",{relatedTarget:s[0]})
if(s.trigger(r),e.trigger(o),!o.isDefaultPrevented()&&!r.isDefaultPrevented()){var a=t(n)
this.activate(e.closest("li"),i),this.activate(a,a.parent(),function(){s.trigger({type:"hidden.bs.tab",relatedTarget:e[0]}),e.trigger({type:"shown.bs.tab",relatedTarget:s[0]})})}}},i.prototype.activate=function(e,n,s){function r(){o.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!1),e.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded",!0),a?(e[0].offsetWidth,e.addClass("in")):e.removeClass("fade"),e.parent(".dropdown-menu").length&&e.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!0),s&&s()}var o=n.find("> .active"),a=s&&t.support.transition&&(o.length&&o.hasClass("fade")||!!n.find("> .fade").length)
o.length&&a?o.one("bsTransitionEnd",r).emulateTransitionEnd(i.TRANSITION_DURATION):r(),o.removeClass("in")}
var n=t.fn.tab
t.fn.tab=e,t.fn.tab.Constructor=i,t.fn.tab.noConflict=function(){return t.fn.tab=n,this}
var s=function(i){i.preventDefault(),e.call(t(this),"show")}
t(document).on("click.bs.tab.data-api",'[data-toggle="tab"]',s).on("click.bs.tab.data-api",'[data-toggle="pill"]',s)}(jQuery),+function(t){"use strict"
function e(e){return this.each(function(){var n=t(this),s=n.data("bs.affix"),r="object"==typeof e&&e
s||n.data("bs.affix",s=new i(this,r)),"string"==typeof e&&s[e]()})}var i=function(e,n){this.options=t.extend({},i.DEFAULTS,n),this.$target=t(this.options.target).on("scroll.bs.affix.data-api",t.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",t.proxy(this.checkPositionWithEventLoop,this)),this.$element=t(e),this.affixed=null,this.unpin=null,this.pinnedOffset=null,this.checkPosition()}
i.VERSION="3.3.6",i.RESET="affix affix-top affix-bottom",i.DEFAULTS={offset:0,target:window},i.prototype.getState=function(t,e,i,n){var s=this.$target.scrollTop(),r=this.$element.offset(),o=this.$target.height()
if(null!=i&&"top"==this.affixed)return i>s&&"top"
if("bottom"==this.affixed)return null!=i?!(s+this.unpin<=r.top)&&"bottom":!(t-n>=s+o)&&"bottom"
var a=null==this.affixed,l=a?s:r.top,u=a?o:e
return null!=i&&i>=s?"top":null!=n&&l+u>=t-n&&"bottom"},i.prototype.getPinnedOffset=function(){if(this.pinnedOffset)return this.pinnedOffset
this.$element.removeClass(i.RESET).addClass("affix")
var t=this.$target.scrollTop(),e=this.$element.offset()
return this.pinnedOffset=e.top-t},i.prototype.checkPositionWithEventLoop=function(){setTimeout(t.proxy(this.checkPosition,this),1)},i.prototype.checkPosition=function(){if(this.$element.is(":visible")){var e=this.$element.height(),n=this.options.offset,s=n.top,r=n.bottom,o=Math.max(t(document).height(),t(document.body).height())
"object"!=typeof n&&(r=s=n),"function"==typeof s&&(s=n.top(this.$element)),"function"==typeof r&&(r=n.bottom(this.$element))
var a=this.getState(o,e,s,r)
if(this.affixed!=a){null!=this.unpin&&this.$element.css("top","")
var l="affix"+(a?"-"+a:""),u=t.Event(l+".bs.affix")
if(this.$element.trigger(u),u.isDefaultPrevented())return
this.affixed=a,this.unpin="bottom"==a?this.getPinnedOffset():null,this.$element.removeClass(i.RESET).addClass(l).trigger(l.replace("affix","affixed")+".bs.affix")}"bottom"==a&&this.$element.offset({top:o-e-r})}}
var n=t.fn.affix
t.fn.affix=e,t.fn.affix.Constructor=i,t.fn.affix.noConflict=function(){return t.fn.affix=n,this},t(window).on("load",function(){t('[data-spy="affix"]').each(function(){var i=t(this),n=i.data()
n.offset=n.offset||{},null!=n.offsetBottom&&(n.offset.bottom=n.offsetBottom),null!=n.offsetTop&&(n.offset.top=n.offsetTop),e.call(i,n)})})}(jQuery),function(t){"function"==typeof define&&define.amd?define(["jquery"],t):t("object"==typeof exports?require("jquery"):jQuery)}(function(t,e){function i(){return new Date(Date.UTC.apply(Date,arguments))}function n(){var t=new Date
return i(t.getFullYear(),t.getMonth(),t.getDate())}function s(t,e){return t.getUTCFullYear()===e.getUTCFullYear()&&t.getUTCMonth()===e.getUTCMonth()&&t.getUTCDate()===e.getUTCDate()}function r(t){return function(){return this[t].apply(this,arguments)}}function o(t){return t&&!isNaN(t.getTime())}function a(e,i){function n(t,e){return e.toLowerCase()}var s,r=t(e).data(),o={},a=new RegExp("^"+i.toLowerCase()+"([A-Z])")
i=new RegExp("^"+i.toLowerCase())
for(var l in r)i.test(l)&&(s=l.replace(a,n),o[s]=r[l])
return o}function l(e){var i={}
if(g[e]||(e=e.split("-")[0],g[e])){var n=g[e]
return t.each(m,function(t,e){e in n&&(i[e]=n[e])}),i}}var u=function(){var e={get:function(t){return this.slice(t)[0]},contains:function(t){for(var e=t&&t.valueOf(),i=0,n=this.length;i<n;i++)if(this[i].valueOf()===e)return i
return-1},remove:function(t){this.splice(t,1)},replace:function(e){e&&(t.isArray(e)||(e=[e]),this.clear(),this.push.apply(this,e))},clear:function(){this.length=0},copy:function(){var t=new u
return t.replace(this),t}}
return function(){var i=[]
return i.push.apply(i,arguments),t.extend(i,e),i}}(),h=function(e,i){t(e).data("datepicker",this),this._process_options(i),this.dates=new u,this.viewDate=this.o.defaultViewDate,this.focusDate=null,this.element=t(e),this.isInput=this.element.is("input"),this.inputField=this.isInput?this.element:this.element.find("input"),this.component=!!this.element.hasClass("date")&&this.element.find(".add-on, .input-group-addon, .btn"),this.hasInput=this.component&&this.inputField.length,this.component&&0===this.component.length&&(this.component=!1),this.isInline=!this.component&&this.element.is("div"),this.picker=t(v.template),this._check_template(this.o.templates.leftArrow)&&this.picker.find(".prev").html(this.o.templates.leftArrow),this._check_template(this.o.templates.rightArrow)&&this.picker.find(".next").html(this.o.templates.rightArrow),this._buildEvents(),this._attachEvents(),this.isInline?this.picker.addClass("datepicker-inline").appendTo(this.element):this.picker.addClass("datepicker-dropdown dropdown-menu"),this.o.rtl&&this.picker.addClass("datepicker-rtl"),this.viewMode=this.o.startView,this.o.calendarWeeks&&this.picker.find("thead .datepicker-title, tfoot .today, tfoot .clear").attr("colspan",function(t,e){return parseInt(e)+1}),this._allow_update=!1,this.setStartDate(this._o.startDate),this.setEndDate(this._o.endDate),this.setDaysOfWeekDisabled(this.o.daysOfWeekDisabled),this.setDaysOfWeekHighlighted(this.o.daysOfWeekHighlighted),this.setDatesDisabled(this.o.datesDisabled),this.fillDow(),this.fillMonths(),this._allow_update=!0,this.update(),this.showMode(),this.isInline&&this.show()}
h.prototype={constructor:h,_resolveViewName:function(t,i){return 0===t||"days"===t||"month"===t?0:1===t||"months"===t||"year"===t?1:2===t||"years"===t||"decade"===t?2:3===t||"decades"===t||"century"===t?3:4===t||"centuries"===t||"millennium"===t?4:i!==e&&i},_check_template:function(i){try{if(i===e||""===i)return!1
if((i.match(/[<>]/g)||[]).length<=0)return!0
var n=t(i)
return n.length>0}catch(t){return!1}},_process_options:function(e){this._o=t.extend({},this._o,e)
var s=this.o=t.extend({},this._o),r=s.language
g[r]||(r=r.split("-")[0],g[r]||(r=p.language)),s.language=r,s.startView=this._resolveViewName(s.startView,0),s.minViewMode=this._resolveViewName(s.minViewMode,0),s.maxViewMode=this._resolveViewName(s.maxViewMode,4),s.startView=Math.min(s.startView,s.maxViewMode),s.startView=Math.max(s.startView,s.minViewMode),s.multidate!==!0&&(s.multidate=Number(s.multidate)||!1,s.multidate!==!1&&(s.multidate=Math.max(0,s.multidate))),s.multidateSeparator=String(s.multidateSeparator),s.weekStart%=7,s.weekEnd=(s.weekStart+6)%7
var o=v.parseFormat(s.format)
s.startDate!==-(1/0)&&(s.startDate?s.startDate instanceof Date?s.startDate=this._local_to_utc(this._zero_time(s.startDate)):s.startDate=v.parseDate(s.startDate,o,s.language,s.assumeNearbyYear):s.startDate=-(1/0)),s.endDate!==1/0&&(s.endDate?s.endDate instanceof Date?s.endDate=this._local_to_utc(this._zero_time(s.endDate)):s.endDate=v.parseDate(s.endDate,o,s.language,s.assumeNearbyYear):s.endDate=1/0),s.daysOfWeekDisabled=s.daysOfWeekDisabled||[],t.isArray(s.daysOfWeekDisabled)||(s.daysOfWeekDisabled=s.daysOfWeekDisabled.split(/[,\s]*/)),s.daysOfWeekDisabled=t.map(s.daysOfWeekDisabled,function(t){return parseInt(t,10)}),s.daysOfWeekHighlighted=s.daysOfWeekHighlighted||[],t.isArray(s.daysOfWeekHighlighted)||(s.daysOfWeekHighlighted=s.daysOfWeekHighlighted.split(/[,\s]*/)),s.daysOfWeekHighlighted=t.map(s.daysOfWeekHighlighted,function(t){return parseInt(t,10)}),s.datesDisabled=s.datesDisabled||[],t.isArray(s.datesDisabled)||(s.datesDisabled=[s.datesDisabled]),s.datesDisabled=t.map(s.datesDisabled,function(t){return v.parseDate(t,o,s.language,s.assumeNearbyYear)})
var a=String(s.orientation).toLowerCase().split(/\s+/g),l=s.orientation.toLowerCase()
if(a=t.grep(a,function(t){return/^auto|left|right|top|bottom$/.test(t)}),s.orientation={x:"auto",y:"auto"},l&&"auto"!==l)if(1===a.length)switch(a[0]){case"top":case"bottom":s.orientation.y=a[0]
break
case"left":case"right":s.orientation.x=a[0]}else l=t.grep(a,function(t){return/^left|right$/.test(t)}),s.orientation.x=l[0]||"auto",l=t.grep(a,function(t){return/^top|bottom$/.test(t)}),s.orientation.y=l[0]||"auto"
else;if(s.defaultViewDate){var u=s.defaultViewDate.year||(new Date).getFullYear(),h=s.defaultViewDate.month||0,c=s.defaultViewDate.day||1
s.defaultViewDate=i(u,h,c)}else s.defaultViewDate=n()},_events:[],_secondaryEvents:[],_applyEvents:function(t){for(var i,n,s,r=0;r<t.length;r++)i=t[r][0],2===t[r].length?(n=e,s=t[r][1]):3===t[r].length&&(n=t[r][1],s=t[r][2]),i.on(s,n)},_unapplyEvents:function(t){for(var i,n,s,r=0;r<t.length;r++)i=t[r][0],2===t[r].length?(s=e,n=t[r][1]):3===t[r].length&&(s=t[r][1],n=t[r][2]),i.off(n,s)},_buildEvents:function(){var e={keyup:t.proxy(function(e){t.inArray(e.keyCode,[27,37,39,38,40,32,13,9])===-1&&this.update()},this),keydown:t.proxy(this.keydown,this),paste:t.proxy(this.paste,this)}
this.o.showOnFocus===!0&&(e.focus=t.proxy(this.show,this)),this.isInput?this._events=[[this.element,e]]:this.component&&this.hasInput?this._events=[[this.inputField,e],[this.component,{click:t.proxy(this.show,this)}]]:this._events=[[this.element,{click:t.proxy(this.show,this),keydown:t.proxy(this.keydown,this)}]],this._events.push([this.element,"*",{blur:t.proxy(function(t){this._focused_from=t.target},this)}],[this.element,{blur:t.proxy(function(t){this._focused_from=t.target},this)}]),this.o.immediateUpdates&&this._events.push([this.element,{"changeYear changeMonth":t.proxy(function(t){this.update(t.date)},this)}]),this._secondaryEvents=[[this.picker,{click:t.proxy(this.click,this)}],[t(window),{resize:t.proxy(this.place,this)}],[t(document),{mousedown:t.proxy(function(t){this.element.is(t.target)||this.element.find(t.target).length||this.picker.is(t.target)||this.picker.find(t.target).length||this.isInline||this.hide()},this)}]]},_attachEvents:function(){this._detachEvents(),this._applyEvents(this._events)},_detachEvents:function(){this._unapplyEvents(this._events)},_attachSecondaryEvents:function(){this._detachSecondaryEvents(),this._applyEvents(this._secondaryEvents)},_detachSecondaryEvents:function(){this._unapplyEvents(this._secondaryEvents)},_trigger:function(e,i){var n=i||this.dates.get(-1),s=this._utc_to_local(n)
this.element.trigger({type:e,date:s,dates:t.map(this.dates,this._utc_to_local),format:t.proxy(function(t,e){0===arguments.length?(t=this.dates.length-1,e=this.o.format):"string"==typeof t&&(e=t,t=this.dates.length-1),e=e||this.o.format
var i=this.dates.get(t)
return v.formatDate(i,e,this.o.language)},this)})},show:function(){if(!(this.inputField.prop("disabled")||this.inputField.prop("readonly")&&this.o.enableOnReadonly===!1))return this.isInline||this.picker.appendTo(this.o.container),this.place(),this.picker.show(),this._attachSecondaryEvents(),this._trigger("show"),(window.navigator.msMaxTouchPoints||"ontouchstart"in document)&&this.o.disableTouchKeyboard&&t(this.element).blur(),this},hide:function(){return this.isInline||!this.picker.is(":visible")?this:(this.focusDate=null,this.picker.hide().detach(),this._detachSecondaryEvents(),this.viewMode=this.o.startView,this.showMode(),this.o.forceParse&&this.inputField.val()&&this.setValue(),this._trigger("hide"),this)},destroy:function(){return this.hide(),this._detachEvents(),this._detachSecondaryEvents(),this.picker.remove(),delete this.element.data().datepicker,this.isInput||delete this.element.data().date,this},paste:function(e){var i
if(e.originalEvent.clipboardData&&e.originalEvent.clipboardData.types&&t.inArray("text/plain",e.originalEvent.clipboardData.types)!==-1)i=e.originalEvent.clipboardData.getData("text/plain")
else{if(!window.clipboardData)return
i=window.clipboardData.getData("Text")}this.setDate(i),this.update(),e.preventDefault()},_utc_to_local:function(t){return t&&new Date(t.getTime()+6e4*t.getTimezoneOffset())},_local_to_utc:function(t){return t&&new Date(t.getTime()-6e4*t.getTimezoneOffset())},_zero_time:function(t){return t&&new Date(t.getFullYear(),t.getMonth(),t.getDate())},_zero_utc_time:function(t){return t&&new Date(Date.UTC(t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate()))},getDates:function(){return t.map(this.dates,this._utc_to_local)},getUTCDates:function(){return t.map(this.dates,function(t){return new Date(t)})},getDate:function(){return this._utc_to_local(this.getUTCDate())},getUTCDate:function(){var t=this.dates.get(-1)
return"undefined"!=typeof t?new Date(t):null},clearDates:function(){this.inputField&&this.inputField.val(""),this.update(),this._trigger("changeDate"),this.o.autoclose&&this.hide()},setDates:function(){var e=t.isArray(arguments[0])?arguments[0]:arguments
return this.update.apply(this,e),this._trigger("changeDate"),this.setValue(),this},setUTCDates:function(){var e=t.isArray(arguments[0])?arguments[0]:arguments
return this.update.apply(this,t.map(e,this._utc_to_local)),this._trigger("changeDate"),this.setValue(),this},setDate:r("setDates"),setUTCDate:r("setUTCDates"),remove:r("destroy"),setValue:function(){var t=this.getFormattedDate()
return this.inputField.val(t),this},getFormattedDate:function(i){i===e&&(i=this.o.format)
var n=this.o.language
return t.map(this.dates,function(t){return v.formatDate(t,i,n)}).join(this.o.multidateSeparator)},getStartDate:function(){return this.o.startDate},setStartDate:function(t){return this._process_options({startDate:t}),this.update(),this.updateNavArrows(),this},getEndDate:function(){return this.o.endDate},setEndDate:function(t){return this._process_options({endDate:t}),this.update(),this.updateNavArrows(),this},setDaysOfWeekDisabled:function(t){return this._process_options({daysOfWeekDisabled:t}),this.update(),this.updateNavArrows(),this},setDaysOfWeekHighlighted:function(t){return this._process_options({daysOfWeekHighlighted:t}),this.update(),this},setDatesDisabled:function(t){this._process_options({datesDisabled:t}),this.update(),this.updateNavArrows()},place:function(){if(this.isInline)return this
var e=this.picker.outerWidth(),i=this.picker.outerHeight(),n=10,s=t(this.o.container),r=s.width(),o="body"===this.o.container?t(document).scrollTop():s.scrollTop(),a=s.offset(),l=[]
this.element.parents().each(function(){var e=t(this).css("z-index")
"auto"!==e&&0!==e&&l.push(parseInt(e))})
var u=Math.max.apply(Math,l)+this.o.zIndexOffset,h=this.component?this.component.parent().offset():this.element.offset(),c=this.component?this.component.outerHeight(!0):this.element.outerHeight(!1),d=this.component?this.component.outerWidth(!0):this.element.outerWidth(!1),f=h.left-a.left,p=h.top-a.top
"body"!==this.o.container&&(p+=o),this.picker.removeClass("datepicker-orient-top datepicker-orient-bottom datepicker-orient-right datepicker-orient-left"),"auto"!==this.o.orientation.x?(this.picker.addClass("datepicker-orient-"+this.o.orientation.x),"right"===this.o.orientation.x&&(f-=e-d)):h.left<0?(this.picker.addClass("datepicker-orient-left"),f-=h.left-n):f+e>r?(this.picker.addClass("datepicker-orient-right"),f+=d-e):this.picker.addClass("datepicker-orient-left")
var m,g=this.o.orientation.y
if("auto"===g&&(m=-o+p-i,g=m<0?"bottom":"top"),this.picker.addClass("datepicker-orient-"+g),"top"===g?p-=i+parseInt(this.picker.css("padding-top")):p+=c,this.o.rtl){var v=r-(f+d)
this.picker.css({top:p,right:v,zIndex:u})}else this.picker.css({top:p,left:f,zIndex:u})
return this},_allow_update:!0,update:function(){if(!this._allow_update)return this
var e=this.dates.copy(),i=[],n=!1
return arguments.length?(t.each(arguments,t.proxy(function(t,e){e instanceof Date&&(e=this._local_to_utc(e)),i.push(e)},this)),n=!0):(i=this.isInput?this.element.val():this.element.data("date")||this.inputField.val(),i=i&&this.o.multidate?i.split(this.o.multidateSeparator):[i],delete this.element.data().date),i=t.map(i,t.proxy(function(t){return v.parseDate(t,this.o.format,this.o.language,this.o.assumeNearbyYear)},this)),i=t.grep(i,t.proxy(function(t){return!this.dateWithinRange(t)||!t},this),!0),this.dates.replace(i),this.dates.length?this.viewDate=new Date(this.dates.get(-1)):this.viewDate<this.o.startDate?this.viewDate=new Date(this.o.startDate):this.viewDate>this.o.endDate?this.viewDate=new Date(this.o.endDate):this.viewDate=this.o.defaultViewDate,n?this.setValue():i.length&&String(e)!==String(this.dates)&&this._trigger("changeDate"),!this.dates.length&&e.length&&this._trigger("clearDate"),this.fill(),this.element.change(),this},fillDow:function(){var e=this.o.weekStart,i="<tr>"
for(this.o.calendarWeeks&&(this.picker.find(".datepicker-days .datepicker-switch").attr("colspan",function(t,e){return parseInt(e)+1}),i+='<th class="cw">&#160;</th>');e<this.o.weekStart+7;)i+='<th class="dow',t.inArray(e,this.o.daysOfWeekDisabled)>-1&&(i+=" disabled"),i+='">'+g[this.o.language].daysMin[e++%7]+"</th>"
i+="</tr>",this.picker.find(".datepicker-days thead").append(i)},fillMonths:function(){for(var t=this._utc_to_local(this.viewDate),e="",i=0;i<12;){var n=t&&t.getMonth()===i?" focused":""
e+='<span class="month'+n+'">'+g[this.o.language].monthsShort[i++]+"</span>"}this.picker.find(".datepicker-months td").html(e)},setRange:function(e){e&&e.length?this.range=t.map(e,function(t){return t.valueOf()}):delete this.range,this.fill()},getClassNames:function(e){var i=[],n=this.viewDate.getUTCFullYear(),s=this.viewDate.getUTCMonth(),r=new Date
return e.getUTCFullYear()<n||e.getUTCFullYear()===n&&e.getUTCMonth()<s?i.push("old"):(e.getUTCFullYear()>n||e.getUTCFullYear()===n&&e.getUTCMonth()>s)&&i.push("new"),this.focusDate&&e.valueOf()===this.focusDate.valueOf()&&i.push("focused"),this.o.todayHighlight&&e.getUTCFullYear()===r.getFullYear()&&e.getUTCMonth()===r.getMonth()&&e.getUTCDate()===r.getDate()&&i.push("today"),this.dates.contains(e)!==-1&&i.push("active"),this.dateWithinRange(e)||i.push("disabled"),this.dateIsDisabled(e)&&i.push("disabled","disabled-date"),t.inArray(e.getUTCDay(),this.o.daysOfWeekHighlighted)!==-1&&i.push("highlighted"),this.range&&(e>this.range[0]&&e<this.range[this.range.length-1]&&i.push("range"),t.inArray(e.valueOf(),this.range)!==-1&&i.push("selected"),e.valueOf()===this.range[0]&&i.push("range-start"),e.valueOf()===this.range[this.range.length-1]&&i.push("range-end")),i},_fill_yearsView:function(i,n,s,r,o,a,l,u){var h,c,d,f,p,m,g,v,y,_,b
for(h="",c=this.picker.find(i),d=parseInt(o/s,10)*s,p=parseInt(a/r,10)*r,m=parseInt(l/r,10)*r,f=t.map(this.dates,function(t){return parseInt(t.getUTCFullYear()/r,10)*r}),c.find(".datepicker-switch").text(d+"-"+(d+9*r)),g=d-r,v=-1;v<11;v+=1)y=[n],_=null,v===-1?y.push("old"):10===v&&y.push("new"),t.inArray(g,f)!==-1&&y.push("active"),(g<p||g>m)&&y.push("disabled"),g===this.viewDate.getFullYear()&&y.push("focused"),u!==t.noop&&(b=u(new Date(g,0,1)),b===e?b={}:"boolean"==typeof b?b={enabled:b}:"string"==typeof b&&(b={classes:b}),b.enabled===!1&&y.push("disabled"),b.classes&&(y=y.concat(b.classes.split(/\s+/))),b.tooltip&&(_=b.tooltip)),h+='<span class="'+y.join(" ")+'"'+(_?' title="'+_+'"':"")+">"+g+"</span>",g+=r
c.find("td").html(h)},fill:function(){var n,s,r=new Date(this.viewDate),o=r.getUTCFullYear(),a=r.getUTCMonth(),l=this.o.startDate!==-(1/0)?this.o.startDate.getUTCFullYear():-(1/0),u=this.o.startDate!==-(1/0)?this.o.startDate.getUTCMonth():-(1/0),h=this.o.endDate!==1/0?this.o.endDate.getUTCFullYear():1/0,c=this.o.endDate!==1/0?this.o.endDate.getUTCMonth():1/0,d=g[this.o.language].today||g.en.today||"",f=g[this.o.language].clear||g.en.clear||"",p=g[this.o.language].titleFormat||g.en.titleFormat
if(!isNaN(o)&&!isNaN(a)){this.picker.find(".datepicker-days .datepicker-switch").text(v.formatDate(r,p,this.o.language)),this.picker.find("tfoot .today").text(d).toggle(this.o.todayBtn!==!1),this.picker.find("tfoot .clear").text(f).toggle(this.o.clearBtn!==!1),this.picker.find("thead .datepicker-title").text(this.o.title).toggle(""!==this.o.title),this.updateNavArrows(),this.fillMonths()
var m=i(o,a-1,28),y=v.getDaysInMonth(m.getUTCFullYear(),m.getUTCMonth())
m.setUTCDate(y),m.setUTCDate(y-(m.getUTCDay()-this.o.weekStart+7)%7)
var _=new Date(m)
m.getUTCFullYear()<100&&_.setUTCFullYear(m.getUTCFullYear()),_.setUTCDate(_.getUTCDate()+42),_=_.valueOf()
for(var b,w=[];m.valueOf()<_;){if(m.getUTCDay()===this.o.weekStart&&(w.push("<tr>"),this.o.calendarWeeks)){var x=new Date(+m+(this.o.weekStart-m.getUTCDay()-7)%7*864e5),k=new Date(Number(x)+(11-x.getUTCDay())%7*864e5),D=new Date(Number(D=i(k.getUTCFullYear(),0,1))+(11-D.getUTCDay())%7*864e5),T=(k-D)/864e5/7+1
w.push('<td class="cw">'+T+"</td>")}b=this.getClassNames(m),b.push("day"),this.o.beforeShowDay!==t.noop&&(s=this.o.beforeShowDay(this._utc_to_local(m)),s===e?s={}:"boolean"==typeof s?s={enabled:s}:"string"==typeof s&&(s={classes:s}),s.enabled===!1&&b.push("disabled"),s.classes&&(b=b.concat(s.classes.split(/\s+/))),s.tooltip&&(n=s.tooltip)),b=t.isFunction(t.uniqueSort)?t.uniqueSort(b):t.unique(b),w.push('<td class="'+b.join(" ")+'"'+(n?' title="'+n+'"':"")+">"+m.getUTCDate()+"</td>"),n=null,m.getUTCDay()===this.o.weekEnd&&w.push("</tr>"),m.setUTCDate(m.getUTCDate()+1)}this.picker.find(".datepicker-days tbody").empty().append(w.join(""))
var C=g[this.o.language].monthsTitle||g.en.monthsTitle||"Months",S=this.picker.find(".datepicker-months").find(".datepicker-switch").text(this.o.maxViewMode<2?C:o).end().find("span").removeClass("active")
if(t.each(this.dates,function(t,e){e.getUTCFullYear()===o&&S.eq(e.getUTCMonth()).addClass("active")}),(o<l||o>h)&&S.addClass("disabled"),o===l&&S.slice(0,u).addClass("disabled"),o===h&&S.slice(c+1).addClass("disabled"),this.o.beforeShowMonth!==t.noop){var M=this
t.each(S,function(i,n){var s=new Date(o,i,1),r=M.o.beforeShowMonth(s)
r===e?r={}:"boolean"==typeof r?r={enabled:r}:"string"==typeof r&&(r={classes:r}),r.enabled!==!1||t(n).hasClass("disabled")||t(n).addClass("disabled"),r.classes&&t(n).addClass(r.classes),r.tooltip&&t(n).prop("title",r.tooltip)})}this._fill_yearsView(".datepicker-years","year",10,1,o,l,h,this.o.beforeShowYear),this._fill_yearsView(".datepicker-decades","decade",100,10,o,l,h,this.o.beforeShowDecade),this._fill_yearsView(".datepicker-centuries","century",1e3,100,o,l,h,this.o.beforeShowCentury)}},updateNavArrows:function(){if(this._allow_update){var t=new Date(this.viewDate),e=t.getUTCFullYear(),i=t.getUTCMonth()
switch(this.viewMode){case 0:this.o.startDate!==-(1/0)&&e<=this.o.startDate.getUTCFullYear()&&i<=this.o.startDate.getUTCMonth()?this.picker.find(".prev").css({visibility:"hidden"}):this.picker.find(".prev").css({visibility:"visible"}),this.o.endDate!==1/0&&e>=this.o.endDate.getUTCFullYear()&&i>=this.o.endDate.getUTCMonth()?this.picker.find(".next").css({visibility:"hidden"}):this.picker.find(".next").css({visibility:"visible"})
break
case 1:case 2:case 3:case 4:this.o.startDate!==-(1/0)&&e<=this.o.startDate.getUTCFullYear()||this.o.maxViewMode<2?this.picker.find(".prev").css({visibility:"hidden"}):this.picker.find(".prev").css({visibility:"visible"}),this.o.endDate!==1/0&&e>=this.o.endDate.getUTCFullYear()||this.o.maxViewMode<2?this.picker.find(".next").css({visibility:"hidden"}):this.picker.find(".next").css({visibility:"visible"})}}},click:function(e){e.preventDefault(),e.stopPropagation()
var s,r,o,a,l,u,h
s=t(e.target),s.hasClass("datepicker-switch")&&this.showMode(1)
var c=s.closest(".prev, .next")
c.length>0&&(r=v.modes[this.viewMode].navStep*(c.hasClass("prev")?-1:1),0===this.viewMode?(this.viewDate=this.moveMonth(this.viewDate,r),this._trigger("changeMonth",this.viewDate)):(this.viewDate=this.moveYear(this.viewDate,r),1===this.viewMode&&this._trigger("changeYear",this.viewDate)),this.fill()),s.hasClass("today")&&!s.hasClass("day")&&(this.showMode(-2),this._setDate(n(),"linked"===this.o.todayBtn?null:"view")),s.hasClass("clear")&&this.clearDates(),s.hasClass("disabled")||(s.hasClass("day")&&(o=parseInt(s.text(),10)||1,a=this.viewDate.getUTCFullYear(),l=this.viewDate.getUTCMonth(),s.hasClass("old")&&(0===l?(l=11,a-=1,u=!0,h=!0):(l-=1,u=!0)),s.hasClass("new")&&(11===l?(l=0,a+=1,u=!0,h=!0):(l+=1,u=!0)),this._setDate(i(a,l,o)),h&&this._trigger("changeYear",this.viewDate),u&&this._trigger("changeMonth",this.viewDate)),s.hasClass("month")&&(this.viewDate.setUTCDate(1),o=1,l=s.parent().find("span").index(s),a=this.viewDate.getUTCFullYear(),this.viewDate.setUTCMonth(l),this._trigger("changeMonth",this.viewDate),1===this.o.minViewMode?(this._setDate(i(a,l,o)),this.showMode()):this.showMode(-1),this.fill()),(s.hasClass("year")||s.hasClass("decade")||s.hasClass("century"))&&(this.viewDate.setUTCDate(1),o=1,l=0,a=parseInt(s.text(),10)||0,this.viewDate.setUTCFullYear(a),s.hasClass("year")&&(this._trigger("changeYear",this.viewDate),2===this.o.minViewMode&&this._setDate(i(a,l,o))),s.hasClass("decade")&&(this._trigger("changeDecade",this.viewDate),3===this.o.minViewMode&&this._setDate(i(a,l,o))),s.hasClass("century")&&(this._trigger("changeCentury",this.viewDate),4===this.o.minViewMode&&this._setDate(i(a,l,o))),this.showMode(-1),this.fill())),this.picker.is(":visible")&&this._focused_from&&t(this._focused_from).focus(),delete this._focused_from},_toggle_multidate:function(t){var e=this.dates.contains(t)
if(t||this.dates.clear(),e!==-1?(this.o.multidate===!0||this.o.multidate>1||this.o.toggleActive)&&this.dates.remove(e):this.o.multidate===!1?(this.dates.clear(),this.dates.push(t)):this.dates.push(t),"number"==typeof this.o.multidate)for(;this.dates.length>this.o.multidate;)this.dates.remove(0)},_setDate:function(t,e){e&&"date"!==e||this._toggle_multidate(t&&new Date(t)),e&&"view"!==e||(this.viewDate=t&&new Date(t)),this.fill(),this.setValue(),e&&"view"===e||this._trigger("changeDate"),this.inputField&&this.inputField.change(),!this.o.autoclose||e&&"date"!==e||this.hide()},moveDay:function(t,e){var i=new Date(t)
return i.setUTCDate(t.getUTCDate()+e),i},moveWeek:function(t,e){return this.moveDay(t,7*e)},moveMonth:function(t,e){if(!o(t))return this.o.defaultViewDate
if(!e)return t
var i,n,s=new Date(t.valueOf()),r=s.getUTCDate(),a=s.getUTCMonth(),l=Math.abs(e)
if(e=e>0?1:-1,1===l)n=e===-1?function(){return s.getUTCMonth()===a}:function(){return s.getUTCMonth()!==i},i=a+e,s.setUTCMonth(i),(i<0||i>11)&&(i=(i+12)%12)
else{for(var u=0;u<l;u++)s=this.moveMonth(s,e)
i=s.getUTCMonth(),s.setUTCDate(r),n=function(){return i!==s.getUTCMonth()}}for(;n();)s.setUTCDate(--r),s.setUTCMonth(i)
return s},moveYear:function(t,e){return this.moveMonth(t,12*e)},moveAvailableDate:function(t,e,i){do{if(t=this[i](t,e),!this.dateWithinRange(t))return!1
i="moveDay"}while(this.dateIsDisabled(t))
return t},weekOfDateIsDisabled:function(e){return t.inArray(e.getUTCDay(),this.o.daysOfWeekDisabled)!==-1},dateIsDisabled:function(e){return this.weekOfDateIsDisabled(e)||t.grep(this.o.datesDisabled,function(t){return s(e,t)}).length>0},dateWithinRange:function(t){return t>=this.o.startDate&&t<=this.o.endDate},keydown:function(t){if(!this.picker.is(":visible"))return void(40!==t.keyCode&&27!==t.keyCode||(this.show(),t.stopPropagation()))
var e,i,n=!1,s=this.focusDate||this.viewDate
switch(t.keyCode){case 27:this.focusDate?(this.focusDate=null,this.viewDate=this.dates.get(-1)||this.viewDate,this.fill()):this.hide(),t.preventDefault(),t.stopPropagation()
break
case 37:case 38:case 39:case 40:if(!this.o.keyboardNavigation||7===this.o.daysOfWeekDisabled.length)break
e=37===t.keyCode||38===t.keyCode?-1:1,0===this.viewMode?t.ctrlKey?(i=this.moveAvailableDate(s,e,"moveYear"),i&&this._trigger("changeYear",this.viewDate)):t.shiftKey?(i=this.moveAvailableDate(s,e,"moveMonth"),i&&this._trigger("changeMonth",this.viewDate)):37===t.keyCode||39===t.keyCode?i=this.moveAvailableDate(s,e,"moveDay"):this.weekOfDateIsDisabled(s)||(i=this.moveAvailableDate(s,e,"moveWeek")):1===this.viewMode?(38!==t.keyCode&&40!==t.keyCode||(e*=4),i=this.moveAvailableDate(s,e,"moveMonth")):2===this.viewMode&&(38!==t.keyCode&&40!==t.keyCode||(e*=4),i=this.moveAvailableDate(s,e,"moveYear")),i&&(this.focusDate=this.viewDate=i,this.setValue(),this.fill(),t.preventDefault())
break
case 13:if(!this.o.forceParse)break
s=this.focusDate||this.dates.get(-1)||this.viewDate,this.o.keyboardNavigation&&(this._toggle_multidate(s),n=!0),this.focusDate=null,this.viewDate=this.dates.get(-1)||this.viewDate,this.setValue(),this.fill(),this.picker.is(":visible")&&(t.preventDefault(),t.stopPropagation(),this.o.autoclose&&this.hide())
break
case 9:this.focusDate=null,this.viewDate=this.dates.get(-1)||this.viewDate,this.fill(),this.hide()}n&&(this.dates.length?this._trigger("changeDate"):this._trigger("clearDate"),this.inputField&&this.inputField.change())},showMode:function(t){t&&(this.viewMode=Math.max(this.o.minViewMode,Math.min(this.o.maxViewMode,this.viewMode+t))),this.picker.children("div").hide().filter(".datepicker-"+v.modes[this.viewMode].clsName).show(),this.updateNavArrows()}}
var c=function(e,i){t(e).data("datepicker",this),this.element=t(e),this.inputs=t.map(i.inputs,function(t){return t.jquery?t[0]:t}),delete i.inputs,f.call(t(this.inputs),i).on("changeDate",t.proxy(this.dateUpdated,this)),this.pickers=t.map(this.inputs,function(e){return t(e).data("datepicker")}),this.updateDates()}
c.prototype={updateDates:function(){this.dates=t.map(this.pickers,function(t){return t.getUTCDate()}),this.updateRanges()},updateRanges:function(){var e=t.map(this.dates,function(t){return t.valueOf()})
t.each(this.pickers,function(t,i){i.setRange(e)})},dateUpdated:function(e){if(!this.updating){this.updating=!0
var i=t(e.target).data("datepicker")
if("undefined"!=typeof i){var n=i.getUTCDate(),s=t.inArray(e.target,this.inputs),r=s-1,o=s+1,a=this.inputs.length
if(s!==-1){if(t.each(this.pickers,function(t,e){e.getUTCDate()||e.setUTCDate(n)}),n<this.dates[r])for(;r>=0&&n<this.dates[r];)this.pickers[r--].setUTCDate(n)
else if(n>this.dates[o])for(;o<a&&n>this.dates[o];)this.pickers[o++].setUTCDate(n)
this.updateDates(),delete this.updating}}}},remove:function(){t.map(this.pickers,function(t){t.remove()}),delete this.element.data().datepicker}}
var d=t.fn.datepicker,f=function(i){var n=Array.apply(null,arguments)
n.shift()
var s
if(this.each(function(){var e=t(this),r=e.data("datepicker"),o="object"==typeof i&&i
if(!r){var u=a(this,"date"),d=t.extend({},p,u,o),f=l(d.language),m=t.extend({},p,f,u,o)
e.hasClass("input-daterange")||m.inputs?(t.extend(m,{inputs:m.inputs||e.find("input").toArray()}),r=new c(this,m)):r=new h(this,m),e.data("datepicker",r)}"string"==typeof i&&"function"==typeof r[i]&&(s=r[i].apply(r,n))}),s===e||s instanceof h||s instanceof c)return this
if(this.length>1)throw new Error("Using only allowed for the collection of a single element ("+i+" function)")
return s}
t.fn.datepicker=f
var p=t.fn.datepicker.defaults={assumeNearbyYear:!1,autoclose:!1,beforeShowDay:t.noop,beforeShowMonth:t.noop,beforeShowYear:t.noop,beforeShowDecade:t.noop,beforeShowCentury:t.noop,calendarWeeks:!1,clearBtn:!1,toggleActive:!1,daysOfWeekDisabled:[],daysOfWeekHighlighted:[],datesDisabled:[],endDate:1/0,forceParse:!0,format:"mm/dd/yyyy",keyboardNavigation:!0,language:"en",minViewMode:0,maxViewMode:4,multidate:!1,multidateSeparator:",",orientation:"auto",rtl:!1,startDate:-(1/0),startView:0,todayBtn:!1,todayHighlight:!1,weekStart:0,disableTouchKeyboard:!1,enableOnReadonly:!0,showOnFocus:!0,zIndexOffset:10,container:"body",immediateUpdates:!1,title:"",templates:{leftArrow:"&laquo;",rightArrow:"&raquo;"}},m=t.fn.datepicker.locale_opts=["format","rtl","weekStart"]
t.fn.datepicker.Constructor=h
var g=t.fn.datepicker.dates={en:{days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],daysShort:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],daysMin:["Su","Mo","Tu","We","Th","Fr","Sa"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],monthsShort:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],today:"Today",clear:"Clear",titleFormat:"MM yyyy"}},v={modes:[{clsName:"days",navFnc:"Month",navStep:1},{clsName:"months",navFnc:"FullYear",navStep:1},{clsName:"years",navFnc:"FullYear",navStep:10},{clsName:"decades",navFnc:"FullDecade",navStep:100},{clsName:"centuries",navFnc:"FullCentury",navStep:1e3}],isLeapYear:function(t){return t%4===0&&t%100!==0||t%400===0},getDaysInMonth:function(t,e){return[31,v.isLeapYear(t)?29:28,31,30,31,30,31,31,30,31,30,31][e]},validParts:/dd?|DD?|mm?|MM?|yy(?:yy)?/g,nonpunctuation:/[^ -\/:-@\u5e74\u6708\u65e5\[-`{-~\t\n\r]+/g,parseFormat:function(t){if("function"==typeof t.toValue&&"function"==typeof t.toDisplay)return t
var e=t.replace(this.validParts,"\0").split("\0"),i=t.match(this.validParts)
if(!e||!e.length||!i||0===i.length)throw new Error("Invalid date format.")
return{separators:e,parts:i}},parseDate:function(s,r,o,a){function l(t,e){return e===!0&&(e=10),t<100&&(t+=2e3,t>(new Date).getFullYear()+e&&(t-=100)),t}function u(){var t=this.slice(0,y[f].length),e=y[f].slice(0,t.length)
return t.toLowerCase()===e.toLowerCase()}if(!s)return e
if(s instanceof Date)return s
if("string"==typeof r&&(r=v.parseFormat(r)),r.toValue)return r.toValue(s,r,o)
var c,d,f,p,m=/([\-+]\d+)([dmwy])/,y=s.match(/([\-+]\d+)([dmwy])/g),_={d:"moveDay",m:"moveMonth",w:"moveWeek",y:"moveYear"},b={yesterday:"-1d",today:"+0d",tomorrow:"+1d"}
if(/^[\-+]\d+[dmwy]([\s,]+[\-+]\d+[dmwy])*$/.test(s)){for(s=new Date,f=0;f<y.length;f++)c=m.exec(y[f]),d=parseInt(c[1]),p=_[c[2]],s=h.prototype[p](s,d)
return i(s.getUTCFullYear(),s.getUTCMonth(),s.getUTCDate())}if("undefined"!=typeof b[s]&&(s=b[s],y=s.match(/([\-+]\d+)([dmwy])/g),/^[\-+]\d+[dmwy]([\s,]+[\-+]\d+[dmwy])*$/.test(s))){for(s=new Date,f=0;f<y.length;f++)c=m.exec(y[f]),d=parseInt(c[1]),p=_[c[2]],s=h.prototype[p](s,d)
return i(s.getUTCFullYear(),s.getUTCMonth(),s.getUTCDate())}y=s&&s.match(this.nonpunctuation)||[],s=new Date
var w,x,k={},D=["yyyy","yy","M","MM","m","mm","d","dd"],T={yyyy:function(t,e){return t.setUTCFullYear(a?l(e,a):e)},yy:function(t,e){return t.setUTCFullYear(a?l(e,a):e)},m:function(t,e){if(isNaN(t))return t
for(e-=1;e<0;)e+=12
for(e%=12,t.setUTCMonth(e);t.getUTCMonth()!==e;)t.setUTCDate(t.getUTCDate()-1)
return t},d:function(t,e){return t.setUTCDate(e)}}
T.M=T.MM=T.mm=T.m,T.dd=T.d,s=n()
var C=r.parts.slice()
if(y.length!==C.length&&(C=t(C).filter(function(e,i){return t.inArray(i,D)!==-1}).toArray()),y.length===C.length){var S
for(f=0,S=C.length;f<S;f++){if(w=parseInt(y[f],10),c=C[f],isNaN(w))switch(c){case"MM":x=t(g[o].months).filter(u),w=t.inArray(x[0],g[o].months)+1
break
case"M":x=t(g[o].monthsShort).filter(u),w=t.inArray(x[0],g[o].monthsShort)+1}k[c]=w}var M,E
for(f=0;f<D.length;f++)E=D[f],E in k&&!isNaN(k[E])&&(M=new Date(s),T[E](M,k[E]),isNaN(M)||(s=M))}return s},formatDate:function(e,i,n){if(!e)return""
if("string"==typeof i&&(i=v.parseFormat(i)),i.toDisplay)return i.toDisplay(e,i,n)
var s={d:e.getUTCDate(),D:g[n].daysShort[e.getUTCDay()],DD:g[n].days[e.getUTCDay()],m:e.getUTCMonth()+1,M:g[n].monthsShort[e.getUTCMonth()],MM:g[n].months[e.getUTCMonth()],yy:e.getUTCFullYear().toString().substring(2),yyyy:e.getUTCFullYear()}
s.dd=(s.d<10?"0":"")+s.d,s.mm=(s.m<10?"0":"")+s.m,e=[]
for(var r=t.extend([],i.separators),o=0,a=i.parts.length;o<=a;o++)r.length&&e.push(r.shift()),e.push(s[i.parts[o]])
return e.join("")},headTemplate:'<thead><tr><th colspan="7" class="datepicker-title"></th></tr><tr><th class="prev">&laquo;</th><th colspan="5" class="datepicker-switch"></th><th class="next">&raquo;</th></tr></thead>',contTemplate:'<tbody><tr><td colspan="7"></td></tr></tbody>',footTemplate:'<tfoot><tr><th colspan="7" class="today"></th></tr><tr><th colspan="7" class="clear"></th></tr></tfoot>'}
v.template='<div class="datepicker"><div class="datepicker-days"><table class="table-condensed">'+v.headTemplate+"<tbody></tbody>"+v.footTemplate+'</table></div><div class="datepicker-months"><table class="table-condensed">'+v.headTemplate+v.contTemplate+v.footTemplate+'</table></div><div class="datepicker-years"><table class="table-condensed">'+v.headTemplate+v.contTemplate+v.footTemplate+'</table></div><div class="datepicker-decades"><table class="table-condensed">'+v.headTemplate+v.contTemplate+v.footTemplate+'</table></div><div class="datepicker-centuries"><table class="table-condensed">'+v.headTemplate+v.contTemplate+v.footTemplate+"</table></div></div>",t.fn.datepicker.DPGlobal=v,t.fn.datepicker.noConflict=function(){return t.fn.datepicker=d,this},t.fn.datepicker.version="1.6.4",t(document).on("focus.datepicker.data-api click.datepicker.data-api",'[data-provide="datepicker"]',function(e){var i=t(this)
i.data("datepicker")||(e.preventDefault(),f.call(i,"show"))}),t(function(){f.call(t('[data-provide="datepicker-inline"]'))})}),function(){"use strict"
if(navigator.userAgent.match(/IEMobile\/10\.0/)){var t=document.createElement("style")
t.appendChild(document.createTextNode("@-ms-viewport{width:auto!important}")),document.querySelector("head").appendChild(t)}}(),function(){function t(t){function e(e,i,n,s,r,o){for(;r>=0&&o>r;r+=t){var a=s?s[r]:r
n=i(n,e[a],a,e)}return n}return function(i,n,s,r){n=_(n,r,4)
var o=!C(i)&&y.keys(i),a=(o||i).length,l=t>0?0:a-1
return arguments.length<3&&(s=i[o?o[l]:l],l+=t),e(i,n,s,o,l,a)}}function e(t){return function(e,i,n){i=b(i,n)
for(var s=T(e),r=t>0?0:s-1;r>=0&&s>r;r+=t)if(i(e[r],r,e))return r
return-1}}function i(t,e,i){return function(n,s,r){var o=0,a=T(n)
if("number"==typeof r)t>0?o=r>=0?r:Math.max(r+a,o):a=r>=0?Math.min(r+1,a):r+a+1
else if(i&&r&&a)return r=i(n,s),n[r]===s?r:-1
if(s!==s)return r=e(h.call(n,o,a),y.isNaN),r>=0?r+o:-1
for(r=t>0?o:a-1;r>=0&&a>r;r+=t)if(n[r]===s)return r
return-1}}function n(t,e){var i=A.length,n=t.constructor,s=y.isFunction(n)&&n.prototype||a,r="constructor"
for(y.has(t,r)&&!y.contains(e,r)&&e.push(r);i--;)r=A[i],r in t&&t[r]!==s[r]&&!y.contains(e,r)&&e.push(r)}var s=this,r=s._,o=Array.prototype,a=Object.prototype,l=Function.prototype,u=o.push,h=o.slice,c=a.toString,d=a.hasOwnProperty,f=Array.isArray,p=Object.keys,m=l.bind,g=Object.create,v=function(){},y=function(t){return t instanceof y?t:this instanceof y?void(this._wrapped=t):new y(t)}
"undefined"!=typeof exports?("undefined"!=typeof module&&module.exports&&(exports=module.exports=y),exports._=y):s._=y,y.VERSION="1.8.3"
var _=function(t,e,i){if(void 0===e)return t
switch(null==i?3:i){case 1:return function(i){return t.call(e,i)}
case 2:return function(i,n){return t.call(e,i,n)}
case 3:return function(i,n,s){return t.call(e,i,n,s)}
case 4:return function(i,n,s,r){return t.call(e,i,n,s,r)}}return function(){return t.apply(e,arguments)}},b=function(t,e,i){return null==t?y.identity:y.isFunction(t)?_(t,e,i):y.isObject(t)?y.matcher(t):y.property(t)}
y.iteratee=function(t,e){return b(t,e,1/0)}
var w=function(t,e){return function(i){var n=arguments.length
if(2>n||null==i)return i
for(var s=1;n>s;s++)for(var r=arguments[s],o=t(r),a=o.length,l=0;a>l;l++){var u=o[l]
e&&void 0!==i[u]||(i[u]=r[u])}return i}},x=function(t){if(!y.isObject(t))return{}
if(g)return g(t)
v.prototype=t
var e=new v
return v.prototype=null,e},k=function(t){return function(e){return null==e?void 0:e[t]}},D=Math.pow(2,53)-1,T=k("length"),C=function(t){var e=T(t)
return"number"==typeof e&&e>=0&&D>=e}
y.each=y.forEach=function(t,e,i){e=_(e,i)
var n,s
if(C(t))for(n=0,s=t.length;s>n;n++)e(t[n],n,t)
else{var r=y.keys(t)
for(n=0,s=r.length;s>n;n++)e(t[r[n]],r[n],t)}return t},y.map=y.collect=function(t,e,i){e=b(e,i)
for(var n=!C(t)&&y.keys(t),s=(n||t).length,r=Array(s),o=0;s>o;o++){var a=n?n[o]:o
r[o]=e(t[a],a,t)}return r},y.reduce=y.foldl=y.inject=t(1),y.reduceRight=y.foldr=t(-1),y.find=y.detect=function(t,e,i){var n
return n=C(t)?y.findIndex(t,e,i):y.findKey(t,e,i),void 0!==n&&n!==-1?t[n]:void 0},y.filter=y.select=function(t,e,i){var n=[]
return e=b(e,i),y.each(t,function(t,i,s){e(t,i,s)&&n.push(t)}),n},y.reject=function(t,e,i){return y.filter(t,y.negate(b(e)),i)},y.every=y.all=function(t,e,i){e=b(e,i)
for(var n=!C(t)&&y.keys(t),s=(n||t).length,r=0;s>r;r++){var o=n?n[r]:r
if(!e(t[o],o,t))return!1}return!0},y.some=y.any=function(t,e,i){e=b(e,i)
for(var n=!C(t)&&y.keys(t),s=(n||t).length,r=0;s>r;r++){var o=n?n[r]:r
if(e(t[o],o,t))return!0}return!1},y.contains=y.includes=y.include=function(t,e,i,n){return C(t)||(t=y.values(t)),("number"!=typeof i||n)&&(i=0),y.indexOf(t,e,i)>=0},y.invoke=function(t,e){var i=h.call(arguments,2),n=y.isFunction(e)
return y.map(t,function(t){var s=n?e:t[e]
return null==s?s:s.apply(t,i)})},y.pluck=function(t,e){return y.map(t,y.property(e))},y.where=function(t,e){return y.filter(t,y.matcher(e))},y.findWhere=function(t,e){return y.find(t,y.matcher(e))},y.max=function(t,e,i){var n,s,r=-1/0,o=-1/0
if(null==e&&null!=t){t=C(t)?t:y.values(t)
for(var a=0,l=t.length;l>a;a++)n=t[a],n>r&&(r=n)}else e=b(e,i),y.each(t,function(t,i,n){s=e(t,i,n),(s>o||s===-1/0&&r===-1/0)&&(r=t,o=s)})
return r},y.min=function(t,e,i){var n,s,r=1/0,o=1/0
if(null==e&&null!=t){t=C(t)?t:y.values(t)
for(var a=0,l=t.length;l>a;a++)n=t[a],r>n&&(r=n)}else e=b(e,i),y.each(t,function(t,i,n){s=e(t,i,n),(o>s||1/0===s&&1/0===r)&&(r=t,o=s)})
return r},y.shuffle=function(t){for(var e,i=C(t)?t:y.values(t),n=i.length,s=Array(n),r=0;n>r;r++)e=y.random(0,r),e!==r&&(s[r]=s[e]),s[e]=i[r]
return s},y.sample=function(t,e,i){return null==e||i?(C(t)||(t=y.values(t)),t[y.random(t.length-1)]):y.shuffle(t).slice(0,Math.max(0,e))},y.sortBy=function(t,e,i){return e=b(e,i),y.pluck(y.map(t,function(t,i,n){return{value:t,index:i,criteria:e(t,i,n)}}).sort(function(t,e){var i=t.criteria,n=e.criteria
if(i!==n){if(i>n||void 0===i)return 1
if(n>i||void 0===n)return-1}return t.index-e.index}),"value")}
var S=function(t){return function(e,i,n){var s={}
return i=b(i,n),y.each(e,function(n,r){var o=i(n,r,e)
t(s,n,o)}),s}}
y.groupBy=S(function(t,e,i){y.has(t,i)?t[i].push(e):t[i]=[e]}),y.indexBy=S(function(t,e,i){t[i]=e}),y.countBy=S(function(t,e,i){y.has(t,i)?t[i]++:t[i]=1}),y.toArray=function(t){return t?y.isArray(t)?h.call(t):C(t)?y.map(t,y.identity):y.values(t):[]},y.size=function(t){return null==t?0:C(t)?t.length:y.keys(t).length},y.partition=function(t,e,i){e=b(e,i)
var n=[],s=[]
return y.each(t,function(t,i,r){(e(t,i,r)?n:s).push(t)}),[n,s]},y.first=y.head=y.take=function(t,e,i){return null==t?void 0:null==e||i?t[0]:y.initial(t,t.length-e)},y.initial=function(t,e,i){return h.call(t,0,Math.max(0,t.length-(null==e||i?1:e)))},y.last=function(t,e,i){return null==t?void 0:null==e||i?t[t.length-1]:y.rest(t,Math.max(0,t.length-e))},y.rest=y.tail=y.drop=function(t,e,i){return h.call(t,null==e||i?1:e)},y.compact=function(t){return y.filter(t,y.identity)}
var M=function(t,e,i,n){for(var s=[],r=0,o=n||0,a=T(t);a>o;o++){var l=t[o]
if(C(l)&&(y.isArray(l)||y.isArguments(l))){e||(l=M(l,e,i))
var u=0,h=l.length
for(s.length+=h;h>u;)s[r++]=l[u++]}else i||(s[r++]=l)}return s}
y.flatten=function(t,e){return M(t,e,!1)},y.without=function(t){return y.difference(t,h.call(arguments,1))},y.uniq=y.unique=function(t,e,i,n){y.isBoolean(e)||(n=i,i=e,e=!1),null!=i&&(i=b(i,n))
for(var s=[],r=[],o=0,a=T(t);a>o;o++){var l=t[o],u=i?i(l,o,t):l
e?(o&&r===u||s.push(l),r=u):i?y.contains(r,u)||(r.push(u),s.push(l)):y.contains(s,l)||s.push(l)}return s},y.union=function(){return y.uniq(M(arguments,!0,!0))},y.intersection=function(t){for(var e=[],i=arguments.length,n=0,s=T(t);s>n;n++){var r=t[n]
if(!y.contains(e,r)){for(var o=1;i>o&&y.contains(arguments[o],r);o++);o===i&&e.push(r)}}return e},y.difference=function(t){var e=M(arguments,!0,!0,1)
return y.filter(t,function(t){return!y.contains(e,t)})},y.zip=function(){return y.unzip(arguments)},y.unzip=function(t){for(var e=t&&y.max(t,T).length||0,i=Array(e),n=0;e>n;n++)i[n]=y.pluck(t,n)
return i},y.object=function(t,e){for(var i={},n=0,s=T(t);s>n;n++)e?i[t[n]]=e[n]:i[t[n][0]]=t[n][1]
return i},y.findIndex=e(1),y.findLastIndex=e(-1),y.sortedIndex=function(t,e,i,n){i=b(i,n,1)
for(var s=i(e),r=0,o=T(t);o>r;){var a=Math.floor((r+o)/2)
i(t[a])<s?r=a+1:o=a}return r},y.indexOf=i(1,y.findIndex,y.sortedIndex),y.lastIndexOf=i(-1,y.findLastIndex),y.range=function(t,e,i){null==e&&(e=t||0,t=0),i=i||1
for(var n=Math.max(Math.ceil((e-t)/i),0),s=Array(n),r=0;n>r;r++,t+=i)s[r]=t
return s}
var E=function(t,e,i,n,s){if(!(n instanceof e))return t.apply(i,s)
var r=x(t.prototype),o=t.apply(r,s)
return y.isObject(o)?o:r}
y.bind=function(t,e){if(m&&t.bind===m)return m.apply(t,h.call(arguments,1))
if(!y.isFunction(t))throw new TypeError("Bind must be called on a function")
var i=h.call(arguments,2),n=function(){return E(t,n,e,this,i.concat(h.call(arguments)))}
return n},y.partial=function(t){var e=h.call(arguments,1),i=function(){for(var n=0,s=e.length,r=Array(s),o=0;s>o;o++)r[o]=e[o]===y?arguments[n++]:e[o]
for(;n<arguments.length;)r.push(arguments[n++])
return E(t,i,this,this,r)}
return i},y.bindAll=function(t){var e,i,n=arguments.length
if(1>=n)throw new Error("bindAll must be passed function names")
for(e=1;n>e;e++)i=arguments[e],t[i]=y.bind(t[i],t)
return t},y.memoize=function(t,e){var i=function(n){var s=i.cache,r=""+(e?e.apply(this,arguments):n)
return y.has(s,r)||(s[r]=t.apply(this,arguments)),s[r]}
return i.cache={},i},y.delay=function(t,e){var i=h.call(arguments,2)
return setTimeout(function(){return t.apply(null,i)},e)},y.defer=y.partial(y.delay,y,1),y.throttle=function(t,e,i){var n,s,r,o=null,a=0
i||(i={})
var l=function(){a=i.leading===!1?0:y.now(),o=null,r=t.apply(n,s),o||(n=s=null)}
return function(){var u=y.now()
a||i.leading!==!1||(a=u)
var h=e-(u-a)
return n=this,s=arguments,0>=h||h>e?(o&&(clearTimeout(o),o=null),a=u,r=t.apply(n,s),o||(n=s=null)):o||i.trailing===!1||(o=setTimeout(l,h)),r}},y.debounce=function(t,e,i){var n,s,r,o,a,l=function(){var u=y.now()-o
e>u&&u>=0?n=setTimeout(l,e-u):(n=null,i||(a=t.apply(r,s),n||(r=s=null)))}
return function(){r=this,s=arguments,o=y.now()
var u=i&&!n
return n||(n=setTimeout(l,e)),u&&(a=t.apply(r,s),r=s=null),a}},y.wrap=function(t,e){return y.partial(e,t)},y.negate=function(t){return function(){return!t.apply(this,arguments)}},y.compose=function(){var t=arguments,e=t.length-1
return function(){for(var i=e,n=t[e].apply(this,arguments);i--;)n=t[i].call(this,n)
return n}},y.after=function(t,e){return function(){return--t<1?e.apply(this,arguments):void 0}},y.before=function(t,e){var i
return function(){return--t>0&&(i=e.apply(this,arguments)),1>=t&&(e=null),i}},y.once=y.partial(y.before,2)
var N=!{toString:null}.propertyIsEnumerable("toString"),A=["valueOf","isPrototypeOf","toString","propertyIsEnumerable","hasOwnProperty","toLocaleString"]
y.keys=function(t){if(!y.isObject(t))return[]
if(p)return p(t)
var e=[]
for(var i in t)y.has(t,i)&&e.push(i)
return N&&n(t,e),e},y.allKeys=function(t){if(!y.isObject(t))return[]
var e=[]
for(var i in t)e.push(i)
return N&&n(t,e),e},y.values=function(t){for(var e=y.keys(t),i=e.length,n=Array(i),s=0;i>s;s++)n[s]=t[e[s]]
return n},y.mapObject=function(t,e,i){e=b(e,i)
for(var n,s=y.keys(t),r=s.length,o={},a=0;r>a;a++)n=s[a],o[n]=e(t[n],n,t)
return o},y.pairs=function(t){for(var e=y.keys(t),i=e.length,n=Array(i),s=0;i>s;s++)n[s]=[e[s],t[e[s]]]
return n},y.invert=function(t){for(var e={},i=y.keys(t),n=0,s=i.length;s>n;n++)e[t[i[n]]]=i[n]
return e},y.functions=y.methods=function(t){var e=[]
for(var i in t)y.isFunction(t[i])&&e.push(i)
return e.sort()},y.extend=w(y.allKeys),y.extendOwn=y.assign=w(y.keys),y.findKey=function(t,e,i){e=b(e,i)
for(var n,s=y.keys(t),r=0,o=s.length;o>r;r++)if(n=s[r],e(t[n],n,t))return n},y.pick=function(t,e,i){var n,s,r={},o=t
if(null==o)return r
y.isFunction(e)?(s=y.allKeys(o),n=_(e,i)):(s=M(arguments,!1,!1,1),n=function(t,e,i){return e in i},o=Object(o))
for(var a=0,l=s.length;l>a;a++){var u=s[a],h=o[u]
n(h,u,o)&&(r[u]=h)}return r},y.omit=function(t,e,i){if(y.isFunction(e))e=y.negate(e)
else{var n=y.map(M(arguments,!1,!1,1),String)
e=function(t,e){return!y.contains(n,e)}}return y.pick(t,e,i)},y.defaults=w(y.allKeys,!0),y.create=function(t,e){var i=x(t)
return e&&y.extendOwn(i,e),i},y.clone=function(t){return y.isObject(t)?y.isArray(t)?t.slice():y.extend({},t):t},y.tap=function(t,e){return e(t),t},y.isMatch=function(t,e){var i=y.keys(e),n=i.length
if(null==t)return!n
for(var s=Object(t),r=0;n>r;r++){var o=i[r]
if(e[o]!==s[o]||!(o in s))return!1}return!0}
var O=function(t,e,i,n){if(t===e)return 0!==t||1/t===1/e
if(null==t||null==e)return t===e
t instanceof y&&(t=t._wrapped),e instanceof y&&(e=e._wrapped)
var s=c.call(t)
if(s!==c.call(e))return!1
switch(s){case"[object RegExp]":case"[object String]":return""+t==""+e
case"[object Number]":return+t!==+t?+e!==+e:0===+t?1/+t===1/e:+t===+e
case"[object Date]":case"[object Boolean]":return+t===+e}var r="[object Array]"===s
if(!r){if("object"!=typeof t||"object"!=typeof e)return!1
var o=t.constructor,a=e.constructor
if(o!==a&&!(y.isFunction(o)&&o instanceof o&&y.isFunction(a)&&a instanceof a)&&"constructor"in t&&"constructor"in e)return!1}i=i||[],n=n||[]
for(var l=i.length;l--;)if(i[l]===t)return n[l]===e
if(i.push(t),n.push(e),r){if(l=t.length,l!==e.length)return!1
for(;l--;)if(!O(t[l],e[l],i,n))return!1}else{var u,h=y.keys(t)
if(l=h.length,y.keys(e).length!==l)return!1
for(;l--;)if(u=h[l],!y.has(e,u)||!O(t[u],e[u],i,n))return!1}return i.pop(),n.pop(),!0}
y.isEqual=function(t,e){return O(t,e)},y.isEmpty=function(t){return null==t||(C(t)&&(y.isArray(t)||y.isString(t)||y.isArguments(t))?0===t.length:0===y.keys(t).length)},y.isElement=function(t){return!(!t||1!==t.nodeType)},y.isArray=f||function(t){return"[object Array]"===c.call(t)},y.isObject=function(t){var e=typeof t
return"function"===e||"object"===e&&!!t},y.each(["Arguments","Function","String","Number","Date","RegExp","Error"],function(t){y["is"+t]=function(e){return c.call(e)==="[object "+t+"]"}}),y.isArguments(arguments)||(y.isArguments=function(t){return y.has(t,"callee")}),"function"!=typeof/./&&"object"!=typeof Int8Array&&(y.isFunction=function(t){return"function"==typeof t||!1}),y.isFinite=function(t){return isFinite(t)&&!isNaN(parseFloat(t))},y.isNaN=function(t){return y.isNumber(t)&&t!==+t},y.isBoolean=function(t){return t===!0||t===!1||"[object Boolean]"===c.call(t)},y.isNull=function(t){return null===t},y.isUndefined=function(t){return void 0===t},y.has=function(t,e){return null!=t&&d.call(t,e)},y.noConflict=function(){return s._=r,this},y.identity=function(t){return t},y.constant=function(t){return function(){return t}},y.noop=function(){},y.property=k,y.propertyOf=function(t){return null==t?function(){}:function(e){return t[e]}},y.matcher=y.matches=function(t){return t=y.extendOwn({},t),function(e){return y.isMatch(e,t)}},y.times=function(t,e,i){var n=Array(Math.max(0,t))
e=_(e,i,1)
for(var s=0;t>s;s++)n[s]=e(s)
return n},y.random=function(t,e){return null==e&&(e=t,t=0),t+Math.floor(Math.random()*(e-t+1))},y.now=Date.now||function(){return(new Date).getTime()}
var P={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;"},I=y.invert(P),L=function(t){var e=function(e){return t[e]},i="(?:"+y.keys(t).join("|")+")",n=RegExp(i),s=RegExp(i,"g")
return function(t){return t=null==t?"":""+t,n.test(t)?t.replace(s,e):t}}
y.escape=L(P),y.unescape=L(I),y.result=function(t,e,i){var n=null==t?void 0:t[e]
return void 0===n&&(n=i),y.isFunction(n)?n.call(t):n}
var H=0
y.uniqueId=function(t){var e=++H+""
return t?t+e:e},y.templateSettings={evaluate:/<%([\s\S]+?)%>/g,interpolate:/<%=([\s\S]+?)%>/g,escape:/<%-([\s\S]+?)%>/g}
var j=/(.)^/,W={"'":"'","\\":"\\","\r":"r","\n":"n","\u2028":"u2028","\u2029":"u2029"},F=/\\|'|\r|\n|\u2028|\u2029/g,$=function(t){return"\\"+W[t]}
y.template=function(t,e,i){!e&&i&&(e=i),e=y.defaults({},e,y.templateSettings)
var n=RegExp([(e.escape||j).source,(e.interpolate||j).source,(e.evaluate||j).source].join("|")+"|$","g"),s=0,r="__p+='"
t.replace(n,function(e,i,n,o,a){return r+=t.slice(s,a).replace(F,$),s=a+e.length,i?r+="'+\n((__t=("+i+"))==null?'':_.escape(__t))+\n'":n?r+="'+\n((__t=("+n+"))==null?'':__t)+\n'":o&&(r+="';\n"+o+"\n__p+='"),e}),r+="';\n",e.variable||(r="with(obj||{}){\n"+r+"}\n"),r="var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n"+r+"return __p;\n"
try{var o=new Function(e.variable||"obj","_",r)}catch(t){throw t.source=r,t}var a=function(t){return o.call(this,t,y)},l=e.variable||"obj"
return a.source="function("+l+"){\n"+r+"}",a},y.chain=function(t){var e=y(t)
return e._chain=!0,e}
var U=function(t,e){return t._chain?y(e).chain():e}
y.mixin=function(t){y.each(y.functions(t),function(e){var i=y[e]=t[e]
y.prototype[e]=function(){var t=[this._wrapped]
return u.apply(t,arguments),U(this,i.apply(y,t))}})},y.mixin(y),y.each(["pop","push","reverse","shift","sort","splice","unshift"],function(t){var e=o[t]
y.prototype[t]=function(){var i=this._wrapped
return e.apply(i,arguments),"shift"!==t&&"splice"!==t||0!==i.length||delete i[0],U(this,i)}}),y.each(["concat","join","slice"],function(t){var e=o[t]
y.prototype[t]=function(){return U(this,e.apply(this._wrapped,arguments))}}),y.prototype.value=function(){return this._wrapped},y.prototype.valueOf=y.prototype.toJSON=y.prototype.value,y.prototype.toString=function(){return""+this._wrapped},"function"==typeof define&&define.amd&&define("underscore",[],function(){return y})}.call(this),function(t){var e="object"==typeof self&&self.self===self&&self||"object"==typeof global&&global.global===global&&global
if("function"==typeof define&&define.amd)define(["underscore","jquery","exports"],function(i,n,s){e.Backbone=t(e,s,i,n)})
else if("undefined"!=typeof exports){var i,n=require("underscore")
try{i=require("jquery")}catch(t){}t(e,exports,n,i)}else e.Backbone=t(e,{},e._,e.jQuery||e.Zepto||e.ender||e.$)}(function(t,e,i,n){var s=t.Backbone,r=Array.prototype.slice
e.VERSION="1.3.3",e.$=n,e.noConflict=function(){return t.Backbone=s,this},e.emulateHTTP=!1,e.emulateJSON=!1
var o=function(t,e,n){switch(t){case 1:return function(){return i[e](this[n])}
case 2:return function(t){return i[e](this[n],t)}
case 3:return function(t,s){return i[e](this[n],l(t,this),s)}
case 4:return function(t,s,r){return i[e](this[n],l(t,this),s,r)}
default:return function(){var t=r.call(arguments)
return t.unshift(this[n]),i[e].apply(i,t)}}},a=function(t,e,n){i.each(e,function(e,s){i[s]&&(t.prototype[s]=o(e,s,n))})},l=function(t,e){return i.isFunction(t)?t:i.isObject(t)&&!e._isModel(t)?u(t):i.isString(t)?function(e){return e.get(t)}:t},u=function(t){var e=i.matches(t)
return function(t){return e(t.attributes)}},h=e.Events={},c=/\s+/,d=function(t,e,n,s,r){var o,a=0
if(n&&"object"==typeof n){void 0!==s&&"context"in r&&void 0===r.context&&(r.context=s)
for(o=i.keys(n);a<o.length;a++)e=d(t,e,o[a],n[o[a]],r)}else if(n&&c.test(n))for(o=n.split(c);a<o.length;a++)e=t(e,o[a],s,r)
else e=t(e,n,s,r)
return e}
h.on=function(t,e,i){return f(this,t,e,i)}
var f=function(t,e,i,n,s){if(t._events=d(p,t._events||{},e,i,{context:n,ctx:t,listening:s}),s){var r=t._listeners||(t._listeners={})
r[s.id]=s}return t}
h.listenTo=function(t,e,n){if(!t)return this
var s=t._listenId||(t._listenId=i.uniqueId("l")),r=this._listeningTo||(this._listeningTo={}),o=r[s]
if(!o){var a=this._listenId||(this._listenId=i.uniqueId("l"))
o=r[s]={obj:t,objId:s,id:a,listeningTo:r,count:0}}return f(t,e,n,this,o),this}
var p=function(t,e,i,n){if(i){var s=t[e]||(t[e]=[]),r=n.context,o=n.ctx,a=n.listening
a&&a.count++,s.push({callback:i,context:r,ctx:r||o,listening:a})}return t}
h.off=function(t,e,i){return this._events?(this._events=d(m,this._events,t,e,{context:i,listeners:this._listeners}),this):this},h.stopListening=function(t,e,n){var s=this._listeningTo
if(!s)return this
for(var r=t?[t._listenId]:i.keys(s),o=0;o<r.length;o++){var a=s[r[o]]
if(!a)break
a.obj.off(e,n,this)}return this}
var m=function(t,e,n,s){if(t){var r,o=0,a=s.context,l=s.listeners
if(e||n||a){for(var u=e?[e]:i.keys(t);o<u.length;o++){e=u[o]
var h=t[e]
if(!h)break
for(var c=[],d=0;d<h.length;d++){var f=h[d]
n&&n!==f.callback&&n!==f.callback._callback||a&&a!==f.context?c.push(f):(r=f.listening,r&&0===--r.count&&(delete l[r.id],delete r.listeningTo[r.objId]))}c.length?t[e]=c:delete t[e]}return t}for(var p=i.keys(l);o<p.length;o++)r=l[p[o]],delete l[r.id],delete r.listeningTo[r.objId]}}
h.once=function(t,e,n){var s=d(g,{},t,e,i.bind(this.off,this))
return"string"==typeof t&&null==n&&(e=void 0),this.on(s,e,n)},h.listenToOnce=function(t,e,n){var s=d(g,{},e,n,i.bind(this.stopListening,this,t))
return this.listenTo(t,s)}
var g=function(t,e,n,s){if(n){var r=t[e]=i.once(function(){s(e,r),n.apply(this,arguments)})
r._callback=n}return t}
h.trigger=function(t){if(!this._events)return this
for(var e=Math.max(0,arguments.length-1),i=Array(e),n=0;n<e;n++)i[n]=arguments[n+1]
return d(v,this._events,t,void 0,i),this}
var v=function(t,e,i,n){if(t){var s=t[e],r=t.all
s&&r&&(r=r.slice()),s&&y(s,n),r&&y(r,[e].concat(n))}return t},y=function(t,e){var i,n=-1,s=t.length,r=e[0],o=e[1],a=e[2]
switch(e.length){case 0:for(;++n<s;)(i=t[n]).callback.call(i.ctx)
return
case 1:for(;++n<s;)(i=t[n]).callback.call(i.ctx,r)
return
case 2:for(;++n<s;)(i=t[n]).callback.call(i.ctx,r,o)
return
case 3:for(;++n<s;)(i=t[n]).callback.call(i.ctx,r,o,a)
return
default:for(;++n<s;)(i=t[n]).callback.apply(i.ctx,e)
return}}
h.bind=h.on,h.unbind=h.off,i.extend(e,h)
var _=e.Model=function(t,e){var n=t||{}
e||(e={}),this.cid=i.uniqueId(this.cidPrefix),this.attributes={},e.collection&&(this.collection=e.collection),e.parse&&(n=this.parse(n,e)||{})
var s=i.result(this,"defaults")
n=i.defaults(i.extend({},s,n),s),this.set(n,e),this.changed={},this.initialize.apply(this,arguments)}
i.extend(_.prototype,h,{changed:null,validationError:null,idAttribute:"id",cidPrefix:"c",initialize:function(){},toJSON:function(t){return i.clone(this.attributes)},sync:function(){return e.sync.apply(this,arguments)},get:function(t){return this.attributes[t]},escape:function(t){return i.escape(this.get(t))},has:function(t){return null!=this.get(t)},matches:function(t){return!!i.iteratee(t,this)(this.attributes)},set:function(t,e,n){if(null==t)return this
var s
if("object"==typeof t?(s=t,n=e):(s={})[t]=e,n||(n={}),!this._validate(s,n))return!1
var r=n.unset,o=n.silent,a=[],l=this._changing
this._changing=!0,l||(this._previousAttributes=i.clone(this.attributes),this.changed={})
var u=this.attributes,h=this.changed,c=this._previousAttributes
for(var d in s)e=s[d],i.isEqual(u[d],e)||a.push(d),i.isEqual(c[d],e)?delete h[d]:h[d]=e,r?delete u[d]:u[d]=e
if(this.idAttribute in s&&(this.id=this.get(this.idAttribute)),!o){a.length&&(this._pending=n)
for(var f=0;f<a.length;f++)this.trigger("change:"+a[f],this,u[a[f]],n)}if(l)return this
if(!o)for(;this._pending;)n=this._pending,this._pending=!1,this.trigger("change",this,n)
return this._pending=!1,this._changing=!1,this},unset:function(t,e){return this.set(t,void 0,i.extend({},e,{unset:!0}))},clear:function(t){var e={}
for(var n in this.attributes)e[n]=void 0
return this.set(e,i.extend({},t,{unset:!0}))},hasChanged:function(t){return null==t?!i.isEmpty(this.changed):i.has(this.changed,t)},changedAttributes:function(t){if(!t)return!!this.hasChanged()&&i.clone(this.changed)
var e=this._changing?this._previousAttributes:this.attributes,n={}
for(var s in t){var r=t[s]
i.isEqual(e[s],r)||(n[s]=r)}return!!i.size(n)&&n},previous:function(t){return null!=t&&this._previousAttributes?this._previousAttributes[t]:null},previousAttributes:function(){return i.clone(this._previousAttributes)},fetch:function(t){t=i.extend({parse:!0},t)
var e=this,n=t.success
return t.success=function(i){var s=t.parse?e.parse(i,t):i
return!!e.set(s,t)&&(n&&n.call(t.context,e,i,t),void e.trigger("sync",e,i,t))},U(this,t),this.sync("read",this,t)},save:function(t,e,n){var s
null==t||"object"==typeof t?(s=t,n=e):(s={})[t]=e,n=i.extend({validate:!0,parse:!0},n)
var r=n.wait
if(s&&!r){if(!this.set(s,n))return!1}else if(!this._validate(s,n))return!1
var o=this,a=n.success,l=this.attributes
n.success=function(t){o.attributes=l
var e=n.parse?o.parse(t,n):t
return r&&(e=i.extend({},s,e)),!(e&&!o.set(e,n))&&(a&&a.call(n.context,o,t,n),void o.trigger("sync",o,t,n))},U(this,n),s&&r&&(this.attributes=i.extend({},l,s))
var u=this.isNew()?"create":n.patch?"patch":"update"
"patch"!==u||n.attrs||(n.attrs=s)
var h=this.sync(u,this,n)
return this.attributes=l,h},destroy:function(t){t=t?i.clone(t):{}
var e=this,n=t.success,s=t.wait,r=function(){e.stopListening(),e.trigger("destroy",e,e.collection,t)}
t.success=function(i){s&&r(),n&&n.call(t.context,e,i,t),e.isNew()||e.trigger("sync",e,i,t)}
var o=!1
return this.isNew()?i.defer(t.success):(U(this,t),o=this.sync("delete",this,t)),s||r(),o},url:function(){var t=i.result(this,"urlRoot")||i.result(this.collection,"url")||$()
if(this.isNew())return t
var e=this.get(this.idAttribute)
return t.replace(/[^\/]$/,"$&/")+encodeURIComponent(e)},parse:function(t,e){return t},clone:function(){return new this.constructor(this.attributes)},isNew:function(){return!this.has(this.idAttribute)},isValid:function(t){return this._validate({},i.extend({},t,{validate:!0}))},_validate:function(t,e){if(!e.validate||!this.validate)return!0
t=i.extend({},this.attributes,t)
var n=this.validationError=this.validate(t,e)||null
return!n||(this.trigger("invalid",this,n,i.extend(e,{validationError:n})),!1)}})
var b={keys:1,values:1,pairs:1,invert:1,pick:0,omit:0,chain:1,isEmpty:1}
a(_,b,"attributes")
var w=e.Collection=function(t,e){e||(e={}),e.model&&(this.model=e.model),void 0!==e.comparator&&(this.comparator=e.comparator),this._reset(),this.initialize.apply(this,arguments),t&&this.reset(t,i.extend({silent:!0},e))},x={add:!0,remove:!0,merge:!0},k={add:!0,remove:!1},D=function(t,e,i){i=Math.min(Math.max(i,0),t.length)
var n,s=Array(t.length-i),r=e.length
for(n=0;n<s.length;n++)s[n]=t[n+i]
for(n=0;n<r;n++)t[n+i]=e[n]
for(n=0;n<s.length;n++)t[n+r+i]=s[n]}
i.extend(w.prototype,h,{model:_,initialize:function(){},toJSON:function(t){return this.map(function(e){return e.toJSON(t)})},sync:function(){return e.sync.apply(this,arguments)},add:function(t,e){return this.set(t,i.extend({merge:!1},e,k))},remove:function(t,e){e=i.extend({},e)
var n=!i.isArray(t)
t=n?[t]:t.slice()
var s=this._removeModels(t,e)
return!e.silent&&s.length&&(e.changes={added:[],merged:[],removed:s},this.trigger("update",this,e)),n?s[0]:s},set:function(t,e){if(null!=t){e=i.extend({},x,e),e.parse&&!this._isModel(t)&&(t=this.parse(t,e)||[])
var n=!i.isArray(t)
t=n?[t]:t.slice()
var s=e.at
null!=s&&(s=+s),s>this.length&&(s=this.length),s<0&&(s+=this.length+1)
var r,o,a=[],l=[],u=[],h=[],c={},d=e.add,f=e.merge,p=e.remove,m=!1,g=this.comparator&&null==s&&e.sort!==!1,v=i.isString(this.comparator)?this.comparator:null
for(o=0;o<t.length;o++){r=t[o]
var y=this.get(r)
if(y){if(f&&r!==y){var _=this._isModel(r)?r.attributes:r
e.parse&&(_=y.parse(_,e)),y.set(_,e),u.push(y),g&&!m&&(m=y.hasChanged(v))}c[y.cid]||(c[y.cid]=!0,a.push(y)),t[o]=y}else d&&(r=t[o]=this._prepareModel(r,e),r&&(l.push(r),this._addReference(r,e),c[r.cid]=!0,a.push(r)))}if(p){for(o=0;o<this.length;o++)r=this.models[o],c[r.cid]||h.push(r)
h.length&&this._removeModels(h,e)}var b=!1,w=!g&&d&&p
if(a.length&&w?(b=this.length!==a.length||i.some(this.models,function(t,e){return t!==a[e]}),this.models.length=0,D(this.models,a,0),this.length=this.models.length):l.length&&(g&&(m=!0),D(this.models,l,null==s?this.length:s),this.length=this.models.length),m&&this.sort({silent:!0}),!e.silent){for(o=0;o<l.length;o++)null!=s&&(e.index=s+o),r=l[o],r.trigger("add",r,this,e);(m||b)&&this.trigger("sort",this,e),(l.length||h.length||u.length)&&(e.changes={added:l,removed:h,merged:u},this.trigger("update",this,e))}return n?t[0]:t}},reset:function(t,e){e=e?i.clone(e):{}
for(var n=0;n<this.models.length;n++)this._removeReference(this.models[n],e)
return e.previousModels=this.models,this._reset(),t=this.add(t,i.extend({silent:!0},e)),e.silent||this.trigger("reset",this,e),t},push:function(t,e){return this.add(t,i.extend({at:this.length},e))},pop:function(t){var e=this.at(this.length-1)
return this.remove(e,t)},unshift:function(t,e){return this.add(t,i.extend({at:0},e))},shift:function(t){var e=this.at(0)
return this.remove(e,t)},slice:function(){return r.apply(this.models,arguments)},get:function(t){if(null!=t)return this._byId[t]||this._byId[this.modelId(t.attributes||t)]||t.cid&&this._byId[t.cid]},has:function(t){return null!=this.get(t)},at:function(t){return t<0&&(t+=this.length),this.models[t]},where:function(t,e){return this[e?"find":"filter"](t)},findWhere:function(t){return this.where(t,!0)},sort:function(t){var e=this.comparator
if(!e)throw new Error("Cannot sort a set without a comparator")
t||(t={})
var n=e.length
return i.isFunction(e)&&(e=i.bind(e,this)),1===n||i.isString(e)?this.models=this.sortBy(e):this.models.sort(e),t.silent||this.trigger("sort",this,t),this},pluck:function(t){return this.map(t+"")},fetch:function(t){t=i.extend({parse:!0},t)
var e=t.success,n=this
return t.success=function(i){var s=t.reset?"reset":"set"
n[s](i,t),e&&e.call(t.context,n,i,t),n.trigger("sync",n,i,t)},U(this,t),this.sync("read",this,t)},create:function(t,e){e=e?i.clone(e):{}
var n=e.wait
if(t=this._prepareModel(t,e),!t)return!1
n||this.add(t,e)
var s=this,r=e.success
return e.success=function(t,e,i){n&&s.add(t,i),r&&r.call(i.context,t,e,i)},t.save(null,e),t},parse:function(t,e){return t},clone:function(){return new this.constructor(this.models,{model:this.model,comparator:this.comparator})},modelId:function(t){return t[this.model.prototype.idAttribute||"id"]},_reset:function(){this.length=0,this.models=[],this._byId={}},_prepareModel:function(t,e){if(this._isModel(t))return t.collection||(t.collection=this),t
e=e?i.clone(e):{},e.collection=this
var n=new this.model(t,e)
return n.validationError?(this.trigger("invalid",this,n.validationError,e),!1):n},_removeModels:function(t,e){for(var i=[],n=0;n<t.length;n++){var s=this.get(t[n])
if(s){var r=this.indexOf(s)
this.models.splice(r,1),this.length--,delete this._byId[s.cid]
var o=this.modelId(s.attributes)
null!=o&&delete this._byId[o],e.silent||(e.index=r,s.trigger("remove",s,this,e)),i.push(s),this._removeReference(s,e)}}return i},_isModel:function(t){return t instanceof _},_addReference:function(t,e){this._byId[t.cid]=t
var i=this.modelId(t.attributes)
null!=i&&(this._byId[i]=t),t.on("all",this._onModelEvent,this)},_removeReference:function(t,e){delete this._byId[t.cid]
var i=this.modelId(t.attributes)
null!=i&&delete this._byId[i],this===t.collection&&delete t.collection,t.off("all",this._onModelEvent,this)},_onModelEvent:function(t,e,i,n){if(e){if(("add"===t||"remove"===t)&&i!==this)return
if("destroy"===t&&this.remove(e,n),"change"===t){var s=this.modelId(e.previousAttributes()),r=this.modelId(e.attributes)
s!==r&&(null!=s&&delete this._byId[s],null!=r&&(this._byId[r]=e))}}this.trigger.apply(this,arguments)}})
var T={forEach:3,each:3,map:3,collect:3,reduce:0,foldl:0,inject:0,reduceRight:0,foldr:0,find:3,detect:3,filter:3,select:3,reject:3,every:3,all:3,some:3,any:3,include:3,includes:3,contains:3,invoke:0,max:3,min:3,toArray:1,size:1,first:3,head:3,take:3,initial:3,rest:3,tail:3,drop:3,last:3,without:0,difference:0,indexOf:3,shuffle:1,lastIndexOf:3,isEmpty:1,chain:1,sample:3,partition:3,groupBy:3,countBy:3,sortBy:3,indexBy:3,findIndex:3,findLastIndex:3}
a(w,T,"models")
var C=e.View=function(t){this.cid=i.uniqueId("view"),i.extend(this,i.pick(t,M)),this._ensureElement(),this.initialize.apply(this,arguments)},S=/^(\S+)\s*(.*)$/,M=["model","collection","el","id","attributes","className","tagName","events"]
i.extend(C.prototype,h,{tagName:"div",$:function(t){return this.$el.find(t)},initialize:function(){},render:function(){return this},remove:function(){return this._removeElement(),this.stopListening(),this},_removeElement:function(){this.$el.remove()},setElement:function(t){return this.undelegateEvents(),this._setElement(t),this.delegateEvents(),this},_setElement:function(t){this.$el=t instanceof e.$?t:e.$(t),this.el=this.$el[0]},delegateEvents:function(t){if(t||(t=i.result(this,"events")),!t)return this
this.undelegateEvents()
for(var e in t){var n=t[e]
if(i.isFunction(n)||(n=this[n]),n){var s=e.match(S)
this.delegate(s[1],s[2],i.bind(n,this))}}return this},delegate:function(t,e,i){return this.$el.on(t+".delegateEvents"+this.cid,e,i),this},undelegateEvents:function(){return this.$el&&this.$el.off(".delegateEvents"+this.cid),this},undelegate:function(t,e,i){return this.$el.off(t+".delegateEvents"+this.cid,e,i),this},_createElement:function(t){return document.createElement(t)},_ensureElement:function(){if(this.el)this.setElement(i.result(this,"el"))
else{var t=i.extend({},i.result(this,"attributes"))
this.id&&(t.id=i.result(this,"id")),this.className&&(t.class=i.result(this,"className")),this.setElement(this._createElement(i.result(this,"tagName"))),this._setAttributes(t)}},_setAttributes:function(t){this.$el.attr(t)}}),e.sync=function(t,n,s){var r=E[t]
i.defaults(s||(s={}),{emulateHTTP:e.emulateHTTP,emulateJSON:e.emulateJSON})
var o={type:r,dataType:"json"}
if(s.url||(o.url=i.result(n,"url")||$()),null!=s.data||!n||"create"!==t&&"update"!==t&&"patch"!==t||(o.contentType="application/json",o.data=JSON.stringify(s.attrs||n.toJSON(s))),s.emulateJSON&&(o.contentType="application/x-www-form-urlencoded",o.data=o.data?{model:o.data}:{}),s.emulateHTTP&&("PUT"===r||"DELETE"===r||"PATCH"===r)){o.type="POST",s.emulateJSON&&(o.data._method=r)
var a=s.beforeSend
s.beforeSend=function(t){if(t.setRequestHeader("X-HTTP-Method-Override",r),a)return a.apply(this,arguments)}}"GET"===o.type||s.emulateJSON||(o.processData=!1)
var l=s.error
s.error=function(t,e,i){s.textStatus=e,s.errorThrown=i,l&&l.call(s.context,t,e,i)}
var u=s.xhr=e.ajax(i.extend(o,s))
return n.trigger("request",n,u,s),u}
var E={create:"POST",update:"PUT",patch:"PATCH",delete:"DELETE",read:"GET"}
e.ajax=function(){return e.$.ajax.apply(e.$,arguments)}
var N=e.Router=function(t){t||(t={}),t.routes&&(this.routes=t.routes),this._bindRoutes(),this.initialize.apply(this,arguments)},A=/\((.*?)\)/g,O=/(\(\?)?:\w+/g,P=/\*\w+/g,I=/[\-{}\[\]+?.,\\\^$|#\s]/g
i.extend(N.prototype,h,{initialize:function(){},route:function(t,n,s){i.isRegExp(t)||(t=this._routeToRegExp(t)),i.isFunction(n)&&(s=n,n=""),s||(s=this[n])
var r=this
return e.history.route(t,function(i){var o=r._extractParameters(t,i)
r.execute(s,o,n)!==!1&&(r.trigger.apply(r,["route:"+n].concat(o)),r.trigger("route",n,o),e.history.trigger("route",r,n,o))}),this},execute:function(t,e,i){t&&t.apply(this,e)},navigate:function(t,i){return e.history.navigate(t,i),this},_bindRoutes:function(){if(this.routes){this.routes=i.result(this,"routes")
for(var t,e=i.keys(this.routes);null!=(t=e.pop());)this.route(t,this.routes[t])}},_routeToRegExp:function(t){return t=t.replace(I,"\\$&").replace(A,"(?:$1)?").replace(O,function(t,e){return e?t:"([^/?]+)"}).replace(P,"([^?]*?)"),new RegExp("^"+t+"(?:\\?([\\s\\S]*))?$")},_extractParameters:function(t,e){var n=t.exec(e).slice(1)
return i.map(n,function(t,e){return e===n.length-1?t||null:t?decodeURIComponent(t):null})}})
var L=e.History=function(){this.handlers=[],this.checkUrl=i.bind(this.checkUrl,this),"undefined"!=typeof window&&(this.location=window.location,this.history=window.history)},H=/^[#\/]|\s+$/g,j=/^\/+|\/+$/g,W=/#.*$/
L.started=!1,i.extend(L.prototype,h,{interval:50,atRoot:function(){var t=this.location.pathname.replace(/[^\/]$/,"$&/")
return t===this.root&&!this.getSearch()},matchRoot:function(){var t=this.decodeFragment(this.location.pathname),e=t.slice(0,this.root.length-1)+"/"
return e===this.root},decodeFragment:function(t){return decodeURI(t.replace(/%25/g,"%2525"))},getSearch:function(){var t=this.location.href.replace(/#.*/,"").match(/\?.+/)
return t?t[0]:""},getHash:function(t){var e=(t||this).location.href.match(/#(.*)$/)
return e?e[1]:""},getPath:function(){var t=this.decodeFragment(this.location.pathname+this.getSearch()).slice(this.root.length-1)
return"/"===t.charAt(0)?t.slice(1):t},getFragment:function(t){return null==t&&(t=this._usePushState||!this._wantsHashChange?this.getPath():this.getHash()),t.replace(H,"")},start:function(t){if(L.started)throw new Error("Backbone.history has already been started")
if(L.started=!0,this.options=i.extend({root:"/"},this.options,t),this.root=this.options.root,this._wantsHashChange=this.options.hashChange!==!1,this._hasHashChange="onhashchange"in window&&(void 0===document.documentMode||document.documentMode>7),this._useHashChange=this._wantsHashChange&&this._hasHashChange,this._wantsPushState=!!this.options.pushState,this._hasPushState=!(!this.history||!this.history.pushState),this._usePushState=this._wantsPushState&&this._hasPushState,this.fragment=this.getFragment(),this.root=("/"+this.root+"/").replace(j,"/"),this._wantsHashChange&&this._wantsPushState){if(!this._hasPushState&&!this.atRoot()){var e=this.root.slice(0,-1)||"/"
return this.location.replace(e+"#"+this.getPath()),!0}this._hasPushState&&this.atRoot()&&this.navigate(this.getHash(),{replace:!0})}if(!this._hasHashChange&&this._wantsHashChange&&!this._usePushState){this.iframe=document.createElement("iframe"),this.iframe.src="javascript:0",this.iframe.style.display="none",this.iframe.tabIndex=-1
var n=document.body,s=n.insertBefore(this.iframe,n.firstChild).contentWindow
s.document.open(),s.document.close(),s.location.hash="#"+this.fragment}var r=window.addEventListener||function(t,e){return attachEvent("on"+t,e)}
if(this._usePushState?r("popstate",this.checkUrl,!1):this._useHashChange&&!this.iframe?r("hashchange",this.checkUrl,!1):this._wantsHashChange&&(this._checkUrlInterval=setInterval(this.checkUrl,this.interval)),!this.options.silent)return this.loadUrl()},stop:function(){var t=window.removeEventListener||function(t,e){return detachEvent("on"+t,e)}
this._usePushState?t("popstate",this.checkUrl,!1):this._useHashChange&&!this.iframe&&t("hashchange",this.checkUrl,!1),this.iframe&&(document.body.removeChild(this.iframe),this.iframe=null),this._checkUrlInterval&&clearInterval(this._checkUrlInterval),L.started=!1},route:function(t,e){this.handlers.unshift({route:t,callback:e})},checkUrl:function(t){var e=this.getFragment()
return e===this.fragment&&this.iframe&&(e=this.getHash(this.iframe.contentWindow)),e!==this.fragment&&(this.iframe&&this.navigate(e),void this.loadUrl())},loadUrl:function(t){return!!this.matchRoot()&&(t=this.fragment=this.getFragment(t),i.some(this.handlers,function(e){if(e.route.test(t))return e.callback(t),!0}))},navigate:function(t,e){if(!L.started)return!1
e&&e!==!0||(e={trigger:!!e}),t=this.getFragment(t||"")
var i=this.root
""!==t&&"?"!==t.charAt(0)||(i=i.slice(0,-1)||"/")
var n=i+t
if(t=this.decodeFragment(t.replace(W,"")),this.fragment!==t){if(this.fragment=t,this._usePushState)this.history[e.replace?"replaceState":"pushState"]({},document.title,n)
else{if(!this._wantsHashChange)return this.location.assign(n)
if(this._updateHash(this.location,t,e.replace),this.iframe&&t!==this.getHash(this.iframe.contentWindow)){var s=this.iframe.contentWindow
e.replace||(s.document.open(),s.document.close()),this._updateHash(s.location,t,e.replace)}}return e.trigger?this.loadUrl(t):void 0}},_updateHash:function(t,e,i){if(i){var n=t.href.replace(/(javascript:|#).*$/,"")
t.replace(n+"#"+e)}else t.hash="#"+e}}),e.history=new L
var F=function(t,e){var n,s=this
return n=t&&i.has(t,"constructor")?t.constructor:function(){return s.apply(this,arguments)},i.extend(n,s,e),n.prototype=i.create(s.prototype,t),n.prototype.constructor=n,n.__super__=s.prototype,n}
_.extend=w.extend=N.extend=C.extend=L.extend=F
var $=function(){throw new Error('A "url" property or function must be specified')},U=function(t,e){var i=e.error
e.error=function(n){i&&i.call(e.context,t,n,e),t.trigger("error",t,n,e)}}
return e}),!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):t.moment=e()}(this,function(){"use strict"
function t(){return on.apply(null,arguments)}function e(t){on=t}function i(t){return t instanceof Array||"[object Array]"===Object.prototype.toString.call(t)}function n(t){return t instanceof Date||"[object Date]"===Object.prototype.toString.call(t)}function s(t,e){var i,n=[]
for(i=0;i<t.length;++i)n.push(e(t[i],i))
return n}function r(t,e){return Object.prototype.hasOwnProperty.call(t,e)}function o(t,e){for(var i in e)r(e,i)&&(t[i]=e[i])
return r(e,"toString")&&(t.toString=e.toString),r(e,"valueOf")&&(t.valueOf=e.valueOf),t}function a(t,e,i,n){return Lt(t,e,i,n,!0).utc()}function l(){return{empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1,parsedDateParts:[],meridiem:null}}function u(t){return null==t._pf&&(t._pf=l()),t._pf}function h(t){if(null==t._isValid){var e=u(t),i=an.call(e.parsedDateParts,function(t){return null!=t})
t._isValid=!isNaN(t._d.getTime())&&e.overflow<0&&!e.empty&&!e.invalidMonth&&!e.invalidWeekday&&!e.nullInput&&!e.invalidFormat&&!e.userInvalidated&&(!e.meridiem||e.meridiem&&i),t._strict&&(t._isValid=t._isValid&&0===e.charsLeftOver&&0===e.unusedTokens.length&&void 0===e.bigHour)}return t._isValid}function c(t){var e=a(NaN)
return null!=t?o(u(e),t):u(e).userInvalidated=!0,e}function d(t){return void 0===t}function f(t,e){var i,n,s
if(d(e._isAMomentObject)||(t._isAMomentObject=e._isAMomentObject),d(e._i)||(t._i=e._i),d(e._f)||(t._f=e._f),d(e._l)||(t._l=e._l),d(e._strict)||(t._strict=e._strict),d(e._tzm)||(t._tzm=e._tzm),d(e._isUTC)||(t._isUTC=e._isUTC),d(e._offset)||(t._offset=e._offset),d(e._pf)||(t._pf=u(e)),d(e._locale)||(t._locale=e._locale),ln.length>0)for(i in ln)n=ln[i],s=e[n],d(s)||(t[n]=s)
return t}function p(e){f(this,e),this._d=new Date(null!=e._d?e._d.getTime():NaN),un===!1&&(un=!0,t.updateOffset(this),un=!1)}function m(t){return t instanceof p||null!=t&&null!=t._isAMomentObject}function g(t){return 0>t?Math.ceil(t):Math.floor(t)}function v(t){var e=+t,i=0
return 0!==e&&isFinite(e)&&(i=g(e)),i}function y(t,e,i){var n,s=Math.min(t.length,e.length),r=Math.abs(t.length-e.length),o=0
for(n=0;s>n;n++)(i&&t[n]!==e[n]||!i&&v(t[n])!==v(e[n]))&&o++
return o+r}function _(e){t.suppressDeprecationWarnings===!1&&"undefined"!=typeof console&&console.warn&&console.warn("Deprecation warning: "+e)}function b(e,i){var n=!0
return o(function(){return null!=t.deprecationHandler&&t.deprecationHandler(null,e),n&&(_(e+"\nArguments: "+Array.prototype.slice.call(arguments).join(", ")+"\n"+(new Error).stack),n=!1),i.apply(this,arguments)},i)}function w(e,i){null!=t.deprecationHandler&&t.deprecationHandler(e,i),hn[e]||(_(i),hn[e]=!0)}function x(t){return t instanceof Function||"[object Function]"===Object.prototype.toString.call(t)}function k(t){return"[object Object]"===Object.prototype.toString.call(t)}function D(t){var e,i
for(i in t)e=t[i],x(e)?this[i]=e:this["_"+i]=e
this._config=t,this._ordinalParseLenient=new RegExp(this._ordinalParse.source+"|"+/\d{1,2}/.source)}function T(t,e){var i,n=o({},t)
for(i in e)r(e,i)&&(k(t[i])&&k(e[i])?(n[i]={},o(n[i],t[i]),o(n[i],e[i])):null!=e[i]?n[i]=e[i]:delete n[i])
return n}function C(t){null!=t&&this.set(t)}function S(t){return t?t.toLowerCase().replace("_","-"):t}function M(t){for(var e,i,n,s,r=0;r<t.length;){for(s=S(t[r]).split("-"),e=s.length,i=S(t[r+1]),i=i?i.split("-"):null;e>0;){if(n=E(s.slice(0,e).join("-")))return n
if(i&&i.length>=e&&y(s,i,!0)>=e-1)break
e--}r++}return null}function E(t){var e=null
if(!pn[t]&&"undefined"!=typeof module&&module&&module.exports)try{e=dn._abbr,require("./locale/"+t),N(e)}catch(t){}return pn[t]}function N(t,e){var i
return t&&(i=d(e)?P(t):A(t,e),i&&(dn=i)),dn._abbr}function A(t,e){return null!==e?(e.abbr=t,null!=pn[t]?(w("defineLocaleOverride","use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale"),e=T(pn[t]._config,e)):null!=e.parentLocale&&(null!=pn[e.parentLocale]?e=T(pn[e.parentLocale]._config,e):w("parentLocaleUndefined","specified parentLocale is not defined yet")),pn[t]=new C(e),N(t),pn[t]):(delete pn[t],null)}function O(t,e){if(null!=e){var i
null!=pn[t]&&(e=T(pn[t]._config,e)),i=new C(e),i.parentLocale=pn[t],pn[t]=i,N(t)}else null!=pn[t]&&(null!=pn[t].parentLocale?pn[t]=pn[t].parentLocale:null!=pn[t]&&delete pn[t])
return pn[t]}function P(t){var e
if(t&&t._locale&&t._locale._abbr&&(t=t._locale._abbr),!t)return dn
if(!i(t)){if(e=E(t))return e
t=[t]}return M(t)}function I(){return cn(pn)}function L(t,e){var i=t.toLowerCase()
mn[i]=mn[i+"s"]=mn[e]=t}function H(t){return"string"==typeof t?mn[t]||mn[t.toLowerCase()]:void 0}function j(t){var e,i,n={}
for(i in t)r(t,i)&&(e=H(i),e&&(n[e]=t[i]))
return n}function W(e,i){return function(n){return null!=n?($(this,e,n),t.updateOffset(this,i),this):F(this,e)}}function F(t,e){return t.isValid()?t._d["get"+(t._isUTC?"UTC":"")+e]():NaN}function $(t,e,i){t.isValid()&&t._d["set"+(t._isUTC?"UTC":"")+e](i)}function U(t,e){var i
if("object"==typeof t)for(i in t)this.set(i,t[i])
else if(t=H(t),x(this[t]))return this[t](e)
return this}function R(t,e,i){var n=""+Math.abs(t),s=e-n.length,r=t>=0
return(r?i?"+":"":"-")+Math.pow(10,Math.max(0,s)).toString().substr(1)+n}function Y(t,e,i,n){var s=n
"string"==typeof n&&(s=function(){return this[n]()}),t&&(_n[t]=s),e&&(_n[e[0]]=function(){return R(s.apply(this,arguments),e[1],e[2])}),i&&(_n[i]=function(){return this.localeData().ordinal(s.apply(this,arguments),t)})}function q(t){return t.match(/\[[\s\S]/)?t.replace(/^\[|\]$/g,""):t.replace(/\\/g,"")}function V(t){var e,i,n=t.match(gn)
for(e=0,i=n.length;i>e;e++)_n[n[e]]?n[e]=_n[n[e]]:n[e]=q(n[e])
return function(e){var s,r=""
for(s=0;i>s;s++)r+=n[s]instanceof Function?n[s].call(e,t):n[s]
return r}}function B(t,e){return t.isValid()?(e=z(e,t.localeData()),yn[e]=yn[e]||V(e),yn[e](t)):t.localeData().invalidDate()}function z(t,e){function i(t){return e.longDateFormat(t)||t}var n=5
for(vn.lastIndex=0;n>=0&&vn.test(t);)t=t.replace(vn,i),vn.lastIndex=0,n-=1
return t}function G(t,e,i){jn[t]=x(e)?e:function(t,n){return t&&i?i:e}}function X(t,e){return r(jn,t)?jn[t](e._strict,e._locale):new RegExp(J(t))}function J(t){return Q(t.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(t,e,i,n,s){return e||i||n||s}))}function Q(t){return t.replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&")}function Z(t,e){var i,n=e
for("string"==typeof t&&(t=[t]),"number"==typeof e&&(n=function(t,i){i[e]=v(t)}),i=0;i<t.length;i++)Wn[t[i]]=n}function K(t,e){Z(t,function(t,i,n,s){n._w=n._w||{},e(t,n._w,n,s)})}function tt(t,e,i){null!=e&&r(Wn,t)&&Wn[t](e,i._a,i,t)}function et(t,e){return new Date(Date.UTC(t,e+1,0)).getUTCDate()}function it(t,e){return i(this._months)?this._months[t.month()]:this._months[Gn.test(e)?"format":"standalone"][t.month()]}function nt(t,e){return i(this._monthsShort)?this._monthsShort[t.month()]:this._monthsShort[Gn.test(e)?"format":"standalone"][t.month()]}function st(t,e,i){var n,s,r,o=t.toLocaleLowerCase()
if(!this._monthsParse)for(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[],n=0;12>n;++n)r=a([2e3,n]),this._shortMonthsParse[n]=this.monthsShort(r,"").toLocaleLowerCase(),this._longMonthsParse[n]=this.months(r,"").toLocaleLowerCase()
return i?"MMM"===e?(s=fn.call(this._shortMonthsParse,o),-1!==s?s:null):(s=fn.call(this._longMonthsParse,o),-1!==s?s:null):"MMM"===e?(s=fn.call(this._shortMonthsParse,o),-1!==s?s:(s=fn.call(this._longMonthsParse,o),-1!==s?s:null)):(s=fn.call(this._longMonthsParse,o),-1!==s?s:(s=fn.call(this._shortMonthsParse,o),-1!==s?s:null))}function rt(t,e,i){var n,s,r
if(this._monthsParseExact)return st.call(this,t,e,i)
for(this._monthsParse||(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[]),n=0;12>n;n++){if(s=a([2e3,n]),i&&!this._longMonthsParse[n]&&(this._longMonthsParse[n]=new RegExp("^"+this.months(s,"").replace(".","")+"$","i"),this._shortMonthsParse[n]=new RegExp("^"+this.monthsShort(s,"").replace(".","")+"$","i")),i||this._monthsParse[n]||(r="^"+this.months(s,"")+"|^"+this.monthsShort(s,""),this._monthsParse[n]=new RegExp(r.replace(".",""),"i")),i&&"MMMM"===e&&this._longMonthsParse[n].test(t))return n
if(i&&"MMM"===e&&this._shortMonthsParse[n].test(t))return n
if(!i&&this._monthsParse[n].test(t))return n}}function ot(t,e){var i
if(!t.isValid())return t
if("string"==typeof e)if(/^\d+$/.test(e))e=v(e)
else if(e=t.localeData().monthsParse(e),"number"!=typeof e)return t
return i=Math.min(t.date(),et(t.year(),e)),t._d["set"+(t._isUTC?"UTC":"")+"Month"](e,i),t}function at(e){return null!=e?(ot(this,e),t.updateOffset(this,!0),this):F(this,"Month")}function lt(){return et(this.year(),this.month())}function ut(t){return this._monthsParseExact?(r(this,"_monthsRegex")||ct.call(this),t?this._monthsShortStrictRegex:this._monthsShortRegex):this._monthsShortStrictRegex&&t?this._monthsShortStrictRegex:this._monthsShortRegex}function ht(t){return this._monthsParseExact?(r(this,"_monthsRegex")||ct.call(this),t?this._monthsStrictRegex:this._monthsRegex):this._monthsStrictRegex&&t?this._monthsStrictRegex:this._monthsRegex}function ct(){function t(t,e){return e.length-t.length}var e,i,n=[],s=[],r=[]
for(e=0;12>e;e++)i=a([2e3,e]),n.push(this.monthsShort(i,"")),s.push(this.months(i,"")),r.push(this.months(i,"")),r.push(this.monthsShort(i,""))
for(n.sort(t),s.sort(t),r.sort(t),e=0;12>e;e++)n[e]=Q(n[e]),s[e]=Q(s[e]),r[e]=Q(r[e])
this._monthsRegex=new RegExp("^("+r.join("|")+")","i"),this._monthsShortRegex=this._monthsRegex,this._monthsStrictRegex=new RegExp("^("+s.join("|")+")","i"),this._monthsShortStrictRegex=new RegExp("^("+n.join("|")+")","i")}function dt(t){var e,i=t._a
return i&&-2===u(t).overflow&&(e=i[$n]<0||i[$n]>11?$n:i[Un]<1||i[Un]>et(i[Fn],i[$n])?Un:i[Rn]<0||i[Rn]>24||24===i[Rn]&&(0!==i[Yn]||0!==i[qn]||0!==i[Vn])?Rn:i[Yn]<0||i[Yn]>59?Yn:i[qn]<0||i[qn]>59?qn:i[Vn]<0||i[Vn]>999?Vn:-1,u(t)._overflowDayOfYear&&(Fn>e||e>Un)&&(e=Un),u(t)._overflowWeeks&&-1===e&&(e=Bn),u(t)._overflowWeekday&&-1===e&&(e=zn),u(t).overflow=e),t}function ft(t){var e,i,n,s,r,o,a=t._i,l=Kn.exec(a)||ts.exec(a)
if(l){for(u(t).iso=!0,e=0,i=is.length;i>e;e++)if(is[e][1].exec(l[1])){s=is[e][0],n=is[e][2]!==!1
break}if(null==s)return void(t._isValid=!1)
if(l[3]){for(e=0,i=ns.length;i>e;e++)if(ns[e][1].exec(l[3])){r=(l[2]||" ")+ns[e][0]
break}if(null==r)return void(t._isValid=!1)}if(!n&&null!=r)return void(t._isValid=!1)
if(l[4]){if(!es.exec(l[4]))return void(t._isValid=!1)
o="Z"}t._f=s+(r||"")+(o||""),Mt(t)}else t._isValid=!1}function pt(e){var i=ss.exec(e._i)
return null!==i?void(e._d=new Date(+i[1])):(ft(e),void(e._isValid===!1&&(delete e._isValid,t.createFromInputFallback(e))))}function mt(t,e,i,n,s,r,o){var a=new Date(t,e,i,n,s,r,o)
return 100>t&&t>=0&&isFinite(a.getFullYear())&&a.setFullYear(t),a}function gt(t){var e=new Date(Date.UTC.apply(null,arguments))
return 100>t&&t>=0&&isFinite(e.getUTCFullYear())&&e.setUTCFullYear(t),e}function vt(t){return yt(t)?366:365}function yt(t){return t%4===0&&t%100!==0||t%400===0}function _t(){return yt(this.year())}function bt(t,e,i){var n=7+e-i,s=(7+gt(t,0,n).getUTCDay()-e)%7
return-s+n-1}function wt(t,e,i,n,s){var r,o,a=(7+i-n)%7,l=bt(t,n,s),u=1+7*(e-1)+a+l
return 0>=u?(r=t-1,o=vt(r)+u):u>vt(t)?(r=t+1,o=u-vt(t)):(r=t,o=u),{year:r,dayOfYear:o}}function xt(t,e,i){var n,s,r=bt(t.year(),e,i),o=Math.floor((t.dayOfYear()-r-1)/7)+1
return 1>o?(s=t.year()-1,n=o+kt(s,e,i)):o>kt(t.year(),e,i)?(n=o-kt(t.year(),e,i),s=t.year()+1):(s=t.year(),n=o),{week:n,year:s}}function kt(t,e,i){var n=bt(t,e,i),s=bt(t+1,e,i)
return(vt(t)-n+s)/7}function Dt(t,e,i){return null!=t?t:null!=e?e:i}function Tt(e){var i=new Date(t.now())
return e._useUTC?[i.getUTCFullYear(),i.getUTCMonth(),i.getUTCDate()]:[i.getFullYear(),i.getMonth(),i.getDate()]}function Ct(t){var e,i,n,s,r=[]
if(!t._d){for(n=Tt(t),t._w&&null==t._a[Un]&&null==t._a[$n]&&St(t),t._dayOfYear&&(s=Dt(t._a[Fn],n[Fn]),t._dayOfYear>vt(s)&&(u(t)._overflowDayOfYear=!0),i=gt(s,0,t._dayOfYear),t._a[$n]=i.getUTCMonth(),t._a[Un]=i.getUTCDate()),e=0;3>e&&null==t._a[e];++e)t._a[e]=r[e]=n[e]
for(;7>e;e++)t._a[e]=r[e]=null==t._a[e]?2===e?1:0:t._a[e]
24===t._a[Rn]&&0===t._a[Yn]&&0===t._a[qn]&&0===t._a[Vn]&&(t._nextDay=!0,t._a[Rn]=0),t._d=(t._useUTC?gt:mt).apply(null,r),null!=t._tzm&&t._d.setUTCMinutes(t._d.getUTCMinutes()-t._tzm),t._nextDay&&(t._a[Rn]=24)}}function St(t){var e,i,n,s,r,o,a,l
e=t._w,null!=e.GG||null!=e.W||null!=e.E?(r=1,o=4,i=Dt(e.GG,t._a[Fn],xt(Ht(),1,4).year),n=Dt(e.W,1),s=Dt(e.E,1),(1>s||s>7)&&(l=!0)):(r=t._locale._week.dow,o=t._locale._week.doy,i=Dt(e.gg,t._a[Fn],xt(Ht(),r,o).year),n=Dt(e.w,1),null!=e.d?(s=e.d,(0>s||s>6)&&(l=!0)):null!=e.e?(s=e.e+r,(e.e<0||e.e>6)&&(l=!0)):s=r),1>n||n>kt(i,r,o)?u(t)._overflowWeeks=!0:null!=l?u(t)._overflowWeekday=!0:(a=wt(i,n,s,r,o),t._a[Fn]=a.year,t._dayOfYear=a.dayOfYear)}function Mt(e){if(e._f===t.ISO_8601)return void ft(e)
e._a=[],u(e).empty=!0
var i,n,s,r,o,a=""+e._i,l=a.length,h=0
for(s=z(e._f,e._locale).match(gn)||[],i=0;i<s.length;i++)r=s[i],n=(a.match(X(r,e))||[])[0],n&&(o=a.substr(0,a.indexOf(n)),o.length>0&&u(e).unusedInput.push(o),a=a.slice(a.indexOf(n)+n.length),h+=n.length),_n[r]?(n?u(e).empty=!1:u(e).unusedTokens.push(r),tt(r,n,e)):e._strict&&!n&&u(e).unusedTokens.push(r)
u(e).charsLeftOver=l-h,a.length>0&&u(e).unusedInput.push(a),u(e).bigHour===!0&&e._a[Rn]<=12&&e._a[Rn]>0&&(u(e).bigHour=void 0),u(e).parsedDateParts=e._a.slice(0),u(e).meridiem=e._meridiem,e._a[Rn]=Et(e._locale,e._a[Rn],e._meridiem),Ct(e),dt(e)}function Et(t,e,i){var n
return null==i?e:null!=t.meridiemHour?t.meridiemHour(e,i):null!=t.isPM?(n=t.isPM(i),n&&12>e&&(e+=12),n||12!==e||(e=0),e):e}function Nt(t){var e,i,n,s,r
if(0===t._f.length)return u(t).invalidFormat=!0,void(t._d=new Date(NaN))
for(s=0;s<t._f.length;s++)r=0,e=f({},t),null!=t._useUTC&&(e._useUTC=t._useUTC),e._f=t._f[s],Mt(e),h(e)&&(r+=u(e).charsLeftOver,r+=10*u(e).unusedTokens.length,u(e).score=r,(null==n||n>r)&&(n=r,i=e))
o(t,i||e)}function At(t){if(!t._d){var e=j(t._i)
t._a=s([e.year,e.month,e.day||e.date,e.hour,e.minute,e.second,e.millisecond],function(t){return t&&parseInt(t,10)}),Ct(t)}}function Ot(t){var e=new p(dt(Pt(t)))
return e._nextDay&&(e.add(1,"d"),e._nextDay=void 0),e}function Pt(t){var e=t._i,s=t._f
return t._locale=t._locale||P(t._l),null===e||void 0===s&&""===e?c({nullInput:!0}):("string"==typeof e&&(t._i=e=t._locale.preparse(e)),m(e)?new p(dt(e)):(i(s)?Nt(t):s?Mt(t):n(e)?t._d=e:It(t),h(t)||(t._d=null),t))}function It(e){var r=e._i
void 0===r?e._d=new Date(t.now()):n(r)?e._d=new Date(r.valueOf()):"string"==typeof r?pt(e):i(r)?(e._a=s(r.slice(0),function(t){return parseInt(t,10)}),Ct(e)):"object"==typeof r?At(e):"number"==typeof r?e._d=new Date(r):t.createFromInputFallback(e)}function Lt(t,e,i,n,s){var r={}
return"boolean"==typeof i&&(n=i,i=void 0),r._isAMomentObject=!0,r._useUTC=r._isUTC=s,r._l=i,r._i=t,r._f=e,r._strict=n,Ot(r)}function Ht(t,e,i,n){return Lt(t,e,i,n,!1)}function jt(t,e){var n,s
if(1===e.length&&i(e[0])&&(e=e[0]),!e.length)return Ht()
for(n=e[0],s=1;s<e.length;++s)(!e[s].isValid()||e[s][t](n))&&(n=e[s])
return n}function Wt(){var t=[].slice.call(arguments,0)
return jt("isBefore",t)}function Ft(){var t=[].slice.call(arguments,0)
return jt("isAfter",t)}function $t(t){var e=j(t),i=e.year||0,n=e.quarter||0,s=e.month||0,r=e.week||0,o=e.day||0,a=e.hour||0,l=e.minute||0,u=e.second||0,h=e.millisecond||0
this._milliseconds=+h+1e3*u+6e4*l+1e3*a*60*60,this._days=+o+7*r,this._months=+s+3*n+12*i,this._data={},this._locale=P(),this._bubble()}function Ut(t){return t instanceof $t}function Rt(t,e){Y(t,0,0,function(){var t=this.utcOffset(),i="+"
return 0>t&&(t=-t,i="-"),i+R(~~(t/60),2)+e+R(~~t%60,2)})}function Yt(t,e){var i=(e||"").match(t)||[],n=i[i.length-1]||[],s=(n+"").match(us)||["-",0,0],r=+(60*s[1])+v(s[2])
return"+"===s[0]?r:-r}function qt(e,i){var s,r
return i._isUTC?(s=i.clone(),r=(m(e)||n(e)?e.valueOf():Ht(e).valueOf())-s.valueOf(),s._d.setTime(s._d.valueOf()+r),t.updateOffset(s,!1),s):Ht(e).local()}function Vt(t){return 15*-Math.round(t._d.getTimezoneOffset()/15)}function Bt(e,i){var n,s=this._offset||0
return this.isValid()?null!=e?("string"==typeof e?e=Yt(In,e):Math.abs(e)<16&&(e*=60),!this._isUTC&&i&&(n=Vt(this)),this._offset=e,this._isUTC=!0,null!=n&&this.add(n,"m"),s!==e&&(!i||this._changeInProgress?ue(this,ne(e-s,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,t.updateOffset(this,!0),this._changeInProgress=null)),this):this._isUTC?s:Vt(this):null!=e?this:NaN}function zt(t,e){return null!=t?("string"!=typeof t&&(t=-t),this.utcOffset(t,e),this):-this.utcOffset()}function Gt(t){return this.utcOffset(0,t)}function Xt(t){return this._isUTC&&(this.utcOffset(0,t),this._isUTC=!1,t&&this.subtract(Vt(this),"m")),this}function Jt(){return this._tzm?this.utcOffset(this._tzm):"string"==typeof this._i&&this.utcOffset(Yt(Pn,this._i)),this}function Qt(t){return!!this.isValid()&&(t=t?Ht(t).utcOffset():0,(this.utcOffset()-t)%60===0)}function Zt(){return this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset()}function Kt(){if(!d(this._isDSTShifted))return this._isDSTShifted
var t={}
if(f(t,this),t=Pt(t),t._a){var e=t._isUTC?a(t._a):Ht(t._a)
this._isDSTShifted=this.isValid()&&y(t._a,e.toArray())>0}else this._isDSTShifted=!1
return this._isDSTShifted}function te(){return!!this.isValid()&&!this._isUTC}function ee(){return!!this.isValid()&&this._isUTC}function ie(){return!!this.isValid()&&(this._isUTC&&0===this._offset)}function ne(t,e){var i,n,s,o=t,a=null
return Ut(t)?o={ms:t._milliseconds,d:t._days,M:t._months}:"number"==typeof t?(o={},e?o[e]=t:o.milliseconds=t):(a=hs.exec(t))?(i="-"===a[1]?-1:1,o={y:0,d:v(a[Un])*i,h:v(a[Rn])*i,m:v(a[Yn])*i,s:v(a[qn])*i,ms:v(a[Vn])*i}):(a=cs.exec(t))?(i="-"===a[1]?-1:1,o={y:se(a[2],i),M:se(a[3],i),w:se(a[4],i),d:se(a[5],i),h:se(a[6],i),m:se(a[7],i),s:se(a[8],i)}):null==o?o={}:"object"==typeof o&&("from"in o||"to"in o)&&(s=oe(Ht(o.from),Ht(o.to)),o={},o.ms=s.milliseconds,o.M=s.months),n=new $t(o),Ut(t)&&r(t,"_locale")&&(n._locale=t._locale),n}function se(t,e){var i=t&&parseFloat(t.replace(",","."))
return(isNaN(i)?0:i)*e}function re(t,e){var i={milliseconds:0,months:0}
return i.months=e.month()-t.month()+12*(e.year()-t.year()),t.clone().add(i.months,"M").isAfter(e)&&--i.months,i.milliseconds=+e-+t.clone().add(i.months,"M"),i}function oe(t,e){var i
return t.isValid()&&e.isValid()?(e=qt(e,t),t.isBefore(e)?i=re(t,e):(i=re(e,t),i.milliseconds=-i.milliseconds,i.months=-i.months),i):{milliseconds:0,months:0}}function ae(t){return 0>t?-1*Math.round(-1*t):Math.round(t)}function le(t,e){return function(i,n){var s,r
return null===n||isNaN(+n)||(w(e,"moment()."+e+"(period, number) is deprecated. Please use moment()."+e+"(number, period)."),r=i,i=n,n=r),i="string"==typeof i?+i:i,s=ne(i,n),ue(this,s,t),this}}function ue(e,i,n,s){var r=i._milliseconds,o=ae(i._days),a=ae(i._months)
e.isValid()&&(s=null==s||s,r&&e._d.setTime(e._d.valueOf()+r*n),o&&$(e,"Date",F(e,"Date")+o*n),a&&ot(e,F(e,"Month")+a*n),s&&t.updateOffset(e,o||a))}function he(t,e){var i=t||Ht(),n=qt(i,this).startOf("day"),s=this.diff(n,"days",!0),r=-6>s?"sameElse":-1>s?"lastWeek":0>s?"lastDay":1>s?"sameDay":2>s?"nextDay":7>s?"nextWeek":"sameElse",o=e&&(x(e[r])?e[r]():e[r])
return this.format(o||this.localeData().calendar(r,this,Ht(i)))}function ce(){return new p(this)}function de(t,e){var i=m(t)?t:Ht(t)
return!(!this.isValid()||!i.isValid())&&(e=H(d(e)?"millisecond":e),"millisecond"===e?this.valueOf()>i.valueOf():i.valueOf()<this.clone().startOf(e).valueOf())}function fe(t,e){var i=m(t)?t:Ht(t)
return!(!this.isValid()||!i.isValid())&&(e=H(d(e)?"millisecond":e),"millisecond"===e?this.valueOf()<i.valueOf():this.clone().endOf(e).valueOf()<i.valueOf())}function pe(t,e,i,n){return n=n||"()",("("===n[0]?this.isAfter(t,i):!this.isBefore(t,i))&&(")"===n[1]?this.isBefore(e,i):!this.isAfter(e,i))}function me(t,e){var i,n=m(t)?t:Ht(t)
return!(!this.isValid()||!n.isValid())&&(e=H(e||"millisecond"),"millisecond"===e?this.valueOf()===n.valueOf():(i=n.valueOf(),this.clone().startOf(e).valueOf()<=i&&i<=this.clone().endOf(e).valueOf()))}function ge(t,e){return this.isSame(t,e)||this.isAfter(t,e)}function ve(t,e){return this.isSame(t,e)||this.isBefore(t,e)}function ye(t,e,i){var n,s,r,o
return this.isValid()?(n=qt(t,this),n.isValid()?(s=6e4*(n.utcOffset()-this.utcOffset()),e=H(e),"year"===e||"month"===e||"quarter"===e?(o=_e(this,n),"quarter"===e?o/=3:"year"===e&&(o/=12)):(r=this-n,o="second"===e?r/1e3:"minute"===e?r/6e4:"hour"===e?r/36e5:"day"===e?(r-s)/864e5:"week"===e?(r-s)/6048e5:r),i?o:g(o)):NaN):NaN}function _e(t,e){var i,n,s=12*(e.year()-t.year())+(e.month()-t.month()),r=t.clone().add(s,"months")
return 0>e-r?(i=t.clone().add(s-1,"months"),n=(e-r)/(r-i)):(i=t.clone().add(s+1,"months"),n=(e-r)/(i-r)),-(s+n)||0}function be(){return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")}function we(){var t=this.clone().utc()
return 0<t.year()&&t.year()<=9999?x(Date.prototype.toISOString)?this.toDate().toISOString():B(t,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"):B(t,"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")}function xe(e){e||(e=this.isUtc()?t.defaultFormatUtc:t.defaultFormat)
var i=B(this,e)
return this.localeData().postformat(i)}function ke(t,e){return this.isValid()&&(m(t)&&t.isValid()||Ht(t).isValid())?ne({to:this,from:t}).locale(this.locale()).humanize(!e):this.localeData().invalidDate()}function De(t){return this.from(Ht(),t)}function Te(t,e){return this.isValid()&&(m(t)&&t.isValid()||Ht(t).isValid())?ne({from:this,to:t}).locale(this.locale()).humanize(!e):this.localeData().invalidDate()}function Ce(t){return this.to(Ht(),t)}function Se(t){var e
return void 0===t?this._locale._abbr:(e=P(t),null!=e&&(this._locale=e),this)}function Me(){return this._locale}function Ee(t){switch(t=H(t)){case"year":this.month(0)
case"quarter":case"month":this.date(1)
case"week":case"isoWeek":case"day":case"date":this.hours(0)
case"hour":this.minutes(0)
case"minute":this.seconds(0)
case"second":this.milliseconds(0)}return"week"===t&&this.weekday(0),"isoWeek"===t&&this.isoWeekday(1),"quarter"===t&&this.month(3*Math.floor(this.month()/3)),this}function Ne(t){return t=H(t),void 0===t||"millisecond"===t?this:("date"===t&&(t="day"),this.startOf(t).add(1,"isoWeek"===t?"week":t).subtract(1,"ms"))}function Ae(){return this._d.valueOf()-6e4*(this._offset||0)}function Oe(){return Math.floor(this.valueOf()/1e3)}function Pe(){return this._offset?new Date(this.valueOf()):this._d}function Ie(){var t=this
return[t.year(),t.month(),t.date(),t.hour(),t.minute(),t.second(),t.millisecond()]}function Le(){var t=this
return{years:t.year(),months:t.month(),date:t.date(),hours:t.hours(),minutes:t.minutes(),seconds:t.seconds(),milliseconds:t.milliseconds()}}function He(){return this.isValid()?this.toISOString():null}function je(){return h(this)}function We(){return o({},u(this))}function Fe(){return u(this).overflow}function $e(){return{input:this._i,format:this._f,locale:this._locale,isUTC:this._isUTC,strict:this._strict}}function Ue(t,e){Y(0,[t,t.length],0,e)}function Re(t){return Be.call(this,t,this.week(),this.weekday(),this.localeData()._week.dow,this.localeData()._week.doy)}function Ye(t){return Be.call(this,t,this.isoWeek(),this.isoWeekday(),1,4)}function qe(){return kt(this.year(),1,4)}function Ve(){var t=this.localeData()._week
return kt(this.year(),t.dow,t.doy)}function Be(t,e,i,n,s){var r
return null==t?xt(this,n,s).year:(r=kt(t,n,s),e>r&&(e=r),ze.call(this,t,e,i,n,s))}function ze(t,e,i,n,s){var r=wt(t,e,i,n,s),o=gt(r.year,0,r.dayOfYear)
return this.year(o.getUTCFullYear()),this.month(o.getUTCMonth()),this.date(o.getUTCDate()),this}function Ge(t){return null==t?Math.ceil((this.month()+1)/3):this.month(3*(t-1)+this.month()%3)}function Xe(t){return xt(t,this._week.dow,this._week.doy).week}function Je(){return this._week.dow}function Qe(){return this._week.doy}function Ze(t){var e=this.localeData().week(this)
return null==t?e:this.add(7*(t-e),"d")}function Ke(t){var e=xt(this,1,4).week
return null==t?e:this.add(7*(t-e),"d")}function ti(t,e){return"string"!=typeof t?t:isNaN(t)?(t=e.weekdaysParse(t),"number"==typeof t?t:null):parseInt(t,10)}function ei(t,e){return i(this._weekdays)?this._weekdays[t.day()]:this._weekdays[this._weekdays.isFormat.test(e)?"format":"standalone"][t.day()]}function ii(t){return this._weekdaysShort[t.day()]}function ni(t){return this._weekdaysMin[t.day()]}function si(t,e,i){var n,s,r,o=t.toLocaleLowerCase()
if(!this._weekdaysParse)for(this._weekdaysParse=[],this._shortWeekdaysParse=[],this._minWeekdaysParse=[],n=0;7>n;++n)r=a([2e3,1]).day(n),this._minWeekdaysParse[n]=this.weekdaysMin(r,"").toLocaleLowerCase(),this._shortWeekdaysParse[n]=this.weekdaysShort(r,"").toLocaleLowerCase(),this._weekdaysParse[n]=this.weekdays(r,"").toLocaleLowerCase()
return i?"dddd"===e?(s=fn.call(this._weekdaysParse,o),-1!==s?s:null):"ddd"===e?(s=fn.call(this._shortWeekdaysParse,o),-1!==s?s:null):(s=fn.call(this._minWeekdaysParse,o),-1!==s?s:null):"dddd"===e?(s=fn.call(this._weekdaysParse,o),-1!==s?s:(s=fn.call(this._shortWeekdaysParse,o),-1!==s?s:(s=fn.call(this._minWeekdaysParse,o),-1!==s?s:null))):"ddd"===e?(s=fn.call(this._shortWeekdaysParse,o),-1!==s?s:(s=fn.call(this._weekdaysParse,o),-1!==s?s:(s=fn.call(this._minWeekdaysParse,o),-1!==s?s:null))):(s=fn.call(this._minWeekdaysParse,o),-1!==s?s:(s=fn.call(this._weekdaysParse,o),-1!==s?s:(s=fn.call(this._shortWeekdaysParse,o),-1!==s?s:null)))}function ri(t,e,i){var n,s,r
if(this._weekdaysParseExact)return si.call(this,t,e,i)
for(this._weekdaysParse||(this._weekdaysParse=[],this._minWeekdaysParse=[],this._shortWeekdaysParse=[],this._fullWeekdaysParse=[]),n=0;7>n;n++){if(s=a([2e3,1]).day(n),i&&!this._fullWeekdaysParse[n]&&(this._fullWeekdaysParse[n]=new RegExp("^"+this.weekdays(s,"").replace(".",".?")+"$","i"),this._shortWeekdaysParse[n]=new RegExp("^"+this.weekdaysShort(s,"").replace(".",".?")+"$","i"),this._minWeekdaysParse[n]=new RegExp("^"+this.weekdaysMin(s,"").replace(".",".?")+"$","i")),this._weekdaysParse[n]||(r="^"+this.weekdays(s,"")+"|^"+this.weekdaysShort(s,"")+"|^"+this.weekdaysMin(s,""),this._weekdaysParse[n]=new RegExp(r.replace(".",""),"i")),i&&"dddd"===e&&this._fullWeekdaysParse[n].test(t))return n
if(i&&"ddd"===e&&this._shortWeekdaysParse[n].test(t))return n
if(i&&"dd"===e&&this._minWeekdaysParse[n].test(t))return n
if(!i&&this._weekdaysParse[n].test(t))return n}}function oi(t){if(!this.isValid())return null!=t?this:NaN
var e=this._isUTC?this._d.getUTCDay():this._d.getDay()
return null!=t?(t=ti(t,this.localeData()),this.add(t-e,"d")):e}function ai(t){if(!this.isValid())return null!=t?this:NaN
var e=(this.day()+7-this.localeData()._week.dow)%7
return null==t?e:this.add(t-e,"d")}function li(t){return this.isValid()?null==t?this.day()||7:this.day(this.day()%7?t:t-7):null!=t?this:NaN}function ui(t){return this._weekdaysParseExact?(r(this,"_weekdaysRegex")||di.call(this),t?this._weekdaysStrictRegex:this._weekdaysRegex):this._weekdaysStrictRegex&&t?this._weekdaysStrictRegex:this._weekdaysRegex}function hi(t){return this._weekdaysParseExact?(r(this,"_weekdaysRegex")||di.call(this),t?this._weekdaysShortStrictRegex:this._weekdaysShortRegex):this._weekdaysShortStrictRegex&&t?this._weekdaysShortStrictRegex:this._weekdaysShortRegex}function ci(t){return this._weekdaysParseExact?(r(this,"_weekdaysRegex")||di.call(this),t?this._weekdaysMinStrictRegex:this._weekdaysMinRegex):this._weekdaysMinStrictRegex&&t?this._weekdaysMinStrictRegex:this._weekdaysMinRegex}function di(){function t(t,e){return e.length-t.length}var e,i,n,s,r,o=[],l=[],u=[],h=[]
for(e=0;7>e;e++)i=a([2e3,1]).day(e),n=this.weekdaysMin(i,""),s=this.weekdaysShort(i,""),r=this.weekdays(i,""),o.push(n),l.push(s),u.push(r),h.push(n),h.push(s),h.push(r)
for(o.sort(t),l.sort(t),u.sort(t),h.sort(t),e=0;7>e;e++)l[e]=Q(l[e]),u[e]=Q(u[e]),h[e]=Q(h[e])
this._weekdaysRegex=new RegExp("^("+h.join("|")+")","i"),this._weekdaysShortRegex=this._weekdaysRegex,this._weekdaysMinRegex=this._weekdaysRegex,this._weekdaysStrictRegex=new RegExp("^("+u.join("|")+")","i"),this._weekdaysShortStrictRegex=new RegExp("^("+l.join("|")+")","i"),this._weekdaysMinStrictRegex=new RegExp("^("+o.join("|")+")","i")}function fi(t){var e=Math.round((this.clone().startOf("day")-this.clone().startOf("year"))/864e5)+1
return null==t?e:this.add(t-e,"d")}function pi(){return this.hours()%12||12}function mi(){return this.hours()||24}function gi(t,e){Y(t,0,0,function(){return this.localeData().meridiem(this.hours(),this.minutes(),e)})}function vi(t,e){return e._meridiemParse}function yi(t){return"p"===(t+"").toLowerCase().charAt(0)}function _i(t,e,i){return t>11?i?"pm":"PM":i?"am":"AM"}function bi(t,e){e[Vn]=v(1e3*("0."+t))}function wi(){return this._isUTC?"UTC":""}function xi(){return this._isUTC?"Coordinated Universal Time":""}function ki(t){return Ht(1e3*t)}function Di(){return Ht.apply(null,arguments).parseZone()}function Ti(t,e,i){var n=this._calendar[t]
return x(n)?n.call(e,i):n}function Ci(t){var e=this._longDateFormat[t],i=this._longDateFormat[t.toUpperCase()]
return e||!i?e:(this._longDateFormat[t]=i.replace(/MMMM|MM|DD|dddd/g,function(t){return t.slice(1)}),this._longDateFormat[t])}function Si(){return this._invalidDate}function Mi(t){return this._ordinal.replace("%d",t)}function Ei(t){return t}function Ni(t,e,i,n){var s=this._relativeTime[i]
return x(s)?s(t,e,i,n):s.replace(/%d/i,t)}function Ai(t,e){var i=this._relativeTime[t>0?"future":"past"]
return x(i)?i(e):i.replace(/%s/i,e)}function Oi(t,e,i,n){var s=P(),r=a().set(n,e)
return s[i](r,t)}function Pi(t,e,i){if("number"==typeof t&&(e=t,t=void 0),t=t||"",null!=e)return Oi(t,e,i,"month")
var n,s=[]
for(n=0;12>n;n++)s[n]=Oi(t,n,i,"month")
return s}function Ii(t,e,i,n){"boolean"==typeof t?("number"==typeof e&&(i=e,e=void 0),e=e||""):(e=t,i=e,t=!1,"number"==typeof e&&(i=e,e=void 0),e=e||"")
var s=P(),r=t?s._week.dow:0
if(null!=i)return Oi(e,(i+r)%7,n,"day")
var o,a=[]
for(o=0;7>o;o++)a[o]=Oi(e,(o+r)%7,n,"day")
return a}function Li(t,e){return Pi(t,e,"months")}function Hi(t,e){return Pi(t,e,"monthsShort")}function ji(t,e,i){return Ii(t,e,i,"weekdays")}function Wi(t,e,i){return Ii(t,e,i,"weekdaysShort")}function Fi(t,e,i){return Ii(t,e,i,"weekdaysMin")}function $i(){var t=this._data
return this._milliseconds=Ws(this._milliseconds),this._days=Ws(this._days),this._months=Ws(this._months),t.milliseconds=Ws(t.milliseconds),t.seconds=Ws(t.seconds),t.minutes=Ws(t.minutes),t.hours=Ws(t.hours),t.months=Ws(t.months),t.years=Ws(t.years),this}function Ui(t,e,i,n){var s=ne(e,i)
return t._milliseconds+=n*s._milliseconds,t._days+=n*s._days,t._months+=n*s._months,t._bubble()}function Ri(t,e){return Ui(this,t,e,1)}function Yi(t,e){return Ui(this,t,e,-1)}function qi(t){return 0>t?Math.floor(t):Math.ceil(t)}function Vi(){var t,e,i,n,s,r=this._milliseconds,o=this._days,a=this._months,l=this._data
return r>=0&&o>=0&&a>=0||0>=r&&0>=o&&0>=a||(r+=864e5*qi(zi(a)+o),o=0,a=0),l.milliseconds=r%1e3,t=g(r/1e3),l.seconds=t%60,e=g(t/60),l.minutes=e%60,i=g(e/60),l.hours=i%24,o+=g(i/24),s=g(Bi(o)),a+=s,o-=qi(zi(s)),n=g(a/12),a%=12,l.days=o,l.months=a,l.years=n,this}function Bi(t){return 4800*t/146097}function zi(t){return 146097*t/4800}function Gi(t){var e,i,n=this._milliseconds
if(t=H(t),"month"===t||"year"===t)return e=this._days+n/864e5,i=this._months+Bi(e),"month"===t?i:i/12
switch(e=this._days+Math.round(zi(this._months)),t){case"week":return e/7+n/6048e5
case"day":return e+n/864e5
case"hour":return 24*e+n/36e5
case"minute":return 1440*e+n/6e4
case"second":return 86400*e+n/1e3
case"millisecond":return Math.floor(864e5*e)+n
default:throw new Error("Unknown unit "+t)}}function Xi(){return this._milliseconds+864e5*this._days+this._months%12*2592e6+31536e6*v(this._months/12)}function Ji(t){return function(){return this.as(t)}}function Qi(t){return t=H(t),this[t+"s"]()}function Zi(t){return function(){return this._data[t]}}function Ki(){return g(this.days()/7)}function tn(t,e,i,n,s){return s.relativeTime(e||1,!!i,t,n)}function en(t,e,i){var n=ne(t).abs(),s=tr(n.as("s")),r=tr(n.as("m")),o=tr(n.as("h")),a=tr(n.as("d")),l=tr(n.as("M")),u=tr(n.as("y")),h=s<er.s&&["s",s]||1>=r&&["m"]||r<er.m&&["mm",r]||1>=o&&["h"]||o<er.h&&["hh",o]||1>=a&&["d"]||a<er.d&&["dd",a]||1>=l&&["M"]||l<er.M&&["MM",l]||1>=u&&["y"]||["yy",u]
return h[2]=e,h[3]=+t>0,h[4]=i,tn.apply(null,h)}function nn(t,e){return void 0!==er[t]&&(void 0===e?er[t]:(er[t]=e,!0))}function sn(t){var e=this.localeData(),i=en(this,!t,e)
return t&&(i=e.pastFuture(+this,i)),e.postformat(i)}function rn(){var t,e,i,n=ir(this._milliseconds)/1e3,s=ir(this._days),r=ir(this._months)
t=g(n/60),e=g(t/60),n%=60,t%=60,i=g(r/12),r%=12
var o=i,a=r,l=s,u=e,h=t,c=n,d=this.asSeconds()
return d?(0>d?"-":"")+"P"+(o?o+"Y":"")+(a?a+"M":"")+(l?l+"D":"")+(u||h||c?"T":"")+(u?u+"H":"")+(h?h+"M":"")+(c?c+"S":""):"P0D"}var on,an
an=Array.prototype.some?Array.prototype.some:function(t){for(var e=Object(this),i=e.length>>>0,n=0;i>n;n++)if(n in e&&t.call(this,e[n],n,e))return!0
return!1}
var ln=t.momentProperties=[],un=!1,hn={}
t.suppressDeprecationWarnings=!1,t.deprecationHandler=null
var cn
cn=Object.keys?Object.keys:function(t){var e,i=[]
for(e in t)r(t,e)&&i.push(e)
return i}
var dn,fn,pn={},mn={},gn=/(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,vn=/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,yn={},_n={},bn=/\d/,wn=/\d\d/,xn=/\d{3}/,kn=/\d{4}/,Dn=/[+-]?\d{6}/,Tn=/\d\d?/,Cn=/\d\d\d\d?/,Sn=/\d\d\d\d\d\d?/,Mn=/\d{1,3}/,En=/\d{1,4}/,Nn=/[+-]?\d{1,6}/,An=/\d+/,On=/[+-]?\d+/,Pn=/Z|[+-]\d\d:?\d\d/gi,In=/Z|[+-]\d\d(?::?\d\d)?/gi,Ln=/[+-]?\d+(\.\d{1,3})?/,Hn=/[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i,jn={},Wn={},Fn=0,$n=1,Un=2,Rn=3,Yn=4,qn=5,Vn=6,Bn=7,zn=8
fn=Array.prototype.indexOf?Array.prototype.indexOf:function(t){var e
for(e=0;e<this.length;++e)if(this[e]===t)return e
return-1},Y("M",["MM",2],"Mo",function(){return this.month()+1}),Y("MMM",0,0,function(t){return this.localeData().monthsShort(this,t)}),Y("MMMM",0,0,function(t){return this.localeData().months(this,t)}),L("month","M"),G("M",Tn),G("MM",Tn,wn),G("MMM",function(t,e){return e.monthsShortRegex(t)}),G("MMMM",function(t,e){return e.monthsRegex(t)}),Z(["M","MM"],function(t,e){e[$n]=v(t)-1}),Z(["MMM","MMMM"],function(t,e,i,n){var s=i._locale.monthsParse(t,n,i._strict)
null!=s?e[$n]=s:u(i).invalidMonth=t})
var Gn=/D[oD]?(\[[^\[\]]*\]|\s+)+MMMM?/,Xn="January_February_March_April_May_June_July_August_September_October_November_December".split("_"),Jn="Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),Qn=Hn,Zn=Hn,Kn=/^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,ts=/^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,es=/Z|[+-]\d\d(?::?\d\d)?/,is=[["YYYYYY-MM-DD",/[+-]\d{6}-\d\d-\d\d/],["YYYY-MM-DD",/\d{4}-\d\d-\d\d/],["GGGG-[W]WW-E",/\d{4}-W\d\d-\d/],["GGGG-[W]WW",/\d{4}-W\d\d/,!1],["YYYY-DDD",/\d{4}-\d{3}/],["YYYY-MM",/\d{4}-\d\d/,!1],["YYYYYYMMDD",/[+-]\d{10}/],["YYYYMMDD",/\d{8}/],["GGGG[W]WWE",/\d{4}W\d{3}/],["GGGG[W]WW",/\d{4}W\d{2}/,!1],["YYYYDDD",/\d{7}/]],ns=[["HH:mm:ss.SSSS",/\d\d:\d\d:\d\d\.\d+/],["HH:mm:ss,SSSS",/\d\d:\d\d:\d\d,\d+/],["HH:mm:ss",/\d\d:\d\d:\d\d/],["HH:mm",/\d\d:\d\d/],["HHmmss.SSSS",/\d\d\d\d\d\d\.\d+/],["HHmmss,SSSS",/\d\d\d\d\d\d,\d+/],["HHmmss",/\d\d\d\d\d\d/],["HHmm",/\d\d\d\d/],["HH",/\d\d/]],ss=/^\/?Date\((\-?\d+)/i
t.createFromInputFallback=b("moment construction falls back to js Date. This is discouraged and will be removed in upcoming major release. Please refer to https://github.com/moment/moment/issues/1407 for more info.",function(t){t._d=new Date(t._i+(t._useUTC?" UTC":""))}),Y("Y",0,0,function(){var t=this.year()
return 9999>=t?""+t:"+"+t}),Y(0,["YY",2],0,function(){return this.year()%100}),Y(0,["YYYY",4],0,"year"),Y(0,["YYYYY",5],0,"year"),Y(0,["YYYYYY",6,!0],0,"year"),L("year","y"),G("Y",On),G("YY",Tn,wn),G("YYYY",En,kn),G("YYYYY",Nn,Dn),G("YYYYYY",Nn,Dn),Z(["YYYYY","YYYYYY"],Fn),Z("YYYY",function(e,i){i[Fn]=2===e.length?t.parseTwoDigitYear(e):v(e)}),Z("YY",function(e,i){i[Fn]=t.parseTwoDigitYear(e)}),Z("Y",function(t,e){e[Fn]=parseInt(t,10)}),t.parseTwoDigitYear=function(t){return v(t)+(v(t)>68?1900:2e3)}
var rs=W("FullYear",!0)
t.ISO_8601=function(){}
var os=b("moment().min is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548",function(){var t=Ht.apply(null,arguments)
return this.isValid()&&t.isValid()?this>t?this:t:c()}),as=b("moment().max is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548",function(){var t=Ht.apply(null,arguments)
return this.isValid()&&t.isValid()?t>this?this:t:c()}),ls=function(){return Date.now?Date.now():+new Date}
Rt("Z",":"),Rt("ZZ",""),G("Z",In),G("ZZ",In),Z(["Z","ZZ"],function(t,e,i){i._useUTC=!0,i._tzm=Yt(In,t)})
var us=/([\+\-]|\d\d)/gi
t.updateOffset=function(){}
var hs=/^(\-)?(?:(\d*)[. ])?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?\d*)?$/,cs=/^(-)?P(?:(-?[0-9,.]*)Y)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)W)?(?:(-?[0-9,.]*)D)?(?:T(?:(-?[0-9,.]*)H)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)S)?)?$/
ne.fn=$t.prototype
var ds=le(1,"add"),fs=le(-1,"subtract")
t.defaultFormat="YYYY-MM-DDTHH:mm:ssZ",t.defaultFormatUtc="YYYY-MM-DDTHH:mm:ss[Z]"
var ps=b("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.",function(t){return void 0===t?this.localeData():this.locale(t)})
Y(0,["gg",2],0,function(){return this.weekYear()%100}),Y(0,["GG",2],0,function(){return this.isoWeekYear()%100}),Ue("gggg","weekYear"),Ue("ggggg","weekYear"),Ue("GGGG","isoWeekYear"),Ue("GGGGG","isoWeekYear"),L("weekYear","gg"),L("isoWeekYear","GG"),G("G",On),G("g",On),G("GG",Tn,wn),G("gg",Tn,wn),G("GGGG",En,kn),G("gggg",En,kn),G("GGGGG",Nn,Dn),G("ggggg",Nn,Dn),K(["gggg","ggggg","GGGG","GGGGG"],function(t,e,i,n){e[n.substr(0,2)]=v(t)}),K(["gg","GG"],function(e,i,n,s){i[s]=t.parseTwoDigitYear(e)}),Y("Q",0,"Qo","quarter"),L("quarter","Q"),G("Q",bn),Z("Q",function(t,e){e[$n]=3*(v(t)-1)}),Y("w",["ww",2],"wo","week"),Y("W",["WW",2],"Wo","isoWeek"),L("week","w"),L("isoWeek","W"),G("w",Tn),G("ww",Tn,wn),G("W",Tn),G("WW",Tn,wn),K(["w","ww","W","WW"],function(t,e,i,n){e[n.substr(0,1)]=v(t)})
var ms={dow:0,doy:6}
Y("D",["DD",2],"Do","date"),L("date","D"),G("D",Tn),G("DD",Tn,wn),G("Do",function(t,e){return t?e._ordinalParse:e._ordinalParseLenient}),Z(["D","DD"],Un),Z("Do",function(t,e){e[Un]=v(t.match(Tn)[0],10)})
var gs=W("Date",!0)
Y("d",0,"do","day"),Y("dd",0,0,function(t){return this.localeData().weekdaysMin(this,t)}),Y("ddd",0,0,function(t){return this.localeData().weekdaysShort(this,t)}),Y("dddd",0,0,function(t){return this.localeData().weekdays(this,t)}),Y("e",0,0,"weekday"),Y("E",0,0,"isoWeekday"),L("day","d"),L("weekday","e"),L("isoWeekday","E"),G("d",Tn),G("e",Tn),G("E",Tn),G("dd",function(t,e){return e.weekdaysMinRegex(t)}),G("ddd",function(t,e){return e.weekdaysShortRegex(t)}),G("dddd",function(t,e){return e.weekdaysRegex(t)}),K(["dd","ddd","dddd"],function(t,e,i,n){var s=i._locale.weekdaysParse(t,n,i._strict)
null!=s?e.d=s:u(i).invalidWeekday=t}),K(["d","e","E"],function(t,e,i,n){e[n]=v(t)})
var vs="Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),ys="Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),_s="Su_Mo_Tu_We_Th_Fr_Sa".split("_"),bs=Hn,ws=Hn,xs=Hn
Y("DDD",["DDDD",3],"DDDo","dayOfYear"),L("dayOfYear","DDD"),G("DDD",Mn),G("DDDD",xn),Z(["DDD","DDDD"],function(t,e,i){i._dayOfYear=v(t)}),Y("H",["HH",2],0,"hour"),Y("h",["hh",2],0,pi),Y("k",["kk",2],0,mi),Y("hmm",0,0,function(){return""+pi.apply(this)+R(this.minutes(),2)}),Y("hmmss",0,0,function(){return""+pi.apply(this)+R(this.minutes(),2)+R(this.seconds(),2)}),Y("Hmm",0,0,function(){return""+this.hours()+R(this.minutes(),2)}),Y("Hmmss",0,0,function(){return""+this.hours()+R(this.minutes(),2)+R(this.seconds(),2)}),gi("a",!0),gi("A",!1),L("hour","h"),G("a",vi),G("A",vi),G("H",Tn),G("h",Tn),G("HH",Tn,wn),G("hh",Tn,wn),G("hmm",Cn),G("hmmss",Sn),G("Hmm",Cn),G("Hmmss",Sn),Z(["H","HH"],Rn),Z(["a","A"],function(t,e,i){i._isPm=i._locale.isPM(t),i._meridiem=t}),Z(["h","hh"],function(t,e,i){e[Rn]=v(t),u(i).bigHour=!0}),Z("hmm",function(t,e,i){var n=t.length-2
e[Rn]=v(t.substr(0,n)),e[Yn]=v(t.substr(n)),u(i).bigHour=!0}),Z("hmmss",function(t,e,i){var n=t.length-4,s=t.length-2
e[Rn]=v(t.substr(0,n)),e[Yn]=v(t.substr(n,2)),e[qn]=v(t.substr(s)),u(i).bigHour=!0}),Z("Hmm",function(t,e,i){var n=t.length-2
e[Rn]=v(t.substr(0,n)),e[Yn]=v(t.substr(n))}),Z("Hmmss",function(t,e,i){var n=t.length-4,s=t.length-2
e[Rn]=v(t.substr(0,n)),e[Yn]=v(t.substr(n,2)),e[qn]=v(t.substr(s))})
var ks=/[ap]\.?m?\.?/i,Ds=W("Hours",!0)
Y("m",["mm",2],0,"minute"),L("minute","m"),G("m",Tn),G("mm",Tn,wn),Z(["m","mm"],Yn)
var Ts=W("Minutes",!1)
Y("s",["ss",2],0,"second"),L("second","s"),G("s",Tn),G("ss",Tn,wn),Z(["s","ss"],qn)
var Cs=W("Seconds",!1)
Y("S",0,0,function(){return~~(this.millisecond()/100)}),Y(0,["SS",2],0,function(){return~~(this.millisecond()/10)}),Y(0,["SSS",3],0,"millisecond"),Y(0,["SSSS",4],0,function(){return 10*this.millisecond()}),Y(0,["SSSSS",5],0,function(){return 100*this.millisecond()}),Y(0,["SSSSSS",6],0,function(){return 1e3*this.millisecond()}),Y(0,["SSSSSSS",7],0,function(){return 1e4*this.millisecond()}),Y(0,["SSSSSSSS",8],0,function(){return 1e5*this.millisecond()}),Y(0,["SSSSSSSSS",9],0,function(){return 1e6*this.millisecond()}),L("millisecond","ms"),G("S",Mn,bn),G("SS",Mn,wn),G("SSS",Mn,xn)
var Ss
for(Ss="SSSS";Ss.length<=9;Ss+="S")G(Ss,An)
for(Ss="S";Ss.length<=9;Ss+="S")Z(Ss,bi)
var Ms=W("Milliseconds",!1)
Y("z",0,0,"zoneAbbr"),Y("zz",0,0,"zoneName")
var Es=p.prototype
Es.add=ds,Es.calendar=he,Es.clone=ce,Es.diff=ye,Es.endOf=Ne,Es.format=xe,Es.from=ke,Es.fromNow=De,Es.to=Te,Es.toNow=Ce,Es.get=U,Es.invalidAt=Fe,Es.isAfter=de,Es.isBefore=fe,Es.isBetween=pe,Es.isSame=me,Es.isSameOrAfter=ge,Es.isSameOrBefore=ve,Es.isValid=je,Es.lang=ps,Es.locale=Se,Es.localeData=Me,Es.max=as,Es.min=os,Es.parsingFlags=We,Es.set=U,Es.startOf=Ee,Es.subtract=fs,Es.toArray=Ie,Es.toObject=Le,Es.toDate=Pe,Es.toISOString=we,Es.toJSON=He,Es.toString=be,Es.unix=Oe,Es.valueOf=Ae,Es.creationData=$e,Es.year=rs,Es.isLeapYear=_t,Es.weekYear=Re,Es.isoWeekYear=Ye,Es.quarter=Es.quarters=Ge,Es.month=at,Es.daysInMonth=lt,Es.week=Es.weeks=Ze,Es.isoWeek=Es.isoWeeks=Ke,Es.weeksInYear=Ve,Es.isoWeeksInYear=qe,Es.date=gs,Es.day=Es.days=oi,Es.weekday=ai,Es.isoWeekday=li,Es.dayOfYear=fi,Es.hour=Es.hours=Ds,Es.minute=Es.minutes=Ts,Es.second=Es.seconds=Cs,Es.millisecond=Es.milliseconds=Ms,Es.utcOffset=Bt,Es.utc=Gt,Es.local=Xt,Es.parseZone=Jt,Es.hasAlignedHourOffset=Qt,Es.isDST=Zt,Es.isDSTShifted=Kt,Es.isLocal=te,Es.isUtcOffset=ee,Es.isUtc=ie,Es.isUTC=ie,Es.zoneAbbr=wi,Es.zoneName=xi,Es.dates=b("dates accessor is deprecated. Use date instead.",gs),Es.months=b("months accessor is deprecated. Use month instead",at),Es.years=b("years accessor is deprecated. Use year instead",rs),Es.zone=b("moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779",zt)
var Ns=Es,As={sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"},Os={LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},Ps="Invalid date",Is="%d",Ls=/\d{1,2}/,Hs={future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"},js=C.prototype
js._calendar=As,js.calendar=Ti,js._longDateFormat=Os,js.longDateFormat=Ci,js._invalidDate=Ps,js.invalidDate=Si,js._ordinal=Is,js.ordinal=Mi,js._ordinalParse=Ls,js.preparse=Ei,js.postformat=Ei,js._relativeTime=Hs,js.relativeTime=Ni,js.pastFuture=Ai,js.set=D,js.months=it,js._months=Xn,js.monthsShort=nt,js._monthsShort=Jn,js.monthsParse=rt,js._monthsRegex=Zn,js.monthsRegex=ht,js._monthsShortRegex=Qn,js.monthsShortRegex=ut,js.week=Xe,js._week=ms,js.firstDayOfYear=Qe,js.firstDayOfWeek=Je,js.weekdays=ei,js._weekdays=vs,js.weekdaysMin=ni,js._weekdaysMin=_s,js.weekdaysShort=ii,js._weekdaysShort=ys,js.weekdaysParse=ri,js._weekdaysRegex=bs,js.weekdaysRegex=ui,js._weekdaysShortRegex=ws,js.weekdaysShortRegex=hi,js._weekdaysMinRegex=xs,js.weekdaysMinRegex=ci,js.isPM=yi,js._meridiemParse=ks,js.meridiem=_i,N("en",{ordinalParse:/\d{1,2}(th|st|nd|rd)/,ordinal:function(t){var e=t%10,i=1===v(t%100/10)?"th":1===e?"st":2===e?"nd":3===e?"rd":"th"
return t+i}}),t.lang=b("moment.lang is deprecated. Use moment.locale instead.",N),t.langData=b("moment.langData is deprecated. Use moment.localeData instead.",P)
var Ws=Math.abs,Fs=Ji("ms"),$s=Ji("s"),Us=Ji("m"),Rs=Ji("h"),Ys=Ji("d"),qs=Ji("w"),Vs=Ji("M"),Bs=Ji("y"),zs=Zi("milliseconds"),Gs=Zi("seconds"),Xs=Zi("minutes"),Js=Zi("hours"),Qs=Zi("days"),Zs=Zi("months"),Ks=Zi("years"),tr=Math.round,er={s:45,m:45,h:22,d:26,M:11},ir=Math.abs,nr=$t.prototype
nr.abs=$i,nr.add=Ri,nr.subtract=Yi,nr.as=Gi,nr.asMilliseconds=Fs,nr.asSeconds=$s,nr.asMinutes=Us,nr.asHours=Rs,nr.asDays=Ys,nr.asWeeks=qs,nr.asMonths=Vs,nr.asYears=Bs,nr.valueOf=Xi,nr._bubble=Vi,nr.get=Qi,nr.milliseconds=zs,nr.seconds=Gs,nr.minutes=Xs,nr.hours=Js,nr.days=Qs,nr.weeks=Ki,nr.months=Zs,nr.years=Ks,nr.humanize=sn,nr.toISOString=rn,nr.toString=rn,nr.toJSON=rn,nr.locale=Se,nr.localeData=Me,nr.toIsoString=b("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)",rn),nr.lang=ps,Y("X",0,0,"unix"),Y("x",0,0,"valueOf"),G("x",On),G("X",Ln),Z("X",function(t,e,i){i._d=new Date(1e3*parseFloat(t,10))}),Z("x",function(t,e,i){i._d=new Date(v(t))}),t.version="2.13.0",e(Ht),t.fn=Ns,t.min=Wt,t.max=Ft,t.now=ls,t.utc=a,t.unix=ki,t.months=Li,t.isDate=n,t.locale=N,t.invalid=c,t.duration=ne,t.isMoment=m,t.weekdays=ji,t.parseZone=Di,t.localeData=P,t.isDuration=Ut,t.monthsShort=Hi,t.weekdaysMin=Fi,t.defineLocale=A,t.updateLocale=O,t.locales=I,t.weekdaysShort=Wi,t.normalizeUnits=H,t.relativeTimeThreshold=nn,t.prototype=Ns
var sr=t
return sr}),function(t){if("function"==typeof define&&define.amd)define(t)
else if("object"==typeof exports)module.exports=t()
else{var e=window.Cookies,i=window.Cookies=t()
i.noConflict=function(){return window.Cookies=e,i}}}(function(){function t(){for(var t=0,e={};t<arguments.length;t++){var i=arguments[t]
for(var n in i)e[n]=i[n]}return e}function e(i){function n(e,s,r){var o
if("undefined"!=typeof document){if(arguments.length>1){if(r=t({path:"/"},n.defaults,r),"number"==typeof r.expires){var a=new Date
a.setMilliseconds(a.getMilliseconds()+864e5*r.expires),r.expires=a}try{o=JSON.stringify(s),/^[\{\[]/.test(o)&&(s=o)}catch(t){}return s=i.write?i.write(s,e):encodeURIComponent(String(s)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g,decodeURIComponent),e=encodeURIComponent(String(e)),e=e.replace(/%(23|24|26|2B|5E|60|7C)/g,decodeURIComponent),e=e.replace(/[\(\)]/g,escape),document.cookie=[e,"=",s,r.expires&&"; expires="+r.expires.toUTCString(),r.path&&"; path="+r.path,r.domain&&"; domain="+r.domain,r.secure?"; secure":""].join("")}e||(o={})
for(var l=document.cookie?document.cookie.split("; "):[],u=/(%[0-9A-Z]{2})+/g,h=0;h<l.length;h++){var c=l[h].split("="),d=c.slice(1).join("=")
'"'===d.charAt(0)&&(d=d.slice(1,-1))
try{var f=c[0].replace(u,decodeURIComponent)
if(d=i.read?i.read(d,f):i(d,f)||d.replace(u,decodeURIComponent),this.json)try{d=JSON.parse(d)}catch(t){}if(e===f){o=d
break}e||(o[f]=d)}catch(t){}}return o}}return n.set=n,n.get=function(t){return n(t)},n.getJSON=function(){return n.apply({json:!0},[].slice.call(arguments))},n.defaults={},n.remove=function(e,i){n(e,"",t(i,{expires:-1}))},n.withConverter=e,n}return e(function(){})}),function(t){"function"==typeof define&&define.amd?define(["jquery"],t):t(jQuery)}(function(t){t.ui=t.ui||{}
var e=(t.ui.version="1.12.1",0),i=Array.prototype.slice
t.cleanData=function(e){return function(i){var n,s,r
for(r=0;null!=(s=i[r]);r++)try{n=t._data(s,"events"),n&&n.remove&&t(s).triggerHandler("remove")}catch(t){}e(i)}}(t.cleanData),t.widget=function(e,i,n){var s,r,o,a={},l=e.split(".")[0]
e=e.split(".")[1]
var u=l+"-"+e
return n||(n=i,i=t.Widget),t.isArray(n)&&(n=t.extend.apply(null,[{}].concat(n))),t.expr[":"][u.toLowerCase()]=function(e){return!!t.data(e,u)},t[l]=t[l]||{},s=t[l][e],r=t[l][e]=function(t,e){return this._createWidget?void(arguments.length&&this._createWidget(t,e)):new r(t,e)},t.extend(r,s,{version:n.version,_proto:t.extend({},n),_childConstructors:[]}),o=new i,o.options=t.widget.extend({},o.options),t.each(n,function(e,n){return t.isFunction(n)?void(a[e]=function(){function t(){return i.prototype[e].apply(this,arguments)}function s(t){return i.prototype[e].apply(this,t)}return function(){var e,i=this._super,r=this._superApply
return this._super=t,this._superApply=s,e=n.apply(this,arguments),this._super=i,this._superApply=r,e}}()):void(a[e]=n)}),r.prototype=t.widget.extend(o,{widgetEventPrefix:s?o.widgetEventPrefix||e:e},a,{constructor:r,namespace:l,widgetName:e,widgetFullName:u}),s?(t.each(s._childConstructors,function(e,i){var n=i.prototype
t.widget(n.namespace+"."+n.widgetName,r,i._proto)}),delete s._childConstructors):i._childConstructors.push(r),t.widget.bridge(e,r),r},t.widget.extend=function(e){for(var n,s,r=i.call(arguments,1),o=0,a=r.length;o<a;o++)for(n in r[o])s=r[o][n],r[o].hasOwnProperty(n)&&void 0!==s&&(t.isPlainObject(s)?e[n]=t.isPlainObject(e[n])?t.widget.extend({},e[n],s):t.widget.extend({},s):e[n]=s)
return e},t.widget.bridge=function(e,n){var s=n.prototype.widgetFullName||e
t.fn[e]=function(r){var o="string"==typeof r,a=i.call(arguments,1),l=this
return o?this.length||"instance"!==r?this.each(function(){var i,n=t.data(this,s)
return"instance"===r?(l=n,!1):n?t.isFunction(n[r])&&"_"!==r.charAt(0)?(i=n[r].apply(n,a),i!==n&&void 0!==i?(l=i&&i.jquery?l.pushStack(i.get()):i,!1):void 0):t.error("no such method '"+r+"' for "+e+" widget instance"):t.error("cannot call methods on "+e+" prior to initialization; attempted to call method '"+r+"'")}):l=void 0:(a.length&&(r=t.widget.extend.apply(null,[r].concat(a))),this.each(function(){var e=t.data(this,s)
e?(e.option(r||{}),e._init&&e._init()):t.data(this,s,new n(r,this))})),l}},t.Widget=function(){},t.Widget._childConstructors=[],t.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{classes:{},disabled:!1,create:null},_createWidget:function(i,n){n=t(n||this.defaultElement||this)[0],this.element=t(n),this.uuid=e++,this.eventNamespace="."+this.widgetName+this.uuid,this.bindings=t(),this.hoverable=t(),this.focusable=t(),this.classesElementLookup={},n!==this&&(t.data(n,this.widgetFullName,this),this._on(!0,this.element,{remove:function(t){t.target===n&&this.destroy()}}),this.document=t(n.style?n.ownerDocument:n.document||n),this.window=t(this.document[0].defaultView||this.document[0].parentWindow)),this.options=t.widget.extend({},this.options,this._getCreateOptions(),i),this._create(),this.options.disabled&&this._setOptionDisabled(this.options.disabled),this._trigger("create",null,this._getCreateEventData()),this._init()},_getCreateOptions:function(){return{}},_getCreateEventData:t.noop,_create:t.noop,_init:t.noop,destroy:function(){var e=this
this._destroy(),t.each(this.classesElementLookup,function(t,i){e._removeClass(i,t)}),this.element.off(this.eventNamespace).removeData(this.widgetFullName),this.widget().off(this.eventNamespace).removeAttr("aria-disabled"),this.bindings.off(this.eventNamespace)},_destroy:t.noop,widget:function(){return this.element},option:function(e,i){var n,s,r,o=e
if(0===arguments.length)return t.widget.extend({},this.options)
if("string"==typeof e)if(o={},n=e.split("."),e=n.shift(),n.length){for(s=o[e]=t.widget.extend({},this.options[e]),r=0;r<n.length-1;r++)s[n[r]]=s[n[r]]||{},s=s[n[r]]
if(e=n.pop(),1===arguments.length)return void 0===s[e]?null:s[e]
s[e]=i}else{if(1===arguments.length)return void 0===this.options[e]?null:this.options[e]
o[e]=i}return this._setOptions(o),this},_setOptions:function(t){var e
for(e in t)this._setOption(e,t[e])
return this},_setOption:function(t,e){return"classes"===t&&this._setOptionClasses(e),this.options[t]=e,"disabled"===t&&this._setOptionDisabled(e),this},_setOptionClasses:function(e){var i,n,s
for(i in e)s=this.classesElementLookup[i],e[i]!==this.options.classes[i]&&s&&s.length&&(n=t(s.get()),this._removeClass(s,i),n.addClass(this._classes({element:n,keys:i,classes:e,add:!0})))},_setOptionDisabled:function(t){this._toggleClass(this.widget(),this.widgetFullName+"-disabled",null,!!t),t&&(this._removeClass(this.hoverable,null,"ui-state-hover"),this._removeClass(this.focusable,null,"ui-state-focus"))},enable:function(){return this._setOptions({disabled:!1})},disable:function(){return this._setOptions({disabled:!0})},_classes:function(e){function i(i,r){var o,a
for(a=0;a<i.length;a++)o=s.classesElementLookup[i[a]]||t(),o=t(e.add?t.unique(o.get().concat(e.element.get())):o.not(e.element).get()),s.classesElementLookup[i[a]]=o,n.push(i[a]),r&&e.classes[i[a]]&&n.push(e.classes[i[a]])}var n=[],s=this
return e=t.extend({element:this.element,classes:this.options.classes||{}},e),this._on(e.element,{remove:"_untrackClassesElement"}),e.keys&&i(e.keys.match(/\S+/g)||[],!0),e.extra&&i(e.extra.match(/\S+/g)||[]),n.join(" ")},_untrackClassesElement:function(e){var i=this
t.each(i.classesElementLookup,function(n,s){t.inArray(e.target,s)!==-1&&(i.classesElementLookup[n]=t(s.not(e.target).get()))})},_removeClass:function(t,e,i){return this._toggleClass(t,e,i,!1)},_addClass:function(t,e,i){return this._toggleClass(t,e,i,!0)},_toggleClass:function(t,e,i,n){n="boolean"==typeof n?n:i
var s="string"==typeof t||null===t,r={extra:s?e:i,keys:s?t:e,element:s?this.element:t,add:n}
return r.element.toggleClass(this._classes(r),n),this},_on:function(e,i,n){var s,r=this
"boolean"!=typeof e&&(n=i,i=e,e=!1),n?(i=s=t(i),this.bindings=this.bindings.add(i)):(n=i,i=this.element,s=this.widget()),t.each(n,function(n,o){function a(){if(e||r.options.disabled!==!0&&!t(this).hasClass("ui-state-disabled"))return("string"==typeof o?r[o]:o).apply(r,arguments)}"string"!=typeof o&&(a.guid=o.guid=o.guid||a.guid||t.guid++)
var l=n.match(/^([\w:-]*)\s*(.*)$/),u=l[1]+r.eventNamespace,h=l[2]
h?s.on(u,h,a):i.on(u,a)})},_off:function(e,i){i=(i||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,e.off(i).off(i),this.bindings=t(this.bindings.not(e).get()),this.focusable=t(this.focusable.not(e).get()),this.hoverable=t(this.hoverable.not(e).get())},_delay:function(t,e){function i(){return("string"==typeof t?n[t]:t).apply(n,arguments)}var n=this
return setTimeout(i,e||0)},_hoverable:function(e){this.hoverable=this.hoverable.add(e),this._on(e,{mouseenter:function(e){this._addClass(t(e.currentTarget),null,"ui-state-hover")},mouseleave:function(e){this._removeClass(t(e.currentTarget),null,"ui-state-hover")}})},_focusable:function(e){this.focusable=this.focusable.add(e),this._on(e,{focusin:function(e){this._addClass(t(e.currentTarget),null,"ui-state-focus")},focusout:function(e){this._removeClass(t(e.currentTarget),null,"ui-state-focus")}})},_trigger:function(e,i,n){var s,r,o=this.options[e]
if(n=n||{},i=t.Event(i),i.type=(e===this.widgetEventPrefix?e:this.widgetEventPrefix+e).toLowerCase(),i.target=this.element[0],r=i.originalEvent)for(s in r)s in i||(i[s]=r[s])
return this.element.trigger(i,n),!(t.isFunction(o)&&o.apply(this.element[0],[i].concat(n))===!1||i.isDefaultPrevented())}},t.each({show:"fadeIn",hide:"fadeOut"},function(e,i){t.Widget.prototype["_"+e]=function(n,s,r){"string"==typeof s&&(s={effect:s})
var o,a=s?s===!0||"number"==typeof s?i:s.effect||i:e
s=s||{},"number"==typeof s&&(s={duration:s}),o=!t.isEmptyObject(s),s.complete=r,s.delay&&n.delay(s.delay),o&&t.effects&&t.effects.effect[a]?n[e](s):a!==e&&n[a]?n[a](s.duration,s.easing,r):n.queue(function(i){t(this)[e](),r&&r.call(n[0]),i()})}})
t.widget
!function(){function e(t,e,i){return[parseFloat(t[0])*(c.test(t[0])?e/100:1),parseFloat(t[1])*(c.test(t[1])?i/100:1)]}function i(e,i){return parseInt(t.css(e,i),10)||0}function n(e){var i=e[0]
return 9===i.nodeType?{width:e.width(),height:e.height(),offset:{top:0,left:0}}:t.isWindow(i)?{width:e.width(),height:e.height(),offset:{top:e.scrollTop(),left:e.scrollLeft()}}:i.preventDefault?{width:0,height:0,offset:{top:i.pageY,left:i.pageX}}:{width:e.outerWidth(),height:e.outerHeight(),offset:e.offset()}}var s,r=Math.max,o=Math.abs,a=/left|center|right/,l=/top|center|bottom/,u=/[\+\-]\d+(\.[\d]+)?%?/,h=/^\w+/,c=/%$/,d=t.fn.position
t.position={scrollbarWidth:function(){if(void 0!==s)return s
var e,i,n=t("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),r=n.children()[0]
return t("body").append(n),e=r.offsetWidth,n.css("overflow","scroll"),i=r.offsetWidth,e===i&&(i=n[0].clientWidth),n.remove(),s=e-i},getScrollInfo:function(e){var i=e.isWindow||e.isDocument?"":e.element.css("overflow-x"),n=e.isWindow||e.isDocument?"":e.element.css("overflow-y"),s="scroll"===i||"auto"===i&&e.width<e.element[0].scrollWidth,r="scroll"===n||"auto"===n&&e.height<e.element[0].scrollHeight
return{width:r?t.position.scrollbarWidth():0,height:s?t.position.scrollbarWidth():0}},getWithinInfo:function(e){var i=t(e||window),n=t.isWindow(i[0]),s=!!i[0]&&9===i[0].nodeType,r=!n&&!s
return{element:i,isWindow:n,isDocument:s,offset:r?t(e).offset():{left:0,top:0},scrollLeft:i.scrollLeft(),scrollTop:i.scrollTop(),width:i.outerWidth(),height:i.outerHeight()}}},t.fn.position=function(s){if(!s||!s.of)return d.apply(this,arguments)
s=t.extend({},s)
var c,f,p,m,g,v,y=t(s.of),_=t.position.getWithinInfo(s.within),b=t.position.getScrollInfo(_),w=(s.collision||"flip").split(" "),x={}
return v=n(y),y[0].preventDefault&&(s.at="left top"),f=v.width,p=v.height,m=v.offset,g=t.extend({},m),t.each(["my","at"],function(){var t,e,i=(s[this]||"").split(" ")
1===i.length&&(i=a.test(i[0])?i.concat(["center"]):l.test(i[0])?["center"].concat(i):["center","center"]),i[0]=a.test(i[0])?i[0]:"center",i[1]=l.test(i[1])?i[1]:"center",t=u.exec(i[0]),e=u.exec(i[1]),x[this]=[t?t[0]:0,e?e[0]:0],s[this]=[h.exec(i[0])[0],h.exec(i[1])[0]]}),1===w.length&&(w[1]=w[0]),"right"===s.at[0]?g.left+=f:"center"===s.at[0]&&(g.left+=f/2),"bottom"===s.at[1]?g.top+=p:"center"===s.at[1]&&(g.top+=p/2),c=e(x.at,f,p),g.left+=c[0],g.top+=c[1],this.each(function(){var n,a,l=t(this),u=l.outerWidth(),h=l.outerHeight(),d=i(this,"marginLeft"),v=i(this,"marginTop"),k=u+d+i(this,"marginRight")+b.width,D=h+v+i(this,"marginBottom")+b.height,T=t.extend({},g),C=e(x.my,l.outerWidth(),l.outerHeight())
"right"===s.my[0]?T.left-=u:"center"===s.my[0]&&(T.left-=u/2),"bottom"===s.my[1]?T.top-=h:"center"===s.my[1]&&(T.top-=h/2),T.left+=C[0],T.top+=C[1],n={marginLeft:d,marginTop:v},t.each(["left","top"],function(e,i){t.ui.position[w[e]]&&t.ui.position[w[e]][i](T,{targetWidth:f,targetHeight:p,elemWidth:u,elemHeight:h,collisionPosition:n,collisionWidth:k,collisionHeight:D,offset:[c[0]+C[0],c[1]+C[1]],my:s.my,at:s.at,within:_,elem:l})}),s.using&&(a=function(t){var e=m.left-T.left,i=e+f-u,n=m.top-T.top,a=n+p-h,c={target:{element:y,left:m.left,top:m.top,width:f,height:p},element:{element:l,left:T.left,top:T.top,width:u,height:h},horizontal:i<0?"left":e>0?"right":"center",vertical:a<0?"top":n>0?"bottom":"middle"}
f<u&&o(e+i)<f&&(c.horizontal="center"),p<h&&o(n+a)<p&&(c.vertical="middle"),r(o(e),o(i))>r(o(n),o(a))?c.important="horizontal":c.important="vertical",s.using.call(this,t,c)}),l.offset(t.extend(T,{using:a}))})},t.ui.position={fit:{left:function(t,e){var i,n=e.within,s=n.isWindow?n.scrollLeft:n.offset.left,o=n.width,a=t.left-e.collisionPosition.marginLeft,l=s-a,u=a+e.collisionWidth-o-s
e.collisionWidth>o?l>0&&u<=0?(i=t.left+l+e.collisionWidth-o-s,t.left+=l-i):u>0&&l<=0?t.left=s:l>u?t.left=s+o-e.collisionWidth:t.left=s:l>0?t.left+=l:u>0?t.left-=u:t.left=r(t.left-a,t.left)},top:function(t,e){var i,n=e.within,s=n.isWindow?n.scrollTop:n.offset.top,o=e.within.height,a=t.top-e.collisionPosition.marginTop,l=s-a,u=a+e.collisionHeight-o-s
e.collisionHeight>o?l>0&&u<=0?(i=t.top+l+e.collisionHeight-o-s,t.top+=l-i):u>0&&l<=0?t.top=s:l>u?t.top=s+o-e.collisionHeight:t.top=s:l>0?t.top+=l:u>0?t.top-=u:t.top=r(t.top-a,t.top)}},flip:{left:function(t,e){var i,n,s=e.within,r=s.offset.left+s.scrollLeft,a=s.width,l=s.isWindow?s.scrollLeft:s.offset.left,u=t.left-e.collisionPosition.marginLeft,h=u-l,c=u+e.collisionWidth-a-l,d="left"===e.my[0]?-e.elemWidth:"right"===e.my[0]?e.elemWidth:0,f="left"===e.at[0]?e.targetWidth:"right"===e.at[0]?-e.targetWidth:0,p=-2*e.offset[0]
h<0?(i=t.left+d+f+p+e.collisionWidth-a-r,(i<0||i<o(h))&&(t.left+=d+f+p)):c>0&&(n=t.left-e.collisionPosition.marginLeft+d+f+p-l,(n>0||o(n)<c)&&(t.left+=d+f+p))},top:function(t,e){var i,n,s=e.within,r=s.offset.top+s.scrollTop,a=s.height,l=s.isWindow?s.scrollTop:s.offset.top,u=t.top-e.collisionPosition.marginTop,h=u-l,c=u+e.collisionHeight-a-l,d="top"===e.my[1],f=d?-e.elemHeight:"bottom"===e.my[1]?e.elemHeight:0,p="top"===e.at[1]?e.targetHeight:"bottom"===e.at[1]?-e.targetHeight:0,m=-2*e.offset[1]
h<0?(n=t.top+f+p+m+e.collisionHeight-a-r,(n<0||n<o(h))&&(t.top+=f+p+m)):c>0&&(i=t.top-e.collisionPosition.marginTop+f+p+m-l,(i>0||o(i)<c)&&(t.top+=f+p+m))}},flipfit:{left:function(){t.ui.position.flip.left.apply(this,arguments),t.ui.position.fit.left.apply(this,arguments)},top:function(){t.ui.position.flip.top.apply(this,arguments),t.ui.position.fit.top.apply(this,arguments)}}}}()
var n=(t.ui.position,t.extend(t.expr[":"],{data:t.expr.createPseudo?t.expr.createPseudo(function(e){return function(i){return!!t.data(i,e)}}):function(e,i,n){return!!t.data(e,n[3])}}),t.ui.keyCode={BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38},t.fn.scrollParent=function(e){var i=this.css("position"),n="absolute"===i,s=e?/(auto|scroll|hidden)/:/(auto|scroll)/,r=this.parents().filter(function(){var e=t(this)
return(!n||"static"!==e.css("position"))&&s.test(e.css("overflow")+e.css("overflow-y")+e.css("overflow-x"))}).eq(0)
return"fixed"!==i&&r.length?r:t(this[0].ownerDocument||document)},t.fn.extend({uniqueId:function(){var t=0
return function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++t)})}}(),removeUniqueId:function(){return this.each(function(){/^ui-id-\d+$/.test(this.id)&&t(this).removeAttr("id")})}}),t.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()),!1)
t(document).on("mouseup",function(){n=!1})
t.widget("ui.mouse",{version:"1.12.1",options:{cancel:"input, textarea, button, select, option",distance:1,delay:0},_mouseInit:function(){var e=this
this.element.on("mousedown."+this.widgetName,function(t){return e._mouseDown(t)}).on("click."+this.widgetName,function(i){if(!0===t.data(i.target,e.widgetName+".preventClickEvent"))return t.removeData(i.target,e.widgetName+".preventClickEvent"),i.stopImmediatePropagation(),!1}),this.started=!1},_mouseDestroy:function(){this.element.off("."+this.widgetName),this._mouseMoveDelegate&&this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate)},_mouseDown:function(e){if(!n){this._mouseMoved=!1,this._mouseStarted&&this._mouseUp(e),this._mouseDownEvent=e
var i=this,s=1===e.which,r=!("string"!=typeof this.options.cancel||!e.target.nodeName)&&t(e.target).closest(this.options.cancel).length
return!(s&&!r&&this._mouseCapture(e))||(this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout(function(){i.mouseDelayMet=!0},this.options.delay)),this._mouseDistanceMet(e)&&this._mouseDelayMet(e)&&(this._mouseStarted=this._mouseStart(e)!==!1,!this._mouseStarted)?(e.preventDefault(),!0):(!0===t.data(e.target,this.widgetName+".preventClickEvent")&&t.removeData(e.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(t){return i._mouseMove(t)},this._mouseUpDelegate=function(t){return i._mouseUp(t)},this.document.on("mousemove."+this.widgetName,this._mouseMoveDelegate).on("mouseup."+this.widgetName,this._mouseUpDelegate),e.preventDefault(),n=!0,!0))}},_mouseMove:function(e){if(this._mouseMoved){if(t.ui.ie&&(!document.documentMode||document.documentMode<9)&&!e.button)return this._mouseUp(e)
if(!e.which)if(e.originalEvent.altKey||e.originalEvent.ctrlKey||e.originalEvent.metaKey||e.originalEvent.shiftKey)this.ignoreMissingWhich=!0
else if(!this.ignoreMissingWhich)return this._mouseUp(e)}return(e.which||e.button)&&(this._mouseMoved=!0),this._mouseStarted?(this._mouseDrag(e),e.preventDefault()):(this._mouseDistanceMet(e)&&this._mouseDelayMet(e)&&(this._mouseStarted=this._mouseStart(this._mouseDownEvent,e)!==!1,this._mouseStarted?this._mouseDrag(e):this._mouseUp(e)),!this._mouseStarted)},_mouseUp:function(e){this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,e.target===this._mouseDownEvent.target&&t.data(e.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(e)),this._mouseDelayTimer&&(clearTimeout(this._mouseDelayTimer),delete this._mouseDelayTimer),this.ignoreMissingWhich=!1,n=!1,e.preventDefault()},_mouseDistanceMet:function(t){return Math.max(Math.abs(this._mouseDownEvent.pageX-t.pageX),Math.abs(this._mouseDownEvent.pageY-t.pageY))>=this.options.distance},_mouseDelayMet:function(){return this.mouseDelayMet},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return!0}}),t.widget("ui.sortable",t.ui.mouse,{version:"1.12.1",widgetEventPrefix:"sort",ready:!1,options:{appendTo:"parent",axis:!1,connectWith:!1,containment:!1,cursor:"auto",cursorAt:!1,dropOnEmpty:!0,forcePlaceholderSize:!1,forceHelperSize:!1,grid:!1,handle:!1,helper:"original",items:"> *",opacity:!1,placeholder:!1,revert:!1,scroll:!0,scrollSensitivity:20,scrollSpeed:20,scope:"default",tolerance:"intersect",zIndex:1e3,activate:null,beforeStop:null,change:null,deactivate:null,out:null,over:null,receive:null,remove:null,sort:null,start:null,stop:null,update:null},_isOverAxis:function(t,e,i){return t>=e&&t<e+i},_isFloating:function(t){return/left|right/.test(t.css("float"))||/inline|table-cell/.test(t.css("display"))},_create:function(){this.containerCache={},this._addClass("ui-sortable"),this.refresh(),this.offset=this.element.offset(),this._mouseInit(),this._setHandleClassName(),this.ready=!0},_setOption:function(t,e){this._super(t,e),"handle"===t&&this._setHandleClassName()},_setHandleClassName:function(){var e=this
this._removeClass(this.element.find(".ui-sortable-handle"),"ui-sortable-handle"),t.each(this.items,function(){e._addClass(this.instance.options.handle?this.item.find(this.instance.options.handle):this.item,"ui-sortable-handle")})},_destroy:function(){this._mouseDestroy()
for(var t=this.items.length-1;t>=0;t--)this.items[t].item.removeData(this.widgetName+"-item")
return this},_mouseCapture:function(e,i){var n=null,s=!1,r=this
return!this.reverting&&(!this.options.disabled&&"static"!==this.options.type&&(this._refreshItems(e),t(e.target).parents().each(function(){if(t.data(this,r.widgetName+"-item")===r)return n=t(this),!1}),t.data(e.target,r.widgetName+"-item")===r&&(n=t(e.target)),!!n&&(!(this.options.handle&&!i&&(t(this.options.handle,n).find("*").addBack().each(function(){this===e.target&&(s=!0)}),!s))&&(this.currentItem=n,this._removeCurrentsFromItems(),!0))))},_mouseStart:function(e,i,n){var s,r,o=this.options
if(this.currentContainer=this,this.refreshPositions(),this.helper=this._createHelper(e),this._cacheHelperProportions(),this._cacheMargins(),this.scrollParent=this.helper.scrollParent(),this.offset=this.currentItem.offset(),this.offset={top:this.offset.top-this.margins.top,left:this.offset.left-this.margins.left},t.extend(this.offset,{click:{left:e.pageX-this.offset.left,top:e.pageY-this.offset.top},parent:this._getParentOffset(),relative:this._getRelativeOffset()}),this.helper.css("position","absolute"),this.cssPosition=this.helper.css("position"),this.originalPosition=this._generatePosition(e),this.originalPageX=e.pageX,this.originalPageY=e.pageY,o.cursorAt&&this._adjustOffsetFromHelper(o.cursorAt),this.domPosition={prev:this.currentItem.prev()[0],parent:this.currentItem.parent()[0]},this.helper[0]!==this.currentItem[0]&&this.currentItem.hide(),this._createPlaceholder(),o.containment&&this._setContainment(),o.cursor&&"auto"!==o.cursor&&(r=this.document.find("body"),this.storedCursor=r.css("cursor"),r.css("cursor",o.cursor),this.storedStylesheet=t("<style>*{ cursor: "+o.cursor+" !important; }</style>").appendTo(r)),o.opacity&&(this.helper.css("opacity")&&(this._storedOpacity=this.helper.css("opacity")),this.helper.css("opacity",o.opacity)),o.zIndex&&(this.helper.css("zIndex")&&(this._storedZIndex=this.helper.css("zIndex")),this.helper.css("zIndex",o.zIndex)),this.scrollParent[0]!==this.document[0]&&"HTML"!==this.scrollParent[0].tagName&&(this.overflowOffset=this.scrollParent.offset()),this._trigger("start",e,this._uiHash()),this._preserveHelperProportions||this._cacheHelperProportions(),!n)for(s=this.containers.length-1;s>=0;s--)this.containers[s]._trigger("activate",e,this._uiHash(this))
return t.ui.ddmanager&&(t.ui.ddmanager.current=this),t.ui.ddmanager&&!o.dropBehaviour&&t.ui.ddmanager.prepareOffsets(this,e),this.dragging=!0,this._addClass(this.helper,"ui-sortable-helper"),this._mouseDrag(e),!0},_mouseDrag:function(e){var i,n,s,r,o=this.options,a=!1
for(this.position=this._generatePosition(e),this.positionAbs=this._convertPositionTo("absolute"),this.lastPositionAbs||(this.lastPositionAbs=this.positionAbs),this.options.scroll&&(this.scrollParent[0]!==this.document[0]&&"HTML"!==this.scrollParent[0].tagName?(this.overflowOffset.top+this.scrollParent[0].offsetHeight-e.pageY<o.scrollSensitivity?this.scrollParent[0].scrollTop=a=this.scrollParent[0].scrollTop+o.scrollSpeed:e.pageY-this.overflowOffset.top<o.scrollSensitivity&&(this.scrollParent[0].scrollTop=a=this.scrollParent[0].scrollTop-o.scrollSpeed),this.overflowOffset.left+this.scrollParent[0].offsetWidth-e.pageX<o.scrollSensitivity?this.scrollParent[0].scrollLeft=a=this.scrollParent[0].scrollLeft+o.scrollSpeed:e.pageX-this.overflowOffset.left<o.scrollSensitivity&&(this.scrollParent[0].scrollLeft=a=this.scrollParent[0].scrollLeft-o.scrollSpeed)):(e.pageY-this.document.scrollTop()<o.scrollSensitivity?a=this.document.scrollTop(this.document.scrollTop()-o.scrollSpeed):this.window.height()-(e.pageY-this.document.scrollTop())<o.scrollSensitivity&&(a=this.document.scrollTop(this.document.scrollTop()+o.scrollSpeed)),e.pageX-this.document.scrollLeft()<o.scrollSensitivity?a=this.document.scrollLeft(this.document.scrollLeft()-o.scrollSpeed):this.window.width()-(e.pageX-this.document.scrollLeft())<o.scrollSensitivity&&(a=this.document.scrollLeft(this.document.scrollLeft()+o.scrollSpeed))),a!==!1&&t.ui.ddmanager&&!o.dropBehaviour&&t.ui.ddmanager.prepareOffsets(this,e)),this.positionAbs=this._convertPositionTo("absolute"),this.options.axis&&"y"===this.options.axis||(this.helper[0].style.left=this.position.left+"px"),this.options.axis&&"x"===this.options.axis||(this.helper[0].style.top=this.position.top+"px"),i=this.items.length-1;i>=0;i--)if(n=this.items[i],s=n.item[0],r=this._intersectsWithPointer(n),r&&n.instance===this.currentContainer&&!(s===this.currentItem[0]||this.placeholder[1===r?"next":"prev"]()[0]===s||t.contains(this.placeholder[0],s)||"semi-dynamic"===this.options.type&&t.contains(this.element[0],s))){if(this.direction=1===r?"down":"up","pointer"!==this.options.tolerance&&!this._intersectsWithSides(n))break
this._rearrange(e,n),this._trigger("change",e,this._uiHash())
break}return this._contactContainers(e),t.ui.ddmanager&&t.ui.ddmanager.drag(this,e),this._trigger("sort",e,this._uiHash()),this.lastPositionAbs=this.positionAbs,!1},_mouseStop:function(e,i){if(e){if(t.ui.ddmanager&&!this.options.dropBehaviour&&t.ui.ddmanager.drop(this,e),this.options.revert){var n=this,s=this.placeholder.offset(),r=this.options.axis,o={}
r&&"x"!==r||(o.left=s.left-this.offset.parent.left-this.margins.left+(this.offsetParent[0]===this.document[0].body?0:this.offsetParent[0].scrollLeft)),r&&"y"!==r||(o.top=s.top-this.offset.parent.top-this.margins.top+(this.offsetParent[0]===this.document[0].body?0:this.offsetParent[0].scrollTop)),this.reverting=!0,t(this.helper).animate(o,parseInt(this.options.revert,10)||500,function(){n._clear(e)})}else this._clear(e,i)
return!1}},cancel:function(){if(this.dragging){this._mouseUp(new t.Event("mouseup",{target:null})),"original"===this.options.helper?(this.currentItem.css(this._storedCSS),this._removeClass(this.currentItem,"ui-sortable-helper")):this.currentItem.show()
for(var e=this.containers.length-1;e>=0;e--)this.containers[e]._trigger("deactivate",null,this._uiHash(this)),this.containers[e].containerCache.over&&(this.containers[e]._trigger("out",null,this._uiHash(this)),this.containers[e].containerCache.over=0)}return this.placeholder&&(this.placeholder[0].parentNode&&this.placeholder[0].parentNode.removeChild(this.placeholder[0]),"original"!==this.options.helper&&this.helper&&this.helper[0].parentNode&&this.helper.remove(),t.extend(this,{helper:null,dragging:!1,reverting:!1,_noFinalSort:null}),this.domPosition.prev?t(this.domPosition.prev).after(this.currentItem):t(this.domPosition.parent).prepend(this.currentItem)),this},serialize:function(e){var i=this._getItemsAsjQuery(e&&e.connected),n=[]
return e=e||{},t(i).each(function(){var i=(t(e.item||this).attr(e.attribute||"id")||"").match(e.expression||/(.+)[\-=_](.+)/)
i&&n.push((e.key||i[1]+"[]")+"="+(e.key&&e.expression?i[1]:i[2]))}),!n.length&&e.key&&n.push(e.key+"="),n.join("&")},toArray:function(e){var i=this._getItemsAsjQuery(e&&e.connected),n=[]
return e=e||{},i.each(function(){n.push(t(e.item||this).attr(e.attribute||"id")||"")}),n},_intersectsWith:function(t){var e=this.positionAbs.left,i=e+this.helperProportions.width,n=this.positionAbs.top,s=n+this.helperProportions.height,r=t.left,o=r+t.width,a=t.top,l=a+t.height,u=this.offset.click.top,h=this.offset.click.left,c="x"===this.options.axis||n+u>a&&n+u<l,d="y"===this.options.axis||e+h>r&&e+h<o,f=c&&d
return"pointer"===this.options.tolerance||this.options.forcePointerForContainers||"pointer"!==this.options.tolerance&&this.helperProportions[this.floating?"width":"height"]>t[this.floating?"width":"height"]?f:r<e+this.helperProportions.width/2&&i-this.helperProportions.width/2<o&&a<n+this.helperProportions.height/2&&s-this.helperProportions.height/2<l},_intersectsWithPointer:function(t){var e,i,n="x"===this.options.axis||this._isOverAxis(this.positionAbs.top+this.offset.click.top,t.top,t.height),s="y"===this.options.axis||this._isOverAxis(this.positionAbs.left+this.offset.click.left,t.left,t.width),r=n&&s
return!!r&&(e=this._getDragVerticalDirection(),i=this._getDragHorizontalDirection(),this.floating?"right"===i||"down"===e?2:1:e&&("down"===e?2:1))},_intersectsWithSides:function(t){var e=this._isOverAxis(this.positionAbs.top+this.offset.click.top,t.top+t.height/2,t.height),i=this._isOverAxis(this.positionAbs.left+this.offset.click.left,t.left+t.width/2,t.width),n=this._getDragVerticalDirection(),s=this._getDragHorizontalDirection()
return this.floating&&s?"right"===s&&i||"left"===s&&!i:n&&("down"===n&&e||"up"===n&&!e)},_getDragVerticalDirection:function(){var t=this.positionAbs.top-this.lastPositionAbs.top
return 0!==t&&(t>0?"down":"up")},_getDragHorizontalDirection:function(){var t=this.positionAbs.left-this.lastPositionAbs.left
return 0!==t&&(t>0?"right":"left")},refresh:function(t){return this._refreshItems(t),this._setHandleClassName(),this.refreshPositions(),this},_connectWith:function(){var t=this.options
return t.connectWith.constructor===String?[t.connectWith]:t.connectWith},_getItemsAsjQuery:function(e){function i(){a.push(this)}var n,s,r,o,a=[],l=[],u=this._connectWith()
if(u&&e)for(n=u.length-1;n>=0;n--)for(r=t(u[n],this.document[0]),s=r.length-1;s>=0;s--)o=t.data(r[s],this.widgetFullName),o&&o!==this&&!o.options.disabled&&l.push([t.isFunction(o.options.items)?o.options.items.call(o.element):t(o.options.items,o.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"),o])
for(l.push([t.isFunction(this.options.items)?this.options.items.call(this.element,null,{options:this.options,item:this.currentItem}):t(this.options.items,this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"),this]),n=l.length-1;n>=0;n--)l[n][0].each(i)
return t(a)},_removeCurrentsFromItems:function(){var e=this.currentItem.find(":data("+this.widgetName+"-item)")
this.items=t.grep(this.items,function(t){for(var i=0;i<e.length;i++)if(e[i]===t.item[0])return!1
return!0})},_refreshItems:function(e){this.items=[],this.containers=[this]
var i,n,s,r,o,a,l,u,h=this.items,c=[[t.isFunction(this.options.items)?this.options.items.call(this.element[0],e,{item:this.currentItem}):t(this.options.items,this.element),this]],d=this._connectWith()
if(d&&this.ready)for(i=d.length-1;i>=0;i--)for(s=t(d[i],this.document[0]),n=s.length-1;n>=0;n--)r=t.data(s[n],this.widgetFullName),r&&r!==this&&!r.options.disabled&&(c.push([t.isFunction(r.options.items)?r.options.items.call(r.element[0],e,{item:this.currentItem}):t(r.options.items,r.element),r]),this.containers.push(r))
for(i=c.length-1;i>=0;i--)for(o=c[i][1],a=c[i][0],n=0,u=a.length;n<u;n++)l=t(a[n]),l.data(this.widgetName+"-item",o),h.push({item:l,instance:o,width:0,height:0,left:0,top:0})},refreshPositions:function(e){this.floating=!!this.items.length&&("x"===this.options.axis||this._isFloating(this.items[0].item)),this.offsetParent&&this.helper&&(this.offset.parent=this._getParentOffset())
var i,n,s,r
for(i=this.items.length-1;i>=0;i--)n=this.items[i],n.instance!==this.currentContainer&&this.currentContainer&&n.item[0]!==this.currentItem[0]||(s=this.options.toleranceElement?t(this.options.toleranceElement,n.item):n.item,e||(n.width=s.outerWidth(),n.height=s.outerHeight()),r=s.offset(),n.left=r.left,n.top=r.top)
if(this.options.custom&&this.options.custom.refreshContainers)this.options.custom.refreshContainers.call(this)
else for(i=this.containers.length-1;i>=0;i--)r=this.containers[i].element.offset(),this.containers[i].containerCache.left=r.left,this.containers[i].containerCache.top=r.top,this.containers[i].containerCache.width=this.containers[i].element.outerWidth(),this.containers[i].containerCache.height=this.containers[i].element.outerHeight()
return this},_createPlaceholder:function(e){e=e||this
var i,n=e.options
n.placeholder&&n.placeholder.constructor!==String||(i=n.placeholder,n.placeholder={element:function(){var n=e.currentItem[0].nodeName.toLowerCase(),s=t("<"+n+">",e.document[0])
return e._addClass(s,"ui-sortable-placeholder",i||e.currentItem[0].className)._removeClass(s,"ui-sortable-helper"),"tbody"===n?e._createTrPlaceholder(e.currentItem.find("tr").eq(0),t("<tr>",e.document[0]).appendTo(s)):"tr"===n?e._createTrPlaceholder(e.currentItem,s):"img"===n&&s.attr("src",e.currentItem.attr("src")),i||s.css("visibility","hidden"),s},update:function(t,s){i&&!n.forcePlaceholderSize||(s.height()||s.height(e.currentItem.innerHeight()-parseInt(e.currentItem.css("paddingTop")||0,10)-parseInt(e.currentItem.css("paddingBottom")||0,10)),s.width()||s.width(e.currentItem.innerWidth()-parseInt(e.currentItem.css("paddingLeft")||0,10)-parseInt(e.currentItem.css("paddingRight")||0,10)))}}),e.placeholder=t(n.placeholder.element.call(e.element,e.currentItem)),e.currentItem.after(e.placeholder),n.placeholder.update(e,e.placeholder)},_createTrPlaceholder:function(e,i){var n=this
e.children().each(function(){t("<td>&#160;</td>",n.document[0]).attr("colspan",t(this).attr("colspan")||1).appendTo(i)})},_contactContainers:function(e){var i,n,s,r,o,a,l,u,h,c,d=null,f=null
for(i=this.containers.length-1;i>=0;i--)if(!t.contains(this.currentItem[0],this.containers[i].element[0]))if(this._intersectsWith(this.containers[i].containerCache)){if(d&&t.contains(this.containers[i].element[0],d.element[0]))continue
d=this.containers[i],f=i}else this.containers[i].containerCache.over&&(this.containers[i]._trigger("out",e,this._uiHash(this)),this.containers[i].containerCache.over=0)
if(d)if(1===this.containers.length)this.containers[f].containerCache.over||(this.containers[f]._trigger("over",e,this._uiHash(this)),this.containers[f].containerCache.over=1)
else{for(s=1e4,r=null,h=d.floating||this._isFloating(this.currentItem),o=h?"left":"top",a=h?"width":"height",c=h?"pageX":"pageY",n=this.items.length-1;n>=0;n--)t.contains(this.containers[f].element[0],this.items[n].item[0])&&this.items[n].item[0]!==this.currentItem[0]&&(l=this.items[n].item.offset()[o],u=!1,e[c]-l>this.items[n][a]/2&&(u=!0),Math.abs(e[c]-l)<s&&(s=Math.abs(e[c]-l),r=this.items[n],this.direction=u?"up":"down"))
if(!r&&!this.options.dropOnEmpty)return
if(this.currentContainer===this.containers[f])return void(this.currentContainer.containerCache.over||(this.containers[f]._trigger("over",e,this._uiHash()),this.currentContainer.containerCache.over=1))
r?this._rearrange(e,r,null,!0):this._rearrange(e,null,this.containers[f].element,!0),this._trigger("change",e,this._uiHash()),this.containers[f]._trigger("change",e,this._uiHash(this)),this.currentContainer=this.containers[f],this.options.placeholder.update(this.currentContainer,this.placeholder),this.containers[f]._trigger("over",e,this._uiHash(this)),this.containers[f].containerCache.over=1}},_createHelper:function(e){var i=this.options,n=t.isFunction(i.helper)?t(i.helper.apply(this.element[0],[e,this.currentItem])):"clone"===i.helper?this.currentItem.clone():this.currentItem
return n.parents("body").length||t("parent"!==i.appendTo?i.appendTo:this.currentItem[0].parentNode)[0].appendChild(n[0]),n[0]===this.currentItem[0]&&(this._storedCSS={width:this.currentItem[0].style.width,height:this.currentItem[0].style.height,position:this.currentItem.css("position"),top:this.currentItem.css("top"),left:this.currentItem.css("left")}),n[0].style.width&&!i.forceHelperSize||n.width(this.currentItem.width()),n[0].style.height&&!i.forceHelperSize||n.height(this.currentItem.height()),n},_adjustOffsetFromHelper:function(e){"string"==typeof e&&(e=e.split(" ")),t.isArray(e)&&(e={left:+e[0],top:+e[1]||0}),"left"in e&&(this.offset.click.left=e.left+this.margins.left),"right"in e&&(this.offset.click.left=this.helperProportions.width-e.right+this.margins.left),"top"in e&&(this.offset.click.top=e.top+this.margins.top),"bottom"in e&&(this.offset.click.top=this.helperProportions.height-e.bottom+this.margins.top)},_getParentOffset:function(){this.offsetParent=this.helper.offsetParent()
var e=this.offsetParent.offset()
return"absolute"===this.cssPosition&&this.scrollParent[0]!==this.document[0]&&t.contains(this.scrollParent[0],this.offsetParent[0])&&(e.left+=this.scrollParent.scrollLeft(),e.top+=this.scrollParent.scrollTop()),(this.offsetParent[0]===this.document[0].body||this.offsetParent[0].tagName&&"html"===this.offsetParent[0].tagName.toLowerCase()&&t.ui.ie)&&(e={top:0,left:0}),{top:e.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:e.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}},_getRelativeOffset:function(){if("relative"===this.cssPosition){var t=this.currentItem.position()
return{top:t.top-(parseInt(this.helper.css("top"),10)||0)+this.scrollParent.scrollTop(),left:t.left-(parseInt(this.helper.css("left"),10)||0)+this.scrollParent.scrollLeft()}}return{top:0,left:0}},_cacheMargins:function(){this.margins={left:parseInt(this.currentItem.css("marginLeft"),10)||0,top:parseInt(this.currentItem.css("marginTop"),10)||0}},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}},_setContainment:function(){var e,i,n,s=this.options
"parent"===s.containment&&(s.containment=this.helper[0].parentNode),"document"!==s.containment&&"window"!==s.containment||(this.containment=[0-this.offset.relative.left-this.offset.parent.left,0-this.offset.relative.top-this.offset.parent.top,"document"===s.containment?this.document.width():this.window.width()-this.helperProportions.width-this.margins.left,("document"===s.containment?this.document.height()||document.body.parentNode.scrollHeight:this.window.height()||this.document[0].body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]),/^(document|window|parent)$/.test(s.containment)||(e=t(s.containment)[0],i=t(s.containment).offset(),n="hidden"!==t(e).css("overflow"),this.containment=[i.left+(parseInt(t(e).css("borderLeftWidth"),10)||0)+(parseInt(t(e).css("paddingLeft"),10)||0)-this.margins.left,i.top+(parseInt(t(e).css("borderTopWidth"),10)||0)+(parseInt(t(e).css("paddingTop"),10)||0)-this.margins.top,i.left+(n?Math.max(e.scrollWidth,e.offsetWidth):e.offsetWidth)-(parseInt(t(e).css("borderLeftWidth"),10)||0)-(parseInt(t(e).css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left,i.top+(n?Math.max(e.scrollHeight,e.offsetHeight):e.offsetHeight)-(parseInt(t(e).css("borderTopWidth"),10)||0)-(parseInt(t(e).css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top])},_convertPositionTo:function(e,i){i||(i=this.position)
var n="absolute"===e?1:-1,s="absolute"!==this.cssPosition||this.scrollParent[0]!==this.document[0]&&t.contains(this.scrollParent[0],this.offsetParent[0])?this.scrollParent:this.offsetParent,r=/(html|body)/i.test(s[0].tagName)
return{top:i.top+this.offset.relative.top*n+this.offset.parent.top*n-("fixed"===this.cssPosition?-this.scrollParent.scrollTop():r?0:s.scrollTop())*n,left:i.left+this.offset.relative.left*n+this.offset.parent.left*n-("fixed"===this.cssPosition?-this.scrollParent.scrollLeft():r?0:s.scrollLeft())*n}},_generatePosition:function(e){var i,n,s=this.options,r=e.pageX,o=e.pageY,a="absolute"!==this.cssPosition||this.scrollParent[0]!==this.document[0]&&t.contains(this.scrollParent[0],this.offsetParent[0])?this.scrollParent:this.offsetParent,l=/(html|body)/i.test(a[0].tagName)
return"relative"!==this.cssPosition||this.scrollParent[0]!==this.document[0]&&this.scrollParent[0]!==this.offsetParent[0]||(this.offset.relative=this._getRelativeOffset()),this.originalPosition&&(this.containment&&(e.pageX-this.offset.click.left<this.containment[0]&&(r=this.containment[0]+this.offset.click.left),e.pageY-this.offset.click.top<this.containment[1]&&(o=this.containment[1]+this.offset.click.top),e.pageX-this.offset.click.left>this.containment[2]&&(r=this.containment[2]+this.offset.click.left),e.pageY-this.offset.click.top>this.containment[3]&&(o=this.containment[3]+this.offset.click.top)),s.grid&&(i=this.originalPageY+Math.round((o-this.originalPageY)/s.grid[1])*s.grid[1],o=this.containment?i-this.offset.click.top>=this.containment[1]&&i-this.offset.click.top<=this.containment[3]?i:i-this.offset.click.top>=this.containment[1]?i-s.grid[1]:i+s.grid[1]:i,n=this.originalPageX+Math.round((r-this.originalPageX)/s.grid[0])*s.grid[0],r=this.containment?n-this.offset.click.left>=this.containment[0]&&n-this.offset.click.left<=this.containment[2]?n:n-this.offset.click.left>=this.containment[0]?n-s.grid[0]:n+s.grid[0]:n)),{top:o-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+("fixed"===this.cssPosition?-this.scrollParent.scrollTop():l?0:a.scrollTop()),left:r-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+("fixed"===this.cssPosition?-this.scrollParent.scrollLeft():l?0:a.scrollLeft())}},_rearrange:function(t,e,i,n){i?i[0].appendChild(this.placeholder[0]):e.item[0].parentNode.insertBefore(this.placeholder[0],"down"===this.direction?e.item[0]:e.item[0].nextSibling),this.counter=this.counter?++this.counter:1
var s=this.counter
this._delay(function(){s===this.counter&&this.refreshPositions(!n)})},_clear:function(t,e){function i(t,e,i){return function(n){i._trigger(t,n,e._uiHash(e))}}this.reverting=!1
var n,s=[]
if(!this._noFinalSort&&this.currentItem.parent().length&&this.placeholder.before(this.currentItem),this._noFinalSort=null,this.helper[0]===this.currentItem[0]){for(n in this._storedCSS)"auto"!==this._storedCSS[n]&&"static"!==this._storedCSS[n]||(this._storedCSS[n]="")
this.currentItem.css(this._storedCSS),this._removeClass(this.currentItem,"ui-sortable-helper")}else this.currentItem.show()
for(this.fromOutside&&!e&&s.push(function(t){this._trigger("receive",t,this._uiHash(this.fromOutside))}),!this.fromOutside&&this.domPosition.prev===this.currentItem.prev().not(".ui-sortable-helper")[0]&&this.domPosition.parent===this.currentItem.parent()[0]||e||s.push(function(t){this._trigger("update",t,this._uiHash())}),this!==this.currentContainer&&(e||(s.push(function(t){this._trigger("remove",t,this._uiHash())}),s.push(function(t){return function(e){t._trigger("receive",e,this._uiHash(this))}}.call(this,this.currentContainer)),s.push(function(t){return function(e){t._trigger("update",e,this._uiHash(this))}}.call(this,this.currentContainer)))),n=this.containers.length-1;n>=0;n--)e||s.push(i("deactivate",this,this.containers[n])),this.containers[n].containerCache.over&&(s.push(i("out",this,this.containers[n])),this.containers[n].containerCache.over=0)
if(this.storedCursor&&(this.document.find("body").css("cursor",this.storedCursor),this.storedStylesheet.remove()),this._storedOpacity&&this.helper.css("opacity",this._storedOpacity),this._storedZIndex&&this.helper.css("zIndex","auto"===this._storedZIndex?"":this._storedZIndex),this.dragging=!1,e||this._trigger("beforeStop",t,this._uiHash()),this.placeholder[0].parentNode.removeChild(this.placeholder[0]),this.cancelHelperRemoval||(this.helper[0]!==this.currentItem[0]&&this.helper.remove(),this.helper=null),!e){for(n=0;n<s.length;n++)s[n].call(this,t)
this._trigger("stop",t,this._uiHash())}return this.fromOutside=!1,!this.cancelHelperRemoval},_trigger:function(){t.Widget.prototype._trigger.apply(this,arguments)===!1&&this.cancel()},_uiHash:function(e){var i=e||this
return{helper:i.helper,placeholder:i.placeholder||t([]),position:i.position,originalPosition:i.originalPosition,offset:i.positionAbs,item:i.currentItem,sender:e?e.element:null}}}),t.ui.safeActiveElement=function(t){var e
try{e=t.activeElement}catch(i){e=t.body}return e||(e=t.body),e.nodeName||(e=t.body),e},t.widget("ui.menu",{version:"1.12.1",defaultElement:"<ul>",delay:300,options:{icons:{submenu:"ui-icon-caret-1-e"},items:"> *",menus:"ul",position:{my:"left top",at:"right top"},role:"menu",blur:null,focus:null,select:null},_create:function(){this.activeMenu=this.element,this.mouseHandled=!1,this.element.uniqueId().attr({role:this.options.role,tabIndex:0}),this._addClass("ui-menu","ui-widget ui-widget-content"),this._on({"mousedown .ui-menu-item":function(t){t.preventDefault()},"click .ui-menu-item":function(e){var i=t(e.target),n=t(t.ui.safeActiveElement(this.document[0]))
!this.mouseHandled&&i.not(".ui-state-disabled").length&&(this.select(e),e.isPropagationStopped()||(this.mouseHandled=!0),i.has(".ui-menu").length?this.expand(e):!this.element.is(":focus")&&n.closest(".ui-menu").length&&(this.element.trigger("focus",[!0]),this.active&&1===this.active.parents(".ui-menu").length&&clearTimeout(this.timer)))},"mouseenter .ui-menu-item":function(e){if(!this.previousFilter){var i=t(e.target).closest(".ui-menu-item"),n=t(e.currentTarget)
i[0]===n[0]&&(this._removeClass(n.siblings().children(".ui-state-active"),null,"ui-state-active"),this.focus(e,n))}},mouseleave:"collapseAll","mouseleave .ui-menu":"collapseAll",focus:function(t,e){var i=this.active||this.element.find(this.options.items).eq(0)
e||this.focus(t,i)},blur:function(e){this._delay(function(){var i=!t.contains(this.element[0],t.ui.safeActiveElement(this.document[0]))
i&&this.collapseAll(e)})},keydown:"_keydown"}),this.refresh(),this._on(this.document,{click:function(t){this._closeOnDocumentClick(t)&&this.collapseAll(t),this.mouseHandled=!1}})},_destroy:function(){var e=this.element.find(".ui-menu-item").removeAttr("role aria-disabled"),i=e.children(".ui-menu-item-wrapper").removeUniqueId().removeAttr("tabIndex role aria-haspopup")
this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeAttr("role aria-labelledby aria-expanded aria-hidden aria-disabled tabIndex").removeUniqueId().show(),i.children().each(function(){var e=t(this)
e.data("ui-menu-submenu-caret")&&e.remove()})},_keydown:function(e){var i,n,s,r,o=!0
switch(e.keyCode){case t.ui.keyCode.PAGE_UP:this.previousPage(e)
break
case t.ui.keyCode.PAGE_DOWN:this.nextPage(e)
break
case t.ui.keyCode.HOME:this._move("first","first",e)
break
case t.ui.keyCode.END:this._move("last","last",e)
break
case t.ui.keyCode.UP:this.previous(e)
break
case t.ui.keyCode.DOWN:this.next(e)
break
case t.ui.keyCode.LEFT:this.collapse(e)
break
case t.ui.keyCode.RIGHT:this.active&&!this.active.is(".ui-state-disabled")&&this.expand(e)
break
case t.ui.keyCode.ENTER:case t.ui.keyCode.SPACE:this._activate(e)
break
case t.ui.keyCode.ESCAPE:this.collapse(e)
break
default:o=!1,n=this.previousFilter||"",r=!1,s=e.keyCode>=96&&e.keyCode<=105?(e.keyCode-96).toString():String.fromCharCode(e.keyCode),clearTimeout(this.filterTimer),s===n?r=!0:s=n+s,i=this._filterMenuItems(s),i=r&&i.index(this.active.next())!==-1?this.active.nextAll(".ui-menu-item"):i,i.length||(s=String.fromCharCode(e.keyCode),i=this._filterMenuItems(s)),i.length?(this.focus(e,i),this.previousFilter=s,this.filterTimer=this._delay(function(){delete this.previousFilter},1e3)):delete this.previousFilter}o&&e.preventDefault()},_activate:function(t){this.active&&!this.active.is(".ui-state-disabled")&&(this.active.children("[aria-haspopup='true']").length?this.expand(t):this.select(t))},refresh:function(){var e,i,n,s,r,o=this,a=this.options.icons.submenu,l=this.element.find(this.options.menus)
this._toggleClass("ui-menu-icons",null,!!this.element.find(".ui-icon").length),n=l.filter(":not(.ui-menu)").hide().attr({role:this.options.role,"aria-hidden":"true","aria-expanded":"false"}).each(function(){var e=t(this),i=e.prev(),n=t("<span>").data("ui-menu-submenu-caret",!0)
o._addClass(n,"ui-menu-icon","ui-icon "+a),i.attr("aria-haspopup","true").prepend(n),e.attr("aria-labelledby",i.attr("id"))}),this._addClass(n,"ui-menu","ui-widget ui-widget-content ui-front"),e=l.add(this.element),i=e.find(this.options.items),i.not(".ui-menu-item").each(function(){var e=t(this)
o._isDivider(e)&&o._addClass(e,"ui-menu-divider","ui-widget-content")}),s=i.not(".ui-menu-item, .ui-menu-divider"),r=s.children().not(".ui-menu").uniqueId().attr({tabIndex:-1,role:this._itemRole()}),this._addClass(s,"ui-menu-item")._addClass(r,"ui-menu-item-wrapper"),i.filter(".ui-state-disabled").attr("aria-disabled","true"),this.active&&!t.contains(this.element[0],this.active[0])&&this.blur()},_itemRole:function(){return{menu:"menuitem",listbox:"option"}[this.options.role]},_setOption:function(t,e){if("icons"===t){var i=this.element.find(".ui-menu-icon")
this._removeClass(i,null,this.options.icons.submenu)._addClass(i,null,e.submenu)}this._super(t,e)},_setOptionDisabled:function(t){this._super(t),this.element.attr("aria-disabled",String(t)),this._toggleClass(null,"ui-state-disabled",!!t)},focus:function(t,e){var i,n,s
this.blur(t,t&&"focus"===t.type),this._scrollIntoView(e),this.active=e.first(),n=this.active.children(".ui-menu-item-wrapper"),this._addClass(n,null,"ui-state-active"),this.options.role&&this.element.attr("aria-activedescendant",n.attr("id")),s=this.active.parent().closest(".ui-menu-item").children(".ui-menu-item-wrapper"),this._addClass(s,null,"ui-state-active"),t&&"keydown"===t.type?this._close():this.timer=this._delay(function(){this._close()},this.delay),i=e.children(".ui-menu"),i.length&&t&&/^mouse/.test(t.type)&&this._startOpening(i),this.activeMenu=e.parent(),this._trigger("focus",t,{item:e})},_scrollIntoView:function(e){var i,n,s,r,o,a
this._hasScroll()&&(i=parseFloat(t.css(this.activeMenu[0],"borderTopWidth"))||0,n=parseFloat(t.css(this.activeMenu[0],"paddingTop"))||0,s=e.offset().top-this.activeMenu.offset().top-i-n,r=this.activeMenu.scrollTop(),o=this.activeMenu.height(),a=e.outerHeight(),s<0?this.activeMenu.scrollTop(r+s):s+a>o&&this.activeMenu.scrollTop(r+s-o+a))},blur:function(t,e){e||clearTimeout(this.timer),this.active&&(this._removeClass(this.active.children(".ui-menu-item-wrapper"),null,"ui-state-active"),this._trigger("blur",t,{item:this.active}),this.active=null)},_startOpening:function(t){clearTimeout(this.timer),"true"===t.attr("aria-hidden")&&(this.timer=this._delay(function(){this._close(),this._open(t)},this.delay))},_open:function(e){var i=t.extend({of:this.active},this.options.position)
clearTimeout(this.timer),this.element.find(".ui-menu").not(e.parents(".ui-menu")).hide().attr("aria-hidden","true"),e.show().removeAttr("aria-hidden").attr("aria-expanded","true").position(i)},collapseAll:function(e,i){clearTimeout(this.timer),this.timer=this._delay(function(){var n=i?this.element:t(e&&e.target).closest(this.element.find(".ui-menu"))
n.length||(n=this.element),this._close(n),this.blur(e),this._removeClass(n.find(".ui-state-active"),null,"ui-state-active"),this.activeMenu=n},this.delay)},_close:function(t){t||(t=this.active?this.active.parent():this.element),t.find(".ui-menu").hide().attr("aria-hidden","true").attr("aria-expanded","false")},_closeOnDocumentClick:function(e){return!t(e.target).closest(".ui-menu").length},_isDivider:function(t){return!/[^\-\u2014\u2013\s]/.test(t.text())},collapse:function(t){var e=this.active&&this.active.parent().closest(".ui-menu-item",this.element)
e&&e.length&&(this._close(),this.focus(t,e))},expand:function(t){var e=this.active&&this.active.children(".ui-menu ").find(this.options.items).first()
e&&e.length&&(this._open(e.parent()),this._delay(function(){this.focus(t,e)}))},next:function(t){this._move("next","first",t)},previous:function(t){this._move("prev","last",t)},isFirstItem:function(){return this.active&&!this.active.prevAll(".ui-menu-item").length},isLastItem:function(){return this.active&&!this.active.nextAll(".ui-menu-item").length},_move:function(t,e,i){var n
this.active&&(n="first"===t||"last"===t?this.active["first"===t?"prevAll":"nextAll"](".ui-menu-item").eq(-1):this.active[t+"All"](".ui-menu-item").eq(0)),n&&n.length&&this.active||(n=this.activeMenu.find(this.options.items)[e]()),this.focus(i,n)},nextPage:function(e){var i,n,s
return this.active?void(this.isLastItem()||(this._hasScroll()?(n=this.active.offset().top,s=this.element.height(),this.active.nextAll(".ui-menu-item").each(function(){return i=t(this),i.offset().top-n-s<0}),this.focus(e,i)):this.focus(e,this.activeMenu.find(this.options.items)[this.active?"last":"first"]()))):void this.next(e)},previousPage:function(e){var i,n,s
return this.active?void(this.isFirstItem()||(this._hasScroll()?(n=this.active.offset().top,s=this.element.height(),this.active.prevAll(".ui-menu-item").each(function(){return i=t(this),i.offset().top-n+s>0}),this.focus(e,i)):this.focus(e,this.activeMenu.find(this.options.items).first()))):void this.next(e)},_hasScroll:function(){return this.element.outerHeight()<this.element.prop("scrollHeight")},select:function(e){this.active=this.active||t(e.target).closest(".ui-menu-item")
var i={item:this.active}
this.active.has(".ui-menu").length||this.collapseAll(e,!0),this._trigger("select",e,i)},_filterMenuItems:function(e){var i=e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&"),n=new RegExp("^"+i,"i")
return this.activeMenu.find(this.options.items).filter(".ui-menu-item").filter(function(){return n.test(t.trim(t(this).children(".ui-menu-item-wrapper").text()))})}})
t.widget("ui.autocomplete",{version:"1.12.1",defaultElement:"<input>",options:{appendTo:null,autoFocus:!1,delay:300,minLength:1,position:{my:"left top",at:"left bottom",collision:"none"},source:null,change:null,close:null,focus:null,open:null,response:null,search:null,select:null},requestIndex:0,pending:0,_create:function(){var e,i,n,s=this.element[0].nodeName.toLowerCase(),r="textarea"===s,o="input"===s
this.isMultiLine=r||!o&&this._isContentEditable(this.element),this.valueMethod=this.element[r||o?"val":"text"],this.isNewMenu=!0,this._addClass("ui-autocomplete-input"),this.element.attr("autocomplete","off"),this._on(this.element,{keydown:function(s){if(this.element.prop("readOnly"))return e=!0,n=!0,void(i=!0)
e=!1,n=!1,i=!1
var r=t.ui.keyCode
switch(s.keyCode){case r.PAGE_UP:e=!0,this._move("previousPage",s)
break
case r.PAGE_DOWN:e=!0,this._move("nextPage",s)
break
case r.UP:e=!0,this._keyEvent("previous",s)
break
case r.DOWN:e=!0,this._keyEvent("next",s)
break
case r.ENTER:this.menu.active&&(e=!0,s.preventDefault(),this.menu.select(s))
break
case r.TAB:this.menu.active&&this.menu.select(s)
break
case r.ESCAPE:this.menu.element.is(":visible")&&(this.isMultiLine||this._value(this.term),this.close(s),s.preventDefault())
break
default:i=!0,this._searchTimeout(s)}},keypress:function(n){if(e)return e=!1,void(this.isMultiLine&&!this.menu.element.is(":visible")||n.preventDefault())
if(!i){var s=t.ui.keyCode
switch(n.keyCode){case s.PAGE_UP:this._move("previousPage",n)
break
case s.PAGE_DOWN:this._move("nextPage",n)
break
case s.UP:this._keyEvent("previous",n)
break
case s.DOWN:this._keyEvent("next",n)}}},input:function(t){return n?(n=!1,void t.preventDefault()):void this._searchTimeout(t)},focus:function(){this.selectedItem=null,this.previous=this._value()},blur:function(t){return this.cancelBlur?void delete this.cancelBlur:(clearTimeout(this.searching),this.close(t),void this._change(t))}}),this._initSource(),this.menu=t("<ul>").appendTo(this._appendTo()).menu({role:null}).hide().menu("instance"),this._addClass(this.menu.element,"ui-autocomplete","ui-front"),this._on(this.menu.element,{mousedown:function(e){e.preventDefault(),this.cancelBlur=!0,this._delay(function(){delete this.cancelBlur,this.element[0]!==t.ui.safeActiveElement(this.document[0])&&this.element.trigger("focus")})},menufocus:function(e,i){var n,s
return this.isNewMenu&&(this.isNewMenu=!1,e.originalEvent&&/^mouse/.test(e.originalEvent.type))?(this.menu.blur(),void this.document.one("mousemove",function(){t(e.target).trigger(e.originalEvent)})):(s=i.item.data("ui-autocomplete-item"),!1!==this._trigger("focus",e,{item:s})&&e.originalEvent&&/^key/.test(e.originalEvent.type)&&this._value(s.value),n=i.item.attr("aria-label")||s.value,void(n&&t.trim(n).length&&(this.liveRegion.children().hide(),t("<div>").text(n).appendTo(this.liveRegion))))},menuselect:function(e,i){var n=i.item.data("ui-autocomplete-item"),s=this.previous
this.element[0]!==t.ui.safeActiveElement(this.document[0])&&(this.element.trigger("focus"),this.previous=s,this._delay(function(){this.previous=s,this.selectedItem=n})),!1!==this._trigger("select",e,{item:n})&&this._value(n.value),this.term=this._value(),this.close(e),this.selectedItem=n}}),this.liveRegion=t("<div>",{role:"status","aria-live":"assertive","aria-relevant":"additions"}).appendTo(this.document[0].body),this._addClass(this.liveRegion,null,"ui-helper-hidden-accessible"),this._on(this.window,{beforeunload:function(){this.element.removeAttr("autocomplete")}})},_destroy:function(){clearTimeout(this.searching),this.element.removeAttr("autocomplete"),this.menu.element.remove(),this.liveRegion.remove()},_setOption:function(t,e){this._super(t,e),"source"===t&&this._initSource(),"appendTo"===t&&this.menu.element.appendTo(this._appendTo()),"disabled"===t&&e&&this.xhr&&this.xhr.abort()},_isEventTargetInWidget:function(e){var i=this.menu.element[0]
return e.target===this.element[0]||e.target===i||t.contains(i,e.target)},_closeOnClickOutside:function(t){this._isEventTargetInWidget(t)||this.close()},_appendTo:function(){var e=this.options.appendTo
return e&&(e=e.jquery||e.nodeType?t(e):this.document.find(e).eq(0)),e&&e[0]||(e=this.element.closest(".ui-front, dialog")),e.length||(e=this.document[0].body),e},_initSource:function(){var e,i,n=this
t.isArray(this.options.source)?(e=this.options.source,this.source=function(i,n){n(t.ui.autocomplete.filter(e,i.term))}):"string"==typeof this.options.source?(i=this.options.source,this.source=function(e,s){n.xhr&&n.xhr.abort(),n.xhr=t.ajax({url:i,data:e,dataType:"json",success:function(t){s(t)},error:function(){s([])}})}):this.source=this.options.source},_searchTimeout:function(t){clearTimeout(this.searching),this.searching=this._delay(function(){var e=this.term===this._value(),i=this.menu.element.is(":visible"),n=t.altKey||t.ctrlKey||t.metaKey||t.shiftKey
e&&(!e||i||n)||(this.selectedItem=null,this.search(null,t))},this.options.delay)},search:function(t,e){return t=null!=t?t:this._value(),this.term=this._value(),t.length<this.options.minLength?this.close(e):this._trigger("search",e)!==!1?this._search(t):void 0},_search:function(t){this.pending++,this._addClass("ui-autocomplete-loading"),this.cancelSearch=!1,this.source({term:t},this._response())},_response:function(){var e=++this.requestIndex
return t.proxy(function(t){e===this.requestIndex&&this.__response(t),this.pending--,this.pending||this._removeClass("ui-autocomplete-loading")},this)},__response:function(t){t&&(t=this._normalize(t)),this._trigger("response",null,{content:t}),!this.options.disabled&&t&&t.length&&!this.cancelSearch?(this._suggest(t),this._trigger("open")):this._close()},close:function(t){this.cancelSearch=!0,this._close(t)},_close:function(t){this._off(this.document,"mousedown"),this.menu.element.is(":visible")&&(this.menu.element.hide(),this.menu.blur(),this.isNewMenu=!0,this._trigger("close",t))},_change:function(t){this.previous!==this._value()&&this._trigger("change",t,{item:this.selectedItem})},_normalize:function(e){return e.length&&e[0].label&&e[0].value?e:t.map(e,function(e){return"string"==typeof e?{label:e,value:e}:t.extend({},e,{label:e.label||e.value,value:e.value||e.label})})},_suggest:function(e){var i=this.menu.element.empty()
this._renderMenu(i,e),this.isNewMenu=!0,this.menu.refresh(),i.show(),this._resizeMenu(),i.position(t.extend({of:this.element},this.options.position)),this.options.autoFocus&&this.menu.next(),this._on(this.document,{mousedown:"_closeOnClickOutside"})},_resizeMenu:function(){var t=this.menu.element
t.outerWidth(Math.max(t.width("").outerWidth()+1,this.element.outerWidth()))},_renderMenu:function(e,i){var n=this
t.each(i,function(t,i){n._renderItemData(e,i)})},_renderItemData:function(t,e){return this._renderItem(t,e).data("ui-autocomplete-item",e)},_renderItem:function(e,i){return t("<li>").append(t("<div>").text(i.label)).appendTo(e)},_move:function(t,e){return this.menu.element.is(":visible")?this.menu.isFirstItem()&&/^previous/.test(t)||this.menu.isLastItem()&&/^next/.test(t)?(this.isMultiLine||this._value(this.term),void this.menu.blur()):void this.menu[t](e):void this.search(null,e)},widget:function(){return this.menu.element},_value:function(){return this.valueMethod.apply(this.element,arguments)},_keyEvent:function(t,e){this.isMultiLine&&!this.menu.element.is(":visible")||(this._move(t,e),e.preventDefault())},_isContentEditable:function(t){if(!t.length)return!1
var e=t.prop("contentEditable")
return"inherit"===e?this._isContentEditable(t.parent()):"true"===e}}),t.extend(t.ui.autocomplete,{escapeRegex:function(t){return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")},filter:function(e,i){var n=new RegExp(t.ui.autocomplete.escapeRegex(i),"i")
return t.grep(e,function(t){return n.test(t.label||t.value||t)})}}),t.widget("ui.autocomplete",t.ui.autocomplete,{options:{messages:{noResults:"No search results.",results:function(t){return t+(t>1?" results are":" result is")+" available, use up and down arrow keys to navigate."}}},__response:function(e){var i
this._superApply(arguments),this.options.disabled||this.cancelSearch||(i=e&&e.length?this.options.messages.results(e.length):this.options.messages.noResults,this.liveRegion.children().hide(),t("<div>").text(i).appendTo(this.liveRegion))}})
t.ui.autocomplete}),function(t,e){function i(t){var e=""
if(t=parseInt(t,10),!t||t<1)return e
for(;t;)e+="0",t-=1
return e}function n(t,e,n){return null==t&&(t=""),t=""+t,(n?t:"")+i(e-t.length)+(n?"":t)}function s(t){return"[object Array]"===Object.prototype.toString.call(t)}function r(t){return"[object Object]"===Object.prototype.toString.call(t)}function o(t,e){for(var i=t.length;i-=1;)if(e(t[i]))return t[i]}function a(t,e){var i,n=0,s=t.length
for("function"!=typeof e&&(i=e,e=function(t){return t===i});n<s;){if(e(t[n]))return t[n]
n+=1}}function l(t,e){var i=0,n=t.length
if(t&&n)for(;i<n;){if(e(t[i],i)===!1)return
i+=1}}function u(t,e){var i=0,n=t.length,s=[]
if(!t||!n)return s
for(;i<n;)s[i]=e(t[i],i),i+=1
return s}function h(t,e){return u(t,function(t){return t[e]})}function c(t){var e=[]
return l(t,function(t){t&&e.push(t)}),e}function d(t){var e=[]
return l(t,function(t){a(e,t)||e.push(t)}),e}function f(t,e){var i=[]
return l(t,function(t){l(e,function(e){t===e&&i.push(t)})}),d(i)}function p(t,e){var i=[]
return l(t,function(n,s){if(!e(n))return i=t.slice(s),!1}),i}function m(t,e){var i=t.slice().reverse()
return p(i,e).reverse()}function g(t,e){for(var i in e)e.hasOwnProperty(i)&&(t[i]=e[i])
return t}var v
if("function"==typeof require)try{v=require("moment")}catch(t){}if(!v&&t.moment&&(v=t.moment),!v)throw"Moment Duration Format cannot find Moment.js"
v.duration.fn.format=function(){var t,e,o,y,_,b,w=[].slice.call(arguments),x=g({},this.format.defaults),k=v.duration(this)
return x.duration=this,l(w,function(t){return"string"==typeof t||"function"==typeof t?void(x.template=t):"number"==typeof t?void(x.precision=t):void(r(t)&&g(x,t))}),o=x.types=s(x.types)?x.types:x.types.split(" "),"function"==typeof x.template&&(x.template=x.template.apply(x)),t=new RegExp(u(o,function(t){return x[t].source}).join("|"),"g"),y=function(t){return a(o,function(e){return x[e].test(t)})},e=u(x.template.match(t),function(t,e){var i=y(t),n=t.length
return{index:e,length:n,token:"escape"===i?t.replace(x.escape,"$1"):t,type:"escape"===i||"general"===i?null:i}},this),_=f(o,d(c(h(e,"type")))),_.length?(l(_,function(t,i){var n,s,r,o,a
n=k.as(t),s=n>0?Math.floor(n):Math.ceil(n),r=n-s,o=i+1===_.length,a=!i,l(e,function(e){e.type===t&&(g(e,{value:n,wholeValue:s,decimalValue:r,isLeast:o,isMost:a}),a&&null==x.forceLength&&e.length>1&&(x.forceLength=!0))}),k.subtract(s,t)}),x.trim&&(e=("left"===x.trim?p:m)(e,function(t){return!(t.isLeast||null!=t.type&&t.wholeValue)})),b=!1,"right"===x.trim&&e.reverse(),e=u(e,function(t){var e,s
if(!t.type)return t.token
if(e=t.isLeast&&x.precision<0?(Math.floor(t.wholeValue*Math.pow(10,x.precision))*Math.pow(10,-x.precision)).toString():t.wholeValue.toString(),e=e.replace(/^\-/,""),t.length>1&&(b||t.isMost||x.forceLength)&&(e=n(e,t.length)),t.isLeast&&x.precision>0)switch(s=t.decimalValue.toString().replace(/^\-/,"").split(/\.|e\-/),s.length){case 1:e+="."+n(s[0],x.precision,!0).slice(0,x.precision)
break
case 2:e+="."+n(s[1],x.precision,!0).slice(0,x.precision)
break
case 3:e+="."+n(i(+s[2]-1)+(s[0]||"0")+s[1],x.precision,!0).slice(0,x.precision)
break
default:throw"Moment Duration Format: unable to parse token decimal value."}return t.isMost&&t.value<0&&(e="-"+e),b=!0,e}),"right"===x.trim&&e.reverse(),e.join("")):h(e,"token").join("")},v.duration.fn.format.defaults={escape:/\[(.+?)\]/,years:/[Yy]+/,months:/M+/,weeks:/[Ww]+/,days:/[Dd]+/,hours:/[Hh]+/,minutes:/m+/,seconds:/s+/,milliseconds:/S+/,general:/.+?/,types:"escape years months weeks days hours minutes seconds milliseconds general",trim:"left",precision:0,forceLength:null,template:function(){var t=this.types,e=this.duration,i=o(t,function(t){return e._data[t]})
switch(i){case"seconds":return"h:mm:ss"
case"minutes":return"d[d] h:mm"
case"hours":return"d[d] h[h]"
case"days":return"M[m] d[d]"
case"weeks":return"y[y] w[w]"
case"months":return"y[y] M[m]"
case"years":return"y[y]"
default:return"y[y] M[m] d[d] h:mm:ss"}}}}(this),moment.defineLocale("et",{months:"jaanuar_veebruar_märts_aprill_mai_juuni_juuli_august_september_oktoober_november_detsember".split("_"),monthsShort:"jaan_veebr_märts_apr_mai_juuni_juuli_aug_sept_okt_nov_dets".split("_"),weekdays:"pühapäev_esmaspäev_teisipäev_kolmapäev_neljapäev_reede_laupäev".split("_"),weekdaysShort:"P_E_T_K_N_R_L".split("_"),weekdaysMin:"P_E_T_K_N_R_L".split("_"),longDateFormat:{LT:"H:mm",LTS:"H:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"},calendar:{sameDay:"[Täna,] LT",nextDay:"[Homme,] LT",nextWeek:"[Järgmine] dddd LT",lastDay:"[Eile,] LT",lastWeek:"[Eelmine] dddd LT",sameElse:"L"},relativeTime:{future:"%s pärast",past:"%s tagasi",s:processRelativeTime,m:processRelativeTime,mm:processRelativeTime,h:processRelativeTime,hh:processRelativeTime,d:processRelativeTime,dd:"%d päeva",M:processRelativeTime,MM:processRelativeTime,y:processRelativeTime,yy:processRelativeTime},ordinalParse:/\d{1,2}\./,ordinal:"%d.",week:{dow:1,doy:4}})
