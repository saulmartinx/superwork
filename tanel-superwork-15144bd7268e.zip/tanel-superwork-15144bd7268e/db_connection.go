package main

import (
	"database/sql"
	"fmt"
	"os/exec"
	"path/filepath"
)

func connectDB(dbname string) error {
	if db != nil {
		return nil
	}
	res, err := sql.Open("postgres", fmt.Sprintf("user=superwork dbname=%s sslmode=disable", dbname))
	if err != nil {
		return err
	}
	db = res
	return nil
}

func recreateDB(dbname string) error {
	if _, err := exec.Command("dropdb", dbname).Output(); err != nil {
	}
	if _, err := exec.Command("dropuser", dbname).Output(); err != nil {
	}
	if _, err := exec.Command("createdb", dbname).Output(); err != nil {
		return err
	}
	if _, err := exec.Command("createuser", dbname).Output(); err != nil {
		return err
	}
	if _, err := exec.Command("psql", dbname, "-f", filepath.Join("db", "setup.sql")).CombinedOutput(); err != nil {
		return err
	}
	return nil
}
