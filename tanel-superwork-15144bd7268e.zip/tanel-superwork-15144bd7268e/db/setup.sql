/*

0) From terminal, get rid of existing data, IF NEEDED SOMEHOW

dropdb superwork

dropdb superwork_test

dropuser superwork

1) From terminal, create new database:

createdb superwork

createuser superwork

psql superwork < db/setup.sql

*/

CREATE EXTENSION pgcrypto;

/* users (User) */

CREATE TABLE users(
	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	name TEXT,
	email TEXT NOT NULL,
	password_hash TEXT,
	created_at timestamp with time zone NOT NULL,
	updated_at timestamp with time zone,
	deleted_at timestamp with time zone
);

CREATE UNIQUE INDEX users_email_unique ON users(email)
   WHERE deleted_at IS NULL;

create index users_deleted_at on users(deleted_at);

GRANT ALL PRIVILEGES ON TABLE users TO GROUP superwork;

ALTER TABLE users ADD COLUMN phone text;
ALTER TABLE users ADD COLUMN year_of_birth int;
ALTER TABLE users ADD COLUMN picture text;

/* create migrations */

CREATE TABLE migrations(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL
);

CREATE UNIQUE INDEX migration_name_unique ON migrations(name);

GRANT ALL PRIVILEGES ON TABLE migrations TO GROUP superwork;

INSERT INTO migrations(name) VALUES('create_migrations');

/* categories (Category) */

CREATE TABLE categories(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index categories_deleted_at on categories(deleted_at);

GRANT ALL PRIVILEGES ON TABLE categories TO GROUP superwork;

INSERT INTO migrations(name) VALUES('categories');

/* companies (Company) */

CREATE TABLE companies(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index companies_deleted_at on companies(deleted_at);

GRANT ALL PRIVILEGES ON TABLE companies TO GROUP superwork;

INSERT INTO migrations(name) VALUES('companies');

/* organizations (Organization) */

CREATE TABLE organizations(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	owner_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	country_code TEXT,
	address TEXT,
	address_subpremise TEXT,
	address_street_number TEXT,
	address_route TEXT,
	address_sublocality TEXT,
	address_locality TEXT,
	address_admin_area_level_1 TEXT,
	address_admin_area_level_2 TEXT,
	address_country TEXT,
	address_postal_code TEXT,
	category_id UUID references categories(id) on delete restrict,
	first_char text,
	visible_to text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index organization_company_id on organizations(company_id);
create index organization_owner_id on organizations(owner_id);
create index organization_category_id on organizations(category_id);
create index organization_deleted_at on organizations(deleted_at);

GRANT ALL PRIVILEGES ON TABLE organizations TO GROUP superwork;

INSERT INTO migrations(name) VALUES('organizations');

/* persons (Person) */

CREATE TABLE persons(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	owner_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	org_id UUID REFERENCES organizations(id) ON DELETE RESTRICT,
	first_name TEXT,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index person_owner_id on persons(owner_id);
create index person_company_id on persons(company_id);
create index person_org_id on persons(org_id);
create index person_deleted_at on persons(deleted_at);

GRANT ALL PRIVILEGES ON TABLE persons TO GROUP superwork;

INSERT INTO migrations(name) VALUES('persons');

/* contacts (Contact) */

CREATE TABLE contacts(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	person_id UUID NOT NULL REFERENCES persons(id) ON DELETE RESTRICT,
	primary_contact boolean,
	type TEXT,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index contact_person_id on contacts(person_id);
create index contact_deleted_at on contacts(deleted_at);

GRANT ALL PRIVILEGES ON TABLE contacts TO GROUP superwork;

INSERT INTO migrations(name) VALUES('contacts');

/* person_fields (PersonField) */

CREATE TABLE person_fields(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	company_id UUID not null references companies(id) on delete restrict,
   	name TEXT NOT NULL,
   	key text not null,
   	order_nr int,
   	picklist_data text,
	field_type text not null,
	edit_flag boolean,
	index_visible_flag boolean,
	details_visible_flag boolean,
	add_visible_flag boolean,
	important_flag boolean,
	bulk_edit_allowed boolean,
	use_field text,
	link text,
	mandatory_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index person_field_company_id on person_fields(company_id);
create index person_field_deleted_at on person_fields(deleted_at);

GRANT ALL PRIVILEGES ON TABLE person_fields TO GROUP superwork;

INSERT INTO migrations(name) VALUES('person_fields');

/* workflows (workflow) */

CREATE TABLE workflows(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID not null references companies(id) on delete restrict,
   	name TEXT NOT NULL,
	order_nr int not null default 0,
	url_title text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index workflow_company_id on workflows(company_id);
create index workflow_field_deleted_at on workflows(deleted_at);

GRANT ALL PRIVILEGES ON TABLE workflows TO GROUP superwork;

INSERT INTO migrations(name) VALUES('workflows');

/* stages (Stage) */

CREATE TABLE stages(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	order_nr int,
	task_probability int,
	workflow_id UUID NOT NULL REFERENCES workflows(id) ON DELETE RESTRICT,
	rotten_flag boolean,
	rotten_days int,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index stage_workflow_id on stages(workflow_id);
create index stage_field_deleted_at on stages(deleted_at);

GRANT ALL PRIVILEGES ON TABLE stages TO GROUP superwork;

INSERT INTO migrations(name) VALUES('stages');

/* tasks (Task) */

CREATE TABLE tasks(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	creator_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	person_id UUID REFERENCES persons(id) ON DELETE RESTRICT,
	org_id UUID REFERENCES organizations(id) ON DELETE RESTRICT,
	stage_id UUID NOT NULL REFERENCES stages(id) ON DELETE RESTRICT,
	value int,
	currency text,
	stage_change_time timestamp with time zone,
	status text,
	lost_reason text,
	visible_to int,
	close_time timestamp with time zone,
	workflow_id UUID NOT NULL REFERENCES workflows(id) ON DELETE RESTRICT,
	won_time timestamp with time zone,
	first_won_time timestamp with time zone,
	lost_time timestamp with time zone,
	expected_close_date timestamp with time zone,
	stage_order_nr           int,
	formatted_value text,
	rotten_time timestamp with time zone,
	weighted_value int,
	formatted_weighted_value text,
	cc_email text,
	org_hidden boolean,
	person_hidden boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index task_creator_user_id on tasks(creator_user_id);
create index task_user_id on tasks(user_id);
create index task_person_id on tasks(person_id);
create index task_org_id on tasks(org_id);
create index task_stage_id on tasks(stage_id);
create index task_workflow_id on tasks(workflow_id);
create index task_deleted_at on tasks(deleted_at);

GRANT ALL PRIVILEGES ON TABLE tasks TO GROUP superwork;

INSERT INTO migrations(name) VALUES('tasks');

/* notes (Note) */

CREATE TABLE notes(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	task_id UUID REFERENCES tasks(id) ON DELETE RESTRICT,
	person_id UUID REFERENCES persons(id) ON DELETE RESTRICT,
	org_id UUID REFERENCES organizations(id) ON DELETE RESTRICT,
	pinned_to_task_flag boolean,
	pinned_to_person_flag boolean,
	pinned_to_organization_flag boolean,
	last_update_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index note_company_id on notes(company_id);
create index note_user_id on notes(user_id);
create index note_task_id on notes(task_id);
create index note_person_id on notes(person_id);
create index note_org_id on notes(org_id);
create index note_deleted_at on notes(deleted_at);

GRANT ALL PRIVILEGES ON TABLE notes TO GROUP superwork;

INSERT INTO migrations(name) VALUES('notes');

/* activity_types (ActivityType) */

CREATE TABLE activity_types(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	key_string text,
	order_nr int,
	color text,
	is_custom_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index activity_type_company_id on activity_types(company_id);
create index activity_type_deleted_at on activity_types(deleted_at);

GRANT ALL PRIVILEGES ON TABLE activity_types TO GROUP superwork;

INSERT INTO migrations(name) VALUES('activity_types');

/* activities (Activity) */

CREATE TABLE activities(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	done boolean,
	type_id uuid references activity_types(id) on delete restrict,
	reference_type text,
	reference_id text,
	due_date timestamp with time zone,
	duration text,
	marked_as_done_time timestamp with time zone,
	task_id UUID REFERENCES tasks(id) ON DELETE RESTRICT,
	org_id UUID REFERENCES organizations(id) ON DELETE RESTRICT,
	person_id UUID REFERENCES persons(id) ON DELETE RESTRICT,
	assigned_to_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
	created_by_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index activity_company_id on activities(company_id);
create index activity_user_id on activities(user_id);
create index activity_task_id on activities(task_id);
create index activity_org_id on activities(org_id);
create index activity_person_id on activities(person_id);
create index activity_assigned_to_user_id on activities(assigned_to_user_id);
create index activity_created_by_user_id on activities(created_by_user_id);
create index activity_deleted_at on activities(deleted_at);
create index activity_type_id on activities(type_id);

GRANT ALL PRIVILEGES ON TABLE activities TO GROUP superwork;

INSERT INTO migrations(name) VALUES('activities');

/* files (File) */

CREATE TABLE files(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name TEXT NOT NULL,
	user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	task_id UUID  REFERENCES tasks(id) ON DELETE RESTRICT,
	person_id UUID REFERENCES persons(id) ON DELETE RESTRICT,
	org_id UUID  REFERENCES organizations(id) ON DELETE RESTRICT,
	activity_id UUID REFERENCES activities(id) ON DELETE RESTRICT,
	note_id UUID  REFERENCES notes(id) ON DELETE RESTRICT,
	file_type text,
	file_size int,
	inline_flag boolean,
	remote_location text,
	remote_id text,
	cid text,
	s3_bucket text,
	url text,
	description text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index file_user_id on files(user_id);
create index file_task_id on files(task_id);
create index file_person_id on files(person_id);
create index file_org_id on files(org_id);
create index file_activity_id on files(activity_id);
create index file_note_id on files(note_id);
create index file_deleted_at on files(deleted_at);

alter table organizations add column picture_id UUID references files(id) on delete restrict;
create index organization_picture_id on organizations(picture_id);

GRANT ALL PRIVILEGES ON TABLE files TO GROUP superwork;

INSERT INTO migrations(name) VALUES('files');

/* company_users */

create table company_users(
	id UUID primary key default gen_random_uuid(),
	user_id UUID not null references users(id) on delete restrict,
	is_admin boolean not null default false,
	company_id UUID not null references companies(id) on delete restrict,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index company_user_user_id on company_users(user_id);
create index company_user_company_id on company_users(company_id);
create index company_user_deleted_at on company_users(deleted_at);

GRANT ALL PRIVILEGES ON TABLE company_users TO GROUP superwork;

insert into migrations(name) values('company_users');

/* activity_fields (ActivityField) */

CREATE TABLE activity_fields(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	key text,
	order_nr int,
	picklist_data text,
	field_type text,
	edit_flag boolean,
	index_visible_flag boolean,
	details_visible_flag boolean,
	add_visible_flag boolean,
	important_flag boolean,
	bulk_edit_allowed boolean,
	mandatory_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index activity_field_company_id on activity_fields(company_id);
create index activity_field_deleted_at on activity_fields(deleted_at);

GRANT ALL PRIVILEGES ON TABLE activity_fields TO GROUP superwork;

INSERT INTO migrations(name) VALUES('activity_fields');

/* currencies (Currency) */

CREATE TABLE currencies(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	code text,
	decimal_points int,
	symbol text,
	is_custom_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index currency_company_id on currencies(company_id);
create index currency_deleted_at on currencies(deleted_at);

GRANT ALL PRIVILEGES ON TABLE currencies TO GROUP superwork;

INSERT INTO migrations(name) VALUES('currencies');

/* task_fields (TaskField) */

CREATE TABLE task_fields(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	key text,
	order_nr int,
	picklist_data text,
	field_type text,
	edit_flag boolean,
	index_visible_flag boolean,
	details_visible_flag boolean,
	add_visible_flag boolean,
	important_flag boolean,
	bulk_edit_allowed boolean,
	mandatory_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index task_fields_company_id on task_fields(company_id);
create index task_fields_deleted_at on task_fields(deleted_at);

GRANT ALL PRIVILEGES ON TABLE task_fields TO GROUP superwork;

INSERT INTO migrations(name) VALUES('task_fields');

/* filters (Filter) */

CREATE TABLE filters(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	type text,
	temporary_flag boolean,
	user_id UUID not null references users(id) on delete restrict,
	visible_to text,
	custom_view_id text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index filters_company_id on filters(company_id);
create index filters_user_id on filters(user_id);
create index filters_deleted_at on filters(deleted_at);

GRANT ALL PRIVILEGES ON TABLE filters TO GROUP superwork;

INSERT INTO migrations(name) VALUES('filters');

/* goals (Goal) */

CREATE TABLE goals(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	user_id UUID NOT NULL references users(id) on delete restrict,
	stage_id UUID references stages(id) on delete restrict,
	active_goal_id UUID references goals(id) on delete restrict,
	period text,
	expected int,
	goal_type text,
	expected_sum int,
	currency text,
	expected_type text,
	created_by_user_id UUID references users(id) on delete restrict,
	workflow_id UUID references workflows(id) on delete restrict,
	master_expected int,
	delivered int,
	delivered_sum text,
	period_start timestamp with time zone,
	period_end timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index goals_company_id on goals(company_id);
create index goals_user_id on goals(user_id);
create index goals_stage_id on goals(stage_id);
create index goals_active_goal_id on goals(active_goal_id);
create index goals_created_by_user_id on goals(created_by_user_id);
create index goals_workflow_id on goals(workflow_id);
create index goals_deleted_at on goals(deleted_at);

GRANT ALL PRIVILEGES ON TABLE goals TO GROUP superwork;

INSERT INTO migrations(name) VALUES('goals');

/* note_fields (NoteField) */

CREATE TABLE note_fields(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	key text,
	field_type text,
	edit_flag boolean,
	mandatory_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index note_fields_company_id on note_fields(company_id);
create index note_fields_deleted_at on note_fields(deleted_at);

GRANT ALL PRIVILEGES ON TABLE note_fields TO GROUP superwork;

INSERT INTO migrations(name) VALUES('note_fields');

/* organization_fields (OrganizationField) */

CREATE TABLE organization_fields(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	key text,
	order_nr int,
	picklist_data text,
	field_type text,
	edit_flag boolean,
	index_visible_flag boolean,
	details_visible_flag boolean,
	add_visible_flag boolean,
	important_flag boolean,
	bulk_edit_allowed boolean,
	use_field text,
	link text,
	mandatory_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index organization_fields_company_id on organization_fields(company_id);
create index organization_fields_deleted_at on organization_fields(deleted_at);

GRANT ALL PRIVILEGES ON TABLE organization_fields TO GROUP superwork;

INSERT INTO migrations(name) VALUES('organization_fields');

/* organization_relationships (OrganizationRelationship) */

CREATE TABLE organization_relationships(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	type text,
	rel_owner_org_id UUID references organizations(id) on delete restrict,
	rel_linked_org_id UUID references organizations(id) on delete restrict,
	calculated_type text,
	calculated_related_org_id UUID references organizations(id) on delete restrict,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index organization_relationships_company_id on organization_relationships(company_id);
create index organization_relationships_rel_owner_org_id on organization_relationships(rel_owner_org_id);
create index organization_relationships_rel_linked_org_id on organization_relationships(rel_linked_org_id);
create index organization_relationships_calculated_related_org_id on organization_relationships(calculated_related_org_id);
create index organization_relationshops_deleted_at on organization_relationships(deleted_at);

GRANT ALL PRIVILEGES ON TABLE organization_relationships TO GROUP superwork;

INSERT INTO migrations(name) VALUES('organization_relationships');

/* products (Product) */

CREATE TABLE products(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
	name text,
	code text,
	unit text,
	tax int,
	selectable boolean,
	first_char text,
	visible_to text,
	owner_id UUID not null references users(id) on delete restrict,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index products_company_id on products(company_id);
create index products_user_id on products(owner_id);
create index products_deleted_at on products(deleted_at);

GRANT ALL PRIVILEGES ON TABLE products TO GROUP superwork;

INSERT INTO migrations(name) VALUES('products');

/* prices (Price) */

CREATE TABLE prices(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	product_id uuid not null references products(id) on delete restrict,
	price int,
	currency text,
	cost int,
	overhead_cost text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index prices_product_id on prices(product_id);
create index prices_deleted_at on prices(deleted_at);

GRANT ALL PRIVILEGES ON TABLE prices TO GROUP superwork;

INSERT INTO migrations(name) VALUES('prices');

/* product_fields (ProductField) */

CREATE TABLE product_fields(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
   	name text,
	key text,
	order_nr int,
	picklist_data text,
	field_type text,
	edit_flag boolean,
	index_visible_flag boolean,
	details_visible_flag boolean,
	add_visible_flag boolean,
	important_flag boolean,
	bulk_edit_allowed boolean,
	use_field text,
	link text,
	mandatory_flag boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index product_fields_company_id on product_fields(company_id);
create index product_fields_deleted_at on product_fields(deleted_at);

GRANT ALL PRIVILEGES ON TABLE product_fields TO GROUP superwork;

INSERT INTO migrations(name) VALUES('product_fields');

/* push_notifications (PushNotification) */

CREATE TABLE push_notifications(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	company_id UUID NOT NULL REFERENCES companies(id) ON DELETE RESTRICT,
   	user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
	subscription_url text,
	type text,
	event text,
	http_auth_user text,
	http_auth_password text,
	http_last_response_code text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index push_notifications_company_id on push_notifications(company_id);
create index push_notifications_user_id on push_notifications(user_id);
create index push_notifications_deleted_at on push_notifications(deleted_at);

GRANT ALL PRIVILEGES ON TABLE push_notifications TO GROUP superwork;

INSERT INTO migrations(name) VALUES('push_notifications');

/* add active_company_id to users */

ALTER TABLE users ADD COLUMN active_company_id UUID NOT NULL references companies(id) on delete restrict;

INSERT INTO migrations(name) VALUES('active_company_id');

/* add active_workflow_id to users */

ALTER TABLE users ADD COLUMN active_workflow_id UUID references workflows(id) on delete restrict;

INSERT INTO migrations(name) VALUES('active_workflow_id');

/* activations */

CREATE TABLE activations(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	user_id UUID not null references users(id) on delete restrict,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index activations_deleted_at on activations(deleted_at);

GRANT ALL PRIVILEGES ON TABLE activations TO GROUP superwork;

INSERT INTO migrations(name) VALUES('activations');

/* timeline (Timeline) */

CREATE TABLE timeline(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	user_id UUID not null references users(id),
   	name text not null,
   	action text not null,
   	under_company_id UUID references companies(id),
   	activity_id UUID references activities(id),
   	activity_field_id UUID references activity_fields(id),
   	activity_type_id UUID references activity_types(id),
   	category_id UUID references categories(id),
   	company_id UUID references companies(id),
   	company_user_id UUID references company_users(id),
   	contact_id UUID references contacts(id),
   	currency_id UUID references currencies(id),
 	file_id UUID references files(id),
 	filter_id UUID references filters(id),
 	goal_id UUID references goals(id),
 	note_field_id UUID references note_fields(id),
 	note_id UUID references notes(id),
 	organization_field_id UUID references organization_fields(id),
 	organization_relationship_id UUID references organization_relationships(id),
 	organization_id UUID references organizations(id),
 	person_field_id UUID references person_fields(id),
 	person_id UUID references persons(id),
 	price_id UUID references prices(id),
 	product_field_id UUID references product_fields(id),
 	product_id UUID references products(id),
 	push_notification_id UUID references push_notifications(id),
 	stage_id UUID references stages(id),
 	task_field_id UUID references task_fields(id),
 	task_id UUID references tasks(id),
 	workflow_id UUID references workflows(id),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index timeline_created_at on timeline(created_at);
create index timeline_user_id on timeline(user_id);
create index timeline_under_company_id on timeline(under_company_id);

GRANT ALL PRIVILEGES ON TABLE timeline TO GROUP superwork;

INSERT INTO migrations(name) VALUES('timeline');

/* time entries */

CREATE TABLE time_entries(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name text,
   	user_id UUID not null references users(id) on delete restrict,
   	company_id UUID not null references companies(id) on delete restrict,
   	started_at timestamp with time zone NOT NULL,
   	finished_at timestamp with time zone,
   	task_id UUID references tasks(id) on delete restrict,
   	activity_id UUID references activities(id) on delete restrict,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index time_entries_deleted_at on time_entries(deleted_at);
create index time_entries_user_id on time_entries(user_id);
create index time_entries_started_at on time_entries(started_at);
create index time_entries_finished_at on time_entries(finished_at);
create index time_entries_task_id on time_entries(task_id);
create index time_entries_activity_id on time_entries(activity_id);
create index time_entries_company_id on time_entries(activity_id);

GRANT ALL PRIVILEGES ON TABLE time_entries TO GROUP superwork;

INSERT INTO migrations(name) VALUES('time_entries');

/* timeline.time_entry_id */

alter table timeline add column time_entry_id uuid references time_entries(id);

create index timeline_time_entry_id on timeline(time_entry_id);

INSERT INTO migrations(name) VALUES('time_entries.time_entry_id');

/* tasks.company_id */

alter table tasks add company_id UUID references companies(id);

create index tasks_company_id on tasks(company_id);

INSERT INTO migrations(name) VALUES('tasks.company_id');

/* api token */

alter table users add api_token text;

create index users_api_token on users(api_token);

insert into migrations(name) values('api token');

/* user events */

CREATE TABLE user_events(
   	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   	name text,
   	user_id UUID not null references users(id) on delete restrict,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);

create index user_events_deleted_at on user_events(deleted_at);
create index user_events_user_id on user_events(user_id);
CREATE UNIQUE INDEX user_events_name_unique ON user_events(name, user_id)
   WHERE deleted_at IS NULL;

GRANT ALL PRIVILEGES ON TABLE user_events TO GROUP superwork;

INSERT INTO migrations(name) VALUES('user_events');

/* activity type is unique per company */

CREATE UNIQUE INDEX activity_types_name_unique ON activity_types(name, company_id)
   WHERE deleted_at IS NULL;
